import { Link } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { IconGraduation } from '../components/ui/Icons';

/** 404 for both public and authenticated areas. */
export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink-50 px-4 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-100 text-brand-700">
        <IconGraduation className="h-8 w-8" />
      </span>
      <h1 className="mt-6 text-3xl font-semibold text-ink-900">Page not found</h1>
      <p className="mt-2 max-w-md text-sm text-ink-500">
        The page you're looking for doesn't exist or may have moved. Check the address or head back home.
      </p>
      <div className="mt-6 flex gap-3">
        <Link to="/">
          <Button>Back to home</Button>
        </Link>
        <Link to="/login">
          <Button variant="outline">Sign in</Button>
        </Link>
      </div>
    </div>
  );
}
