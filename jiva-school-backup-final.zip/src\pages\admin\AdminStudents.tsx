import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { studentSchema, type StudentInput } from '../../lib/validation';
import { formatDate } from '../../lib/utils';
import type { Student, StudentStatus } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { useToast } from '../../components/Toast';
import type { Paginated } from '../../lib/repo/types';

const STATUS_TONE: Record<StudentStatus, 'success' | 'neutral' | 'info' | 'warning'> = {
  active: 'success',
  inactive: 'neutral',
  graduated: 'info',
  transferred: 'warning',
};

interface StudentForm {
  fullName: string;
  dateOfBirth: string;
  gender: string;
  admissionDate: string;
  guardianName: string;
  guardianPhone: string;
  address: string;
  status: StudentStatus;
}

const EMPTY_FORM: StudentForm = {
  fullName: '',
  dateOfBirth: '',
  gender: '',
  admissionDate: '',
  guardianName: '',
  guardianPhone: '',
  address: '',
  status: 'active',
};

/** Admin student register — search, create and edit student records. */
export function AdminStudents() {
  const repo = useRepo();
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [form, setForm] = useState<StudentForm>(EMPTY_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const { data, loading, error, reload } = useAsync<Paginated<Student>>(
    () => repo.listStudents({ search, page, pageSize: 10 }),
    [repo, search, page],
  );

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setErrors({});
    setFormError(null);
    setModalOpen(true);
  }

  function openEdit(student: Student) {
    setEditing(student);
    setForm({
      fullName: student.fullName,
      dateOfBirth: student.dateOfBirth ?? '',
      gender: student.gender ?? '',
      admissionDate: student.admissionDate ?? '',
      guardianName: student.guardianName ?? '',
      guardianPhone: student.guardianPhone ?? '',
      address: student.address ?? '',
      status: student.status,
    });
    setErrors({});
    setFormError(null);
    setModalOpen(true);
  }

  async function save() {
    const payload: StudentInput = {
      fullName: form.fullName,
      dateOfBirth: form.dateOfBirth || undefined,
      gender: (form.gender || undefined) as StudentInput['gender'],
      admissionDate: form.admissionDate || undefined,
      guardianName: form.guardianName || undefined,
      guardianPhone: form.guardianPhone || undefined,
      address: form.address || undefined,
      status: form.status,
    };
    const parsed = studentSchema.safeParse(payload);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      if (editing) {
        await repo.updateStudent(editing.id, {
          fullName: parsed.data.fullName,
          dateOfBirth: parsed.data.dateOfBirth ?? null,
          gender: (parsed.data.gender || null) as Student['gender'],
          admissionDate: parsed.data.admissionDate ?? null,
          guardianName: parsed.data.guardianName ?? null,
          guardianPhone: parsed.data.guardianPhone ?? null,
          address: parsed.data.address ?? null,
          status: parsed.data.status,
        });
        toast.push('success', 'Student record updated.');
      } else {
        await repo.createStudent({
          fullName: parsed.data.fullName,
          dateOfBirth: parsed.data.dateOfBirth ?? null,
          gender: (parsed.data.gender || null) as Student['gender'],
          admissionDate: parsed.data.admissionDate ?? null,
          guardianName: parsed.data.guardianName ?? null,
          guardianPhone: parsed.data.guardianPhone ?? null,
          address: parsed.data.address ?? null,
          status: parsed.data.status,
        });
        toast.push('success', 'Student registered.');
      }
      setModalOpen(false);
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  const columns: Array<Column<Student>> = [
    { key: 'studentId', header: 'Student ID', render: (s) => <span className="font-medium text-ink-800">{s.studentId}</span> },
    { key: 'name', header: 'Name', render: (s) => s.fullName },
    { key: 'guardian', header: 'Guardian', render: (s) => s.guardianName ?? '—' },
    { key: 'admission', header: 'Admitted', render: (s) => formatDate(s.admissionDate) },
    { key: 'status', header: 'Status', render: (s) => <Badge tone={STATUS_TONE[s.status]}>{s.status}</Badge> },
    {
      key: 'actions',
      header: '',
      headerClassName: 'text-right',
      className: 'text-right',
      render: (s) => (
        <Button size="sm" variant="outline" onClick={() => openEdit(s)}>
          Edit
        </Button>
      ),
    },
  ];

  const total = data?.total ?? 0;
  const pageSize = data?.pageSize ?? 10;
  const pageCount = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <PageHeader
        title="Students"
        subtitle="Register, search and update student records."
        actions={
          <Button onClick={openCreate}>
            <span className="text-lg leading-none">+</span> Add student
          </Button>
        }
      />

      <Card>
        <div className="border-b border-ink-100 p-4">
          <Input
            placeholder="Search by name, student ID or guardian…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>

        {loading && <PageSpinner />}
        {error && (
          <div className="p-4">
            <Alert variant="danger">{error}</Alert>
          </div>
        )}
        {data && (
          <DataTable
            columns={columns}
            rows={data.items}
            rowKey={(s) => s.id}
            caption="Student register"
            empty={<EmptyState title="No students found" description="Try a different search, or add a new student." />}
          />
        )}

        {data && total > pageSize && (
          <div className="flex items-center justify-between border-t border-ink-100 px-4 py-3 text-sm text-ink-500">
            <span>
              Page {data.page} of {pageCount} · {total} students
            </span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <Button size="sm" variant="outline" disabled={page >= pageCount} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          </div>
        )}
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? `Edit ${editing.fullName}` : 'Add student'}
        description={editing ? 'Update the student record below.' : 'Register a new student. A student ID is assigned automatically.'}
        footer={
          <>
            <Button variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void save()}>
              {editing ? 'Save changes' : 'Register student'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input label="Full name" value={form.fullName} error={errors.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Date of birth" type="date" value={form.dateOfBirth} error={errors.dateOfBirth} onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })} />
            <Select label="Gender" value={form.gender} error={errors.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
              <option value="">Not specified</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Admission date" type="date" value={form.admissionDate} error={errors.admissionDate} onChange={(e) => setForm({ ...form, admissionDate: e.target.value })} />
            <Select label="Status" value={form.status} error={errors.status} onChange={(e) => setForm({ ...form, status: e.target.value as StudentStatus })}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="graduated">Graduated</option>
              <option value="transferred">Transferred</option>
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Guardian name" value={form.guardianName} error={errors.guardianName} onChange={(e) => setForm({ ...form, guardianName: e.target.value })} />
            <Input label="Guardian phone" value={form.guardianPhone} error={errors.guardianPhone} onChange={(e) => setForm({ ...form, guardianPhone: e.target.value })} />
          </div>
          <Input label="Address" value={form.address} error={errors.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </div>
      </Modal>
    </div>
  );
}
