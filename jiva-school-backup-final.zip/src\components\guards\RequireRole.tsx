import { Navigate } from 'react-router-dom';
import type { ReactNode } from 'react';
import { useAuth } from '../../state/AuthContext';
import { HOME_BY_ROLE } from '../../lib/permissions';
import type { Role } from '../../lib/types';

/** Require a specific role; other authenticated users are sent to their home. */
export function RequireRole({ role, children }: { role: Role; children: ReactNode }) {
  const { session } = useAuth();
  if (!session) return <Navigate to="/login" replace />;
  if (session.profile.role !== role) return <Navigate to={HOME_BY_ROLE[session.profile.role]} replace />;
  return <>{children}</>;
}
