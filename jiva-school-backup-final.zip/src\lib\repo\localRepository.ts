import { computeSubjectResult, rankByPercentages, summarizeSubjects, validateMarkScore } from '../grading';
import { can, ROLE_LABELS, type Permission } from '../permissions';
import { createSeedDb, type DemoCredential, type DemoDb } from '../demo/seed';
import { hashPassword, isStrongPassword, verifyPassword } from '../security';
import { uid } from '../utils';
import type {
  AcademicYear,
  Assessment,
  AuditLog,
  ClassSection,
  GradingScale,
  Mark,
  Notice,
  Profile,
  ResultPublication,
  Role,
  Session,
  Subject,
  SubjectResult,
  Teacher,
  Term,
  TermResult,
  Student,
} from '../types';
import {
  matchesSearch,
  paginate,
  type ClassResultSheet,
  type CreateAccountInput,
  type CreateStudentInput,
  type CreateTeacherInput,
  type MarkDraftInput,
  type MarkSubmissionCheck,
  type PageFilter,
  type Paginated,
  type RegisterInput,
  type SaveAssessmentInput,
  type SaveNoticeInput,
  type SchoolRepository,
} from './types';

const DB_KEY = 'jiva_school_demo_db_v1';
const SESSION_KEY = 'jiva_school_demo_session_v1';

function storage(): Storage | null {
  try {
    return globalThis.localStorage ?? null;
  } catch {
    return null;
  }
}

function persistDb(database: DemoDb): void {
  try {
    storage()?.setItem(DB_KEY, JSON.stringify(database));
  } catch {
    /* quota exceeded — demo continues in memory */
  }
}

function loadDb(): DemoDb {
  const store = storage();
  if (store) {
    try {
      const raw = store.getItem(DB_KEY);
      if (raw) return JSON.parse(raw) as DemoDb;
    } catch {
      /* corrupted payload — reseed below */
    }
  }
  const seeded = createSeedDb();
  persistDb(seeded);
  return seeded;
}

let db: DemoDb = loadDb();

/** Reset the demo database to its seeded state (used by tests). */
export function resetDemoDb(): DemoDb {
  db = createSeedDb();
  persistDb(db);
  try {
    storage()?.removeItem(SESSION_KEY);
  } catch {
    /* ignore */
  }
  return db;
}

const nowIso = () => new Date().toISOString();

export class LocalRepository implements SchoolRepository {
  private session: Session | null = null;
  private listeners = new Set<(session: Session | null) => void>();

  constructor() {
    const store = storage();
    const raw = store?.getItem(SESSION_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw) as { profileId: string; email: string };
        const profile = db.profiles.find((p) => p.id === parsed.profileId);
        if (profile) this.session = { user: { id: profile.id, email: parsed.email }, profile };
      } catch {
        /* ignore invalid session */
      }
    }
  }

  /* ------------------------------ helpers ------------------------------ */

  private auth(): Session {
    if (!this.session) throw new Error('Please sign in to continue.');
    return this.session;
  }

  private assertPermission(permission: Permission): Profile {
    const { profile } = this.auth();
    if (!can(profile.role, permission)) {
      throw new Error('You do not have permission to perform this action.');
    }
    return profile;
  }

  private emit(): void {
    for (const cb of this.listeners) cb(this.session);
  }

  private teacherByProfile(profileId: string) {
    return db.teachers.find((t) => t.profileId === profileId) ?? null;
  }

  private studentByProfile(profileId: string) {
    return db.students.find((s) => s.profileId === profileId) ?? null;
  }

  private parentByProfile(profileId: string) {
    return db.parents.find((p) => p.profileId === profileId) ?? null;
  }

  private childrenOf(profileId: string): Student[] {
    const parent = this.parentByProfile(profileId);
    if (!parent) return [];
    const ids = new Set(db.parentLinks.filter((l) => l.parentId === parent.id).map((l) => l.studentId));
    return db.students.filter((s) => ids.has(s.id));
  }

  private isAssignedToClass(profileId: string, classSectionId: string): boolean {
    const teacher = this.teacherByProfile(profileId);
    if (!teacher) return false;
    return db.assignments.some((a) => a.teacherId === teacher.id && a.classSectionId === classSectionId);
  }

  private assertTeacherCombination(profile: Profile, classSectionId: string, subjectId: string): void {
    if (profile.role === 'admin') return;
    const teacher = this.teacherByProfile(profile.id);
    if (!teacher) throw new Error('No teacher profile is linked to your account.');
    const year = db.academicYears.find((y) => y.isCurrent);
    const ok = db.assignments.some(
      (a) =>
        a.teacherId === teacher.id &&
        a.classSectionId === classSectionId &&
        a.subjectId === subjectId &&
        a.academicYearId === year?.id,
    );
    if (!ok) throw new Error('You are not assigned to teach this subject in this class.');
  }

  private writeAudit(
    actor: Profile,
    action: string,
    entityType: string,
    entityId: string,
    summary: string,
    details?: string,
  ): void {
    db.audit.push({
      id: uid('aud'),
      actorId: actor.id,
      actorName: actor.fullName,
      action,
      entityType,
      entityId,
      summary,
      details: details ?? null,
      createdAt: nowIso(),
    });
  }

  /* -------------------------------- auth -------------------------------- */

  getSession(): Session | null {
    return this.session;
  }

  subscribe(callback: (session: Session | null) => void): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  /** Verify a credential, upgrading legacy plain-text demo passwords to hashes. */
  private async checkPassword(credential: DemoCredential, password: string): Promise<boolean> {
    if (credential.passwordHash) return verifyPassword(password, credential.passwordHash);
    // Legacy demo seed data stored the plain-text password. Verify it once,
    // then replace it with a PBKDF2 hash so nothing sensitive stays persisted.
    if (credential.password !== password) return false;
    credential.passwordHash = await hashPassword(password);
    delete credential.password;
    persistDb(db);
    return true;
  }

  async signIn(email: string, password: string): Promise<Session> {
    const normalized = email.trim().toLowerCase();
    const credential = db.credentials.find((c) => c.email.toLowerCase() === normalized);
    const profile = credential ? db.profiles.find((p) => p.id === credential.profileId) : null;
    // Generic error — never reveal whether an account exists.
    if (!credential || !profile || !(await this.checkPassword(credential, password))) {
      throw new Error('Invalid email or password.');
    }
    this.session = { user: { id: profile.id, email: credential.email }, profile };
    try {
      storage()?.setItem(SESSION_KEY, JSON.stringify({ profileId: profile.id, email: credential.email }));
    } catch {
      /* ignore */
    }
    this.emit();
    return this.session;
  }

  async signOut(): Promise<void> {
    this.session = null;
    try {
      storage()?.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
    this.emit();
  }

  async requestPasswordReset(email: string): Promise<void> {
    // Demo mode has no email service; the UI directs users to an administrator
    // instead of pretending a reset email was sent. Kept for the Supabase mode.
    void email.trim().toLowerCase();
  }

  /**
   * Self-service sign-up. Only students and parents may register themselves —
   * staff accounts must be created by an administrator from the Accounts page.
   */
  async register(input: RegisterInput): Promise<Session> {
    if (input.role !== 'student' && input.role !== 'parent') {
      throw new Error(
        'Self sign-up is only available for students and parents. Staff accounts are created by an administrator.',
      );
    }
    const email = input.email.trim().toLowerCase();
    const fullName = input.fullName.trim();
    if (fullName.length < 2) throw new Error('Enter your full name.');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Enter a valid email address.');
    if (!isStrongPassword(input.password)) {
      throw new Error('Password must be at least 8 characters and include both a letter and a number.');
    }
    if (db.credentials.some((c) => c.email.toLowerCase() === email)) {
      throw new Error('An account with this email already exists.');
    }
    const timestamp = nowIso();
    const profile: Profile = { id: uid('prof'), email, fullName, role: input.role, createdAt: timestamp };
    db.profiles.push(profile);
    db.credentials.push({ email, passwordHash: await hashPassword(input.password), profileId: profile.id });
    // Give the person a record so their portal has content immediately; an
    // administrator can later enrol them into classes / link family members.
    if (input.role === 'student') {
      db.students.push({
        id: uid('stu'),
        studentId: this.nextStudentNumber(),
        fullName,
        dateOfBirth: null,
        gender: null,
        status: 'active',
        admissionDate: timestamp.slice(0, 10),
        profileId: profile.id,
        guardianName: null,
        guardianPhone: null,
        address: null,
        createdAt: timestamp,
        updatedAt: timestamp,
      });
    } else {
      db.parents.push({ id: uid('par'), profileId: profile.id, fullName, phone: null, email, createdAt: timestamp });
    }
    this.writeAudit(
      profile,
      'account.register',
      'profile',
      profile.id,
      `Self-registered ${ROLE_LABELS[profile.role]} account for ${email}.`,
    );
    persistDb(db);
    this.session = { user: { id: profile.id, email }, profile };
    try {
      storage()?.setItem(SESSION_KEY, JSON.stringify({ profileId: profile.id, email }));
    } catch {
      /* ignore */
    }
    this.emit();
    return this.session;
  }

  /** Admin action: replace an account's password (stored as a PBKDF2 hash). */
  async resetPassword(profileId: string, newPassword: string): Promise<void> {
    const actor = this.assertPermission('accounts.manage');
    const profile = db.profiles.find((p) => p.id === profileId);
    const credential = db.credentials.find((c) => c.profileId === profileId);
    if (!profile || !credential) throw new Error('Account not found.');
    if (!isStrongPassword(newPassword)) {
      throw new Error('Password must be at least 8 characters and include both a letter and a number.');
    }
    credential.passwordHash = await hashPassword(newPassword);
    delete credential.password;
    this.writeAudit(actor, 'account.password_reset', 'profile', profile.id, `Reset the password for ${profile.email}.`);
    persistDb(db);
  }

  /* ------------------------- accounts & audit --------------------------- */

  async listAccounts(filter?: PageFilter): Promise<Paginated<Profile>> {
    this.assertPermission('accounts.manage');
    const items = db.profiles
      .filter((p) => matchesSearch(filter?.search, p.fullName, p.email, p.role))
      .sort((a, b) => a.fullName.localeCompare(b.fullName));
    return paginate(items, filter);
  }

  async createAccount(input: CreateAccountInput): Promise<Profile> {
    const actor = this.assertPermission('accounts.manage');
    const email = input.email.trim().toLowerCase();
    if (db.credentials.some((c) => c.email.toLowerCase() === email)) {
      throw new Error('An account with this email already exists.');
    }
    if (!isStrongPassword(input.password)) {
      throw new Error('Password must be at least 8 characters and include both a letter and a number.');
    }
    const profile: Profile = {
      id: uid('prof'),
      email,
      fullName: input.fullName.trim(),
      role: input.role,
      createdAt: nowIso(),
    };
    db.profiles.push(profile);
    db.credentials.push({ email, passwordHash: await hashPassword(input.password), profileId: profile.id });
    if (input.role === 'student' && input.studentId) {
      const student = db.students.find((s) => s.id === input.studentId);
      if (student) student.profileId = profile.id;
    }
    if (input.role === 'teacher' && input.teacherId) {
      const teacher = db.teachers.find((t) => t.id === input.teacherId);
      if (teacher) teacher.profileId = profile.id;
    }
    if (input.role === 'parent' && input.parentId) {
      const parent = db.parents.find((p) => p.id === input.parentId);
      if (parent) parent.profileId = profile.id;
    }
    this.writeAudit(actor, 'account.create', 'profile', profile.id, `Created ${ROLE_LABELS[input.role]} account for ${email}.`);
    persistDb(db);
    return profile;
  }

  async updateAccountRole(profileId: string, role: Role): Promise<Profile> {
    const actor = this.assertPermission('accounts.manage');
    if (actor.id === profileId) throw new Error('You cannot change the role of your own account.');
    const profile = db.profiles.find((p) => p.id === profileId);
    if (!profile) throw new Error('Account not found.');
    const previous = profile.role;
    profile.role = role;
    this.writeAudit(actor, 'account.role_change', 'profile', profile.id, `Changed role of ${profile.email} from ${ROLE_LABELS[previous]} to ${ROLE_LABELS[role]}.`);
    persistDb(db);
    return profile;
  }

  async listAuditLogs(filter?: PageFilter): Promise<Paginated<AuditLog>> {
    this.assertPermission('audit.view');
    const items = [...db.audit].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return paginate(items, filter);
  }

  /* ------------------------------ students ------------------------------ */

  async listStudents(
    filter?: PageFilter & { classSectionId?: string; status?: Student['status'] },
  ): Promise<Paginated<Student>> {
    const actor = this.auth().profile;
    let pool: Student[];
    if (actor.role === 'admin') {
      pool = db.students;
    } else if (actor.role === 'teacher') {
      const teacher = this.teacherByProfile(actor.id);
      const classIds = new Set(db.assignments.filter((a) => a.teacherId === teacher?.id).map((a) => a.classSectionId));
      const studentIds = new Set(
        db.enrollments.filter((e) => classIds.has(e.classSectionId)).map((e) => e.studentId),
      );
      pool = db.students.filter((s) => studentIds.has(s.id));
    } else if (actor.role === 'student') {
      const me = this.studentByProfile(actor.id);
      pool = me ? [me] : [];
    } else {
      pool = this.childrenOf(actor.id);
    }
    const items = pool
      .filter((s) => {
        if (filter?.status && s.status !== filter.status) return false;
        if (filter?.classSectionId) {
          const enrolled = db.enrollments.some(
            (e) => e.studentId === s.id && e.classSectionId === filter.classSectionId && e.status === 'active',
          );
          if (!enrolled) return false;
        }
        return matchesSearch(filter?.search, s.fullName, s.studentId, s.guardianName);
      })
      .sort((a, b) => a.fullName.localeCompare(b.fullName));
    return paginate(items, filter);
  }

  async getStudent(id: string): Promise<Student | null> {
    const actor = this.auth().profile;
    const student = db.students.find((s) => s.id === id) ?? null;
    if (!student) return null;
    if (actor.role === 'admin') return student;
    if (actor.role === 'teacher') {
      const classId = this.activeClassOf(student.id);
      return classId && this.isAssignedToClass(actor.id, classId) ? student : null;
    }
    if (actor.role === 'student') return this.studentByProfile(actor.id)?.id === id ? student : null;
    return this.childrenOf(actor.id).some((s) => s.id === id) ? student : null;
  }

  private activeClassOf(studentId: string): string | null {
    const enrollment = db.enrollments
      .filter((e) => e.studentId === studentId && e.status === 'active')
      .sort((a, b) => b.enrolledAt.localeCompare(a.enrolledAt))[0];
    return enrollment?.classSectionId ?? null;
  }

  private nextStudentNumber(): string {
    const year = new Date().getFullYear();
    let max = 0;
    for (const s of db.students) {
      const match = /^JS-\d{4}-(\d{4})$/.exec(s.studentId);
      if (match) max = Math.max(max, Number(match[1]));
    }
    return `JS-${year}-${String(max + 1).padStart(4, '0')}`;
  }

  async createStudent(input: CreateStudentInput): Promise<Student> {
    const actor = this.assertPermission('students.manage');
    const timestamp = nowIso();
    const student: Student = {
      id: uid('stu'),
      studentId: this.nextStudentNumber(),
      fullName: input.fullName.trim(),
      dateOfBirth: input.dateOfBirth ?? null,
      gender: input.gender ?? null,
      status: input.status,
      admissionDate: input.admissionDate ?? timestamp.slice(0, 10),
      profileId: null,
      guardianName: input.guardianName ?? null,
      guardianPhone: input.guardianPhone ?? null,
      address: input.address ?? null,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    db.students.push(student);
    if (input.classSectionId) {
      const year = db.academicYears.find((y) => y.isCurrent);
      if (year) {
        db.enrollments.push({
          id: uid('enr'),
          studentId: student.id,
          classSectionId: input.classSectionId,
          academicYearId: year.id,
          status: 'active',
          enrolledAt: timestamp,
        });
      }
    }
    this.writeAudit(actor, 'student.create', 'student', student.id, `Registered student ${student.fullName} (${student.studentId}).`);
    persistDb(db);
    return student;
  }

  async updateStudent(
    id: string,
    input: Partial<Omit<Student, 'id' | 'createdAt' | 'updatedAt'>>,
  ): Promise<Student> {
    const actor = this.assertPermission('students.manage');
    const student = db.students.find((s) => s.id === id);
    if (!student) throw new Error('Student not found.');
    Object.assign(student, input, { id: student.id, updatedAt: nowIso() });
    this.writeAudit(actor, 'student.update', 'student', student.id, `Updated record of ${student.fullName} (${student.studentId}).`);
    persistDb(db);
    return student;
  }

  /* ----------------------------- parents -------------------------------- */

  async listParents() {
    this.assertPermission('students.manage');
    return [...db.parents].sort((a, b) => a.fullName.localeCompare(b.fullName));
  }

  async listParentLinks() {
    this.assertPermission('students.manage');
    return [...db.parentLinks];
  }

  async linkParentToStudent(input: { parentId: string; studentId: string; relationship: string }) {
    const actor = this.assertPermission('students.manage');
    const parent = db.parents.find((p) => p.id === input.parentId);
    const student = db.students.find((s) => s.id === input.studentId);
    if (!parent || !student) throw new Error('Parent or student not found.');
    if (db.parentLinks.some((l) => l.parentId === parent.id && l.studentId === student.id)) {
      throw new Error('This parent is already linked to the student.');
    }
    const link = {
      id: uid('lnk'),
      parentId: parent.id,
      studentId: student.id,
      relationship: input.relationship.trim() || 'Guardian',
      createdAt: nowIso(),
    };
    db.parentLinks.push(link);
    this.writeAudit(
      actor,
      'parent.link',
      'parent_student_link',
      link.id,
      `Linked ${parent.fullName} to ${student.fullName} as ${link.relationship}.`,
    );
    persistDb(db);
    return link;
  }

  async getMyChildren(): Promise<Student[]> {
    const actor = this.assertPermission('results.view.children');
    return this.childrenOf(actor.id);
  }

  /* ------------------------------ teachers ------------------------------ */

  async listTeachers(filter?: PageFilter): Promise<Paginated<Teacher>> {
    this.assertPermission('staff.manage');
    const items = db.teachers
      .filter((t) => matchesSearch(filter?.search, t.fullName, t.employeeNo, t.email))
      .sort((a, b) => a.fullName.localeCompare(b.fullName));
    return paginate(items, filter);
  }

  async createTeacher(input: CreateTeacherInput): Promise<Teacher> {
    const actor = this.assertPermission('staff.manage');
    if (db.teachers.some((t) => t.employeeNo.toLowerCase() === input.employeeNo.trim().toLowerCase())) {
      throw new Error('A teacher with this employee number already exists.');
    }
    const teacher: Teacher = {
      id: uid('tch'),
      employeeNo: input.employeeNo.trim(),
      profileId: null,
      fullName: input.fullName.trim(),
      phone: input.phone ?? null,
      email: input.email ?? null,
      status: input.status ?? 'active',
      createdAt: nowIso(),
    };
    db.teachers.push(teacher);
    this.writeAudit(actor, 'staff.create', 'teacher', teacher.id, `Added staff member ${teacher.fullName} (${teacher.employeeNo}).`);
    persistDb(db);
    return teacher;
  }

  async updateTeacher(id: string, input: Partial<CreateTeacherInput>): Promise<Teacher> {
    const actor = this.assertPermission('staff.manage');
    const teacher = db.teachers.find((t) => t.id === id);
    if (!teacher) throw new Error('Teacher not found.');
    if (input.fullName !== undefined) teacher.fullName = input.fullName.trim();
    if (input.phone !== undefined) teacher.phone = input.phone;
    if (input.email !== undefined) teacher.email = input.email;
    if (input.status !== undefined) teacher.status = input.status;
    this.writeAudit(actor, 'staff.update', 'teacher', teacher.id, `Updated staff record of ${teacher.fullName}.`);
    persistDb(db);
    return teacher;
  }

  /* -------------------- classes, subjects, calendar --------------------- */

  async listClassSections(): Promise<ClassSection[]> {
    this.auth();
    return [...db.classSections].sort(
      (a, b) => a.gradeLevel - b.gradeLevel || a.section.localeCompare(b.section),
    );
  }

  async createClassSection(input: { name: string; section: string; gradeLevel: number }): Promise<ClassSection> {
    const actor = this.assertPermission('academics.manage');
    if (
      db.classSections.some(
        (c) => c.name.toLowerCase() === input.name.trim().toLowerCase() && c.section.toLowerCase() === input.section.trim().toLowerCase(),
      )
    ) {
      throw new Error('That class and section already exists.');
    }
    const created: ClassSection = {
      id: uid('cls'),
      name: input.name.trim(),
      section: input.section.trim(),
      gradeLevel: input.gradeLevel,
      classTeacherId: null,
      createdAt: nowIso(),
    };
    db.classSections.push(created);
    this.writeAudit(actor, 'class.create', 'class_section', created.id, `Created class ${created.name} ${created.section}.`);
    persistDb(db);
    return created;
  }

  async updateClassSection(
    id: string,
    input: Partial<{ name: string; section: string; gradeLevel: number; classTeacherId: string | null }>,
  ): Promise<ClassSection> {
    const actor = this.assertPermission('academics.manage');
    const classSection = db.classSections.find((c) => c.id === id);
    if (!classSection) throw new Error('Class not found.');
    Object.assign(classSection, input, { id: classSection.id });
    this.writeAudit(actor, 'class.update', 'class_section', classSection.id, `Updated class ${classSection.name} ${classSection.section}.`);
    persistDb(db);
    return classSection;
  }

  async listSubjects(): Promise<Subject[]> {
    this.auth();
    return [...db.subjects].sort((a, b) => a.name.localeCompare(b.name));
  }

  async createSubject(input: { code: string; name: string; isCore: boolean }): Promise<Subject> {
    const actor = this.assertPermission('academics.manage');
    if (db.subjects.some((s) => s.code.toLowerCase() === input.code.trim().toLowerCase())) {
      throw new Error('A subject with this code already exists.');
    }
    const subject: Subject = { id: uid('sub'), code: input.code.trim().toUpperCase(), name: input.name.trim(), isCore: input.isCore };
    db.subjects.push(subject);
    this.writeAudit(actor, 'subject.create', 'subject', subject.id, `Created subject ${subject.name} (${subject.code}).`);
    persistDb(db);
    return subject;
  }

  async updateSubject(id: string, input: Partial<{ code: string; name: string; isCore: boolean }>): Promise<Subject> {
    const actor = this.assertPermission('academics.manage');
    const subject = db.subjects.find((s) => s.id === id);
    if (!subject) throw new Error('Subject not found.');
    Object.assign(subject, input, { id: subject.id });
    this.writeAudit(actor, 'subject.update', 'subject', subject.id, `Updated subject ${subject.name}.`);
    persistDb(db);
    return subject;
  }

  async listAcademicYears(): Promise<AcademicYear[]> {
    this.auth();
    return [...db.academicYears].sort((a, b) => b.name.localeCompare(a.name));
  }

  async createAcademicYear(input: { name: string; startDate: string; endDate: string }): Promise<AcademicYear> {
    const actor = this.assertPermission('academics.manage');
    if (db.academicYears.some((y) => y.name.toLowerCase() === input.name.trim().toLowerCase())) {
      throw new Error('An academic year with this name already exists.');
    }
    const year: AcademicYear = {
      id: uid('yr'),
      name: input.name.trim(),
      startDate: input.startDate,
      endDate: input.endDate,
      isCurrent: false,
    };
    db.academicYears.push(year);
    this.writeAudit(actor, 'year.create', 'academic_year', year.id, `Created academic year ${year.name}.`);
    persistDb(db);
    return year;
  }

  async setCurrentAcademicYear(id: string): Promise<void> {
    const actor = this.assertPermission('academics.manage');
    const year = db.academicYears.find((y) => y.id === id);
    if (!year) throw new Error('Academic year not found.');
    for (const y of db.academicYears) y.isCurrent = y.id === id;
    this.writeAudit(actor, 'year.set_current', 'academic_year', id, `Set ${year.name} as the current academic year.`);
    persistDb(db);
  }

  async listTerms(academicYearId?: string): Promise<Term[]> {
    this.auth();
    return db.terms
      .filter((t) => !academicYearId || t.academicYearId === academicYearId)
      .sort((a, b) => a.order - b.order);
  }

  async createTerm(input: { academicYearId: string; name: string; order: number; startDate: string; endDate: string }): Promise<Term> {
    const actor = this.assertPermission('academics.manage');
    if (!db.academicYears.some((y) => y.id === input.academicYearId)) throw new Error('Academic year not found.');
    const term: Term = { id: uid('term'), ...input, isCurrent: false };
    db.terms.push(term);
    this.writeAudit(actor, 'term.create', 'term', term.id, `Created term ${term.name}.`);
    persistDb(db);
    return term;
  }

  async setCurrentTerm(id: string): Promise<void> {
    const actor = this.assertPermission('academics.manage');
    const term = db.terms.find((t) => t.id === id);
    if (!term) throw new Error('Term not found.');
    for (const t of db.terms) t.isCurrent = t.id === id;
    this.writeAudit(actor, 'term.set_current', 'term', id, `Set ${term.name} as the current term.`);
    persistDb(db);
  }

  /* -------------------- enrolments & assignments ------------------------ */

  async listEnrollments(filter?: { classSectionId?: string; academicYearId?: string; studentId?: string }) {
    const actor = this.auth().profile;
    let pool = db.enrollments;
    if (actor.role === 'teacher') {
      const teacher = this.teacherByProfile(actor.id);
      const classIds = new Set(db.assignments.filter((a) => a.teacherId === teacher?.id).map((a) => a.classSectionId));
      pool = pool.filter((e) => classIds.has(e.classSectionId));
    } else if (actor.role === 'student') {
      const me = this.studentByProfile(actor.id);
      pool = me ? pool.filter((e) => e.studentId === me.id) : [];
    } else if (actor.role === 'parent') {
      const ids = new Set(this.childrenOf(actor.id).map((s) => s.id));
      pool = pool.filter((e) => ids.has(e.studentId));
    }
    return pool.filter(
      (e) =>
        (!filter?.classSectionId || e.classSectionId === filter.classSectionId) &&
        (!filter?.academicYearId || e.academicYearId === filter.academicYearId) &&
        (!filter?.studentId || e.studentId === filter.studentId),
    );
  }

  async enrollStudent(input: { studentId: string; classSectionId: string; academicYearId: string }) {
    const actor = this.assertPermission('enrollments.manage');
    const student = db.students.find((s) => s.id === input.studentId);
    const classSection = db.classSections.find((c) => c.id === input.classSectionId);
    const year = db.academicYears.find((y) => y.id === input.academicYearId);
    if (!student || !classSection || !year) throw new Error('Student, class or academic year not found.');
    if (
      db.enrollments.some(
        (e) => e.studentId === student.id && e.academicYearId === year.id && e.status === 'active',
      )
    ) {
      throw new Error('This student already has an active enrolment for that academic year.');
    }
    const enrollment = {
      id: uid('enr'),
      studentId: student.id,
      classSectionId: classSection.id,
      academicYearId: year.id,
      status: 'active' as const,
      enrolledAt: nowIso(),
    };
    db.enrollments.push(enrollment);
    this.writeAudit(
      actor,
      'enrollment.create',
      'enrollment',
      enrollment.id,
      `Enrolled ${student.fullName} into ${classSection.name} ${classSection.section} for ${year.name}.`,
    );
    persistDb(db);
    return enrollment;
  }

  async updateEnrollmentStatus(id: string, status: 'active' | 'completed' | 'withdrawn') {
    const actor = this.assertPermission('enrollments.manage');
    const enrollment = db.enrollments.find((e) => e.id === id);
    if (!enrollment) throw new Error('Enrolment not found.');
    enrollment.status = status;
    this.writeAudit(actor, 'enrollment.update', 'enrollment', id, `Set enrolment status to ${status}.`);
    persistDb(db);
    return enrollment;
  }

  async listTeacherAssignments(filter?: { teacherId?: string; classSectionId?: string }) {
    const actor = this.auth().profile;
    let pool = db.assignments;
    if (actor.role === 'teacher') {
      const teacher = this.teacherByProfile(actor.id);
      pool = pool.filter((a) => a.teacherId === teacher?.id);
    } else if (actor.role !== 'admin') {
      pool = [];
    }
    return pool.filter(
      (a) =>
        (!filter?.teacherId || a.teacherId === filter.teacherId) &&
        (!filter?.classSectionId || a.classSectionId === filter.classSectionId),
    );
  }

  async createTeacherAssignment(input: { teacherId: string; classSectionId: string; subjectId: string; academicYearId: string }) {
    const actor = this.assertPermission('academics.manage');
    const teacher = db.teachers.find((t) => t.id === input.teacherId);
    const classSection = db.classSections.find((c) => c.id === input.classSectionId);
    const subject = db.subjects.find((s) => s.id === input.subjectId);
    const year = db.academicYears.find((y) => y.id === input.academicYearId);
    if (!teacher || !classSection || !subject || !year) throw new Error('Teacher, class, subject or year not found.');
    if (
      db.assignments.some(
        (a) =>
          a.teacherId === teacher.id &&
          a.classSectionId === classSection.id &&
          a.subjectId === subject.id &&
          a.academicYearId === year.id,
      )
    ) {
      throw new Error('This teacher is already assigned to that class and subject.');
    }
    const assignment = { id: uid('asg'), ...input, createdAt: nowIso() };
    db.assignments.push(assignment);
    this.writeAudit(
      actor,
      'assignment.create',
      'teacher_assignment',
      assignment.id,
      `Assigned ${teacher.fullName} to ${subject.name} in ${classSection.name} ${classSection.section}.`,
    );
    persistDb(db);
    return assignment;
  }

  async deleteTeacherAssignment(id: string) {
    const actor = this.assertPermission('academics.manage');
    const index = db.assignments.findIndex((a) => a.id === id);
    if (index === -1) throw new Error('Assignment not found.');
    db.assignments.splice(index, 1);
    this.writeAudit(actor, 'assignment.delete', 'teacher_assignment', id, 'Removed a teacher class-subject assignment.');
    persistDb(db);
  }

  /* --------------------------- assessments ------------------------------ */

  async listAssessments(filter?: { classSectionId?: string; subjectId?: string; termId?: string }): Promise<Assessment[]> {
    const actor = this.auth().profile;
    let pool: Assessment[];
    if (actor.role === 'admin') {
      pool = db.assessments;
    } else if (actor.role === 'teacher') {
      const teacher = this.teacherByProfile(actor.id);
      const combos = new Set(
        db.assignments.filter((a) => a.teacherId === teacher?.id).map((a) => `${a.classSectionId}:${a.subjectId}`),
      );
      pool = db.assessments.filter((a) => combos.has(`${a.classSectionId}:${a.subjectId}`));
    } else {
      pool = [];
    }
    return pool
      .filter(
        (a) =>
          (!filter?.classSectionId || a.classSectionId === filter.classSectionId) &&
          (!filter?.subjectId || a.subjectId === filter.subjectId) &&
          (!filter?.termId || a.termId === filter.termId),
      )
      .sort((a, b) => a.title.localeCompare(b.title));
  }

  async createAssessment(input: SaveAssessmentInput): Promise<Assessment> {
    const actor = this.assertPermission('assessments.manage');
    this.assertTeacherCombination(actor, input.classSectionId, input.subjectId);
    if (input.maxMarks <= 0) throw new Error('Maximum marks must be greater than zero.');
    if (input.weight <= 0 || input.weight > 100) throw new Error('Weight must be between 1 and 100.');
    const existingWeight = db.assessments
      .filter(
        (a) =>
          a.classSectionId === input.classSectionId &&
          a.subjectId === input.subjectId &&
          a.termId === input.termId,
      )
      .reduce((sum, a) => sum + a.weight, 0);
    if (existingWeight + input.weight > 100) {
      throw new Error(`Total weight for this subject and term would exceed 100 (currently ${existingWeight}).`);
    }
    const timestamp = nowIso();
    const assessment: Assessment = {
      id: uid('asmt'),
      title: input.title.trim(),
      description: input.description ?? null,
      type: input.type,
      classSectionId: input.classSectionId,
      subjectId: input.subjectId,
      termId: input.termId,
      maxMarks: input.maxMarks,
      weight: input.weight,
      dueDate: input.dueDate ?? null,
      status: 'draft',
      submittedAt: null,
      createdBy: actor.id,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    db.assessments.push(assessment);
    this.writeAudit(actor, 'assessment.create', 'assessment', assessment.id, `Created assessment "${assessment.title}".`);
    persistDb(db);
    return assessment;
  }

  async updateAssessment(id: string, input: Partial<SaveAssessmentInput>): Promise<Assessment> {
    const actor = this.assertPermission('assessments.manage');
    const assessment = db.assessments.find((a) => a.id === id);
    if (!assessment) throw new Error('Assessment not found.');
    if (actor.role === 'teacher' && assessment.createdBy !== actor.id) {
      throw new Error('You can only edit assessments you created.');
    }
    if (assessment.status === 'submitted') {
      throw new Error('This assessment is locked (submitted). Ask an administrator to reopen it first.');
    }
    if (input.title !== undefined) assessment.title = input.title.trim();
    if (input.description !== undefined) assessment.description = input.description;
    if (input.type !== undefined) assessment.type = input.type;
    if (input.maxMarks !== undefined) {
      if (input.maxMarks <= 0) throw new Error('Maximum marks must be greater than zero.');
      assessment.maxMarks = input.maxMarks;
    }
    if (input.weight !== undefined) assessment.weight = input.weight;
    if (input.dueDate !== undefined) assessment.dueDate = input.dueDate;
    assessment.updatedAt = nowIso();
    this.writeAudit(actor, 'assessment.update', 'assessment', assessment.id, `Updated assessment "${assessment.title}".`);
    persistDb(db);
    return assessment;
  }

  async deleteAssessment(id: string): Promise<void> {
    const actor = this.assertPermission('assessments.manage');
    const assessment = db.assessments.find((a) => a.id === id);
    if (!assessment) throw new Error('Assessment not found.');
    if (actor.role === 'teacher' && assessment.createdBy !== actor.id) {
      throw new Error('You can only delete assessments you created.');
    }
    db.assessments = db.assessments.filter((a) => a.id !== id);
    db.marks = db.marks.filter((m) => m.assessmentId !== id);
    this.writeAudit(actor, 'assessment.delete', 'assessment', id, `Deleted assessment "${assessment.title}" and its marks.`);
    persistDb(db);
  }

  /* ------------------------------- marks -------------------------------- */

  private findAssessment(id: string): Assessment {
    const assessment = db.assessments.find((a) => a.id === id);
    if (!assessment) throw new Error('Assessment not found.');
    return assessment;
  }

  private canAccessAssessment(profile: Profile, assessment: Assessment): boolean {
    if (profile.role === 'admin') return true;
    if (profile.role !== 'teacher') return false;
    const teacher = this.teacherByProfile(profile.id);
    if (!teacher) return false;
    return db.assignments.some(
      (a) =>
        a.teacherId === teacher.id &&
        a.classSectionId === assessment.classSectionId &&
        a.subjectId === assessment.subjectId,
    );
  }

  async listMarks(assessmentId: string): Promise<Mark[]> {
    const { profile } = this.auth();
    const assessment = this.findAssessment(assessmentId);
    if (!this.canAccessAssessment(profile, assessment)) {
      throw new Error('You do not have access to this assessment.');
    }
    return db.marks.filter((m) => m.assessmentId === assessmentId);
  }

  async saveMarkDrafts(drafts: MarkDraftInput[]): Promise<Mark[]> {
    const { profile } = this.auth();
    if (profile.role !== 'teacher' && profile.role !== 'admin') {
      throw new Error('Only teachers can enter marks.');
    }
    const saved: Mark[] = [];
    for (const draft of drafts) {
      const assessment = this.findAssessment(draft.assessmentId);
      if (!this.canAccessAssessment(profile, assessment)) {
        throw new Error('You are not assigned to this class and subject.');
      }
      if (assessment.status !== 'draft') {
        throw new Error(`"${assessment.title}" is locked. Ask an administrator to reopen it before editing.`);
      }
      const validation = validateMarkScore(draft.score, assessment.maxMarks);
      if (!validation.ok) throw new Error(`${assessment.title}: ${validation.error}`);
      const enrolled = db.enrollments.some(
        (e) => e.studentId === draft.studentId && e.classSectionId === assessment.classSectionId && e.status === 'active',
      );
      if (!enrolled) throw new Error('That student is not enrolled in this class.');
      const existing = db.marks.find((m) => m.assessmentId === draft.assessmentId && m.studentId === draft.studentId);
      const timestamp = nowIso();
      if (existing) {
        existing.score = draft.score;
        existing.updatedAt = timestamp;
        saved.push(existing);
      } else {
        const mark: Mark = {
          id: uid('mk'),
          assessmentId: draft.assessmentId,
          studentId: draft.studentId,
          score: draft.score,
          status: 'draft',
          enteredBy: profile.id,
          createdAt: timestamp,
          updatedAt: timestamp,
        };
        db.marks.push(mark);
        saved.push(mark);
      }
    }
    persistDb(db);
    return saved;
  }

  async checkSubmissionReadiness(assessmentId: string): Promise<MarkSubmissionCheck> {
    this.auth();
    const assessment = this.findAssessment(assessmentId);
    const students = db.enrollments
      .filter((e) => e.classSectionId === assessment.classSectionId && e.status === 'active')
      .map((e) => db.students.find((s) => s.id === e.studentId))
      .filter((s): s is Student => Boolean(s));
    const marks = db.marks.filter((m) => m.assessmentId === assessmentId);
    const missing = students.filter((s) => {
      const mark = marks.find((m) => m.studentId === s.id);
      return !mark || mark.score === null;
    });
    return {
      ok: missing.length === 0,
      missing:
        missing.length === 0
          ? []
          : [
              {
                assessmentId: assessment.id,
                assessmentTitle: assessment.title,
                studentNames: missing.map((s) => s.fullName),
              },
            ],
    };
  }

  async submitAssessmentMarks(assessmentId: string): Promise<Assessment> {
    const { profile } = this.auth();
    const assessment = this.findAssessment(assessmentId);
    if (!this.canAccessAssessment(profile, assessment)) throw new Error('You do not have access to this assessment.');
    if (assessment.status !== 'draft') throw new Error('This assessment has already been submitted.');
    const readiness = await this.checkSubmissionReadiness(assessmentId);
    if (!readiness.ok) {
      const names = readiness.missing[0]?.studentNames.join(', ') ?? '';
      throw new Error(`Cannot submit: marks are missing for ${names}.`);
    }
    const timestamp = nowIso();
    assessment.status = 'submitted';
    assessment.submittedAt = timestamp;
    assessment.updatedAt = timestamp;
    for (const mark of db.marks.filter((m) => m.assessmentId === assessmentId)) {
      mark.status = 'submitted';
      mark.updatedAt = timestamp;
    }
    this.writeAudit(profile, 'marks.submit', 'assessment', assessmentId, `Submitted marks for "${assessment.title}".`);
    persistDb(db);
    return assessment;
  }

  async reopenAssessment(assessmentId: string): Promise<Assessment> {
    const profile = this.assertPermission('marks.review');
    const assessment = this.findAssessment(assessmentId);
    assessment.status = 'draft';
    assessment.submittedAt = null;
    assessment.updatedAt = nowIso();
    for (const mark of db.marks.filter((m) => m.assessmentId === assessmentId)) {
      mark.status = 'draft';
      mark.updatedAt = assessment.updatedAt;
    }
    this.writeAudit(profile, 'assessment.reopen', 'assessment', assessmentId, `Reopened "${assessment.title}" for editing.`);
    persistDb(db);
    return assessment;
  }

  async correctMark(input: {
    assessmentId: string;
    studentId: string;
    score: number | null;
    reason: string;
  }): Promise<Mark> {
    const profile = this.assertPermission('marks.correct');
    if (!input.reason || input.reason.trim().length < 5) {
      throw new Error('A correction reason of at least 5 characters is required.');
    }
    const assessment = this.findAssessment(input.assessmentId);
    const validation = validateMarkScore(input.score, assessment.maxMarks);
    if (!validation.ok) throw new Error(validation.error);
    const student = db.students.find((s) => s.id === input.studentId);
    if (!student) throw new Error('Student not found.');
    let mark = db.marks.find((m) => m.assessmentId === input.assessmentId && m.studentId === input.studentId);
    const previous = mark?.score ?? null;
    const timestamp = nowIso();
    if (mark) {
      mark.score = input.score;
      mark.updatedAt = timestamp;
    } else {
      mark = {
        id: uid('mk'),
        assessmentId: input.assessmentId,
        studentId: input.studentId,
        score: input.score,
        status: 'submitted',
        enteredBy: profile.id,
        createdAt: timestamp,
        updatedAt: timestamp,
      };
      db.marks.push(mark);
    }
    this.writeAudit(
      profile,
      'mark.correct',
      'mark',
      mark.id,
      `Corrected ${student.fullName}'s mark in "${assessment.title}" from ${previous ?? '—'} to ${input.score ?? '—'}.`,
      input.reason.trim(),
    );
    persistDb(db);
    return mark;
  }

  /* -------------------- results & publication workflow ------------------- */

  private publicationFor(classSectionId: string, termId: string): ResultPublication {
    let publication = db.publications.find((p) => p.classSectionId === classSectionId && p.termId === termId);
    if (!publication) {
      publication = { id: uid('pub'), classSectionId, termId, state: 'draft', updatedAt: nowIso() };
      db.publications.push(publication);
    }
    return publication;
  }

  async getPublication(classSectionId: string, termId: string): Promise<ResultPublication | null> {
    this.auth();
    return db.publications.find((p) => p.classSectionId === classSectionId && p.termId === termId) ?? null;
  }

  private classLabel(classSectionId: string): string {
    const c = db.classSections.find((x) => x.id === classSectionId);
    return c ? `${c.name} ${c.section}` : 'class';
  }

  private termLabel(termId: string): string {
    const t = db.terms.find((x) => x.id === termId);
    const y = t ? db.academicYears.find((x) => x.id === t.academicYearId) : null;
    return t ? `${t.name} ${y?.name ?? ''}`.trim() : 'term';
  }

  async getClassResultSheet(classSectionId: string, termId: string): Promise<ClassResultSheet> {
    const { profile } = this.auth();
    if (profile.role !== 'admin' && !this.isAssignedToClass(profile.id, classSectionId)) {
      throw new Error('You are not assigned to this class.');
    }
    const classSection = db.classSections.find((c) => c.id === classSectionId);
    const term = db.terms.find((t) => t.id === termId);
    if (!classSection || !term) throw new Error('Class or term not found.');
    const students = db.enrollments
      .filter((e) => e.classSectionId === classSectionId && e.status === 'active')
      .map((e) => db.students.find((s) => s.id === e.studentId))
      .filter((s): s is Student => Boolean(s))
      .sort((a, b) => a.fullName.localeCompare(b.fullName));
    const assessments = db.assessments
      .filter((a) => a.classSectionId === classSectionId && a.termId === termId)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const assessmentIds = new Set(assessments.map((a) => a.id));
    const marks = db.marks.filter((m) => assessmentIds.has(m.assessmentId));
    return {
      classSection,
      term,
      assessments,
      students,
      marks,
      publication: db.publications.find((p) => p.classSectionId === classSectionId && p.termId === termId) ?? null,
    };
  }

  async submitClassResults(classSectionId: string, termId: string): Promise<ResultPublication> {
    const { profile } = this.auth();
    if (profile.role !== 'admin' && !this.isAssignedToClass(profile.id, classSectionId)) {
      throw new Error('You can only submit results for classes you teach.');
    }
    const assessments = db.assessments.filter((a) => a.classSectionId === classSectionId && a.termId === termId);
    if (assessments.length === 0) throw new Error('There are no assessments to submit for this class and term.');
    const pending = assessments.filter((a) => a.status !== 'submitted');
    if (pending.length > 0) {
      throw new Error(`Cannot submit: these assessments are still drafts: ${pending.map((a) => a.title).join(', ')}.`);
    }
    const publication = this.publicationFor(classSectionId, termId);
    if (publication.state === 'published') throw new Error('These results are already published.');
    const timestamp = nowIso();
    publication.state = 'submitted';
    publication.submittedBy = profile.id;
    publication.submittedAt = timestamp;
    publication.updatedAt = timestamp;
    this.writeAudit(profile, 'results.submit', 'result_publication', publication.id, `Submitted ${this.classLabel(classSectionId)} ${this.termLabel(termId)} results for review.`);
    persistDb(db);
    return publication;
  }

  async approveClassResults(classSectionId: string, termId: string): Promise<ResultPublication> {
    const profile = this.assertPermission('marks.review');
    const publication = this.publicationFor(classSectionId, termId);
    if (publication.state !== 'submitted') {
      throw new Error('Only submitted results can be approved. Submit the marks first.');
    }
    const timestamp = nowIso();
    publication.state = 'approved';
    publication.approvedBy = profile.id;
    publication.approvedAt = timestamp;
    publication.updatedAt = timestamp;
    this.writeAudit(profile, 'results.approve', 'result_publication', publication.id, `Approved ${this.classLabel(classSectionId)} ${this.termLabel(termId)} results.`);
    persistDb(db);
    return publication;
  }

  async publishClassResults(classSectionId: string, termId: string): Promise<ResultPublication> {
    const profile = this.assertPermission('results.publish');
    const publication = this.publicationFor(classSectionId, termId);
    if (publication.state !== 'approved') {
      throw new Error('Only approved results can be published. Approve them first.');
    }
    const timestamp = nowIso();
    publication.state = 'published';
    publication.publishedBy = profile.id;
    publication.publishedAt = timestamp;
    publication.updatedAt = timestamp;
    this.writeAudit(profile, 'results.publish', 'result_publication', publication.id, `Published ${this.classLabel(classSectionId)} ${this.termLabel(termId)} results for students and parents.`);
    persistDb(db);
    return publication;
  }

  /* --------------------------- result building --------------------------- */

  private computeSubjectResultsFor(studentId: string, classSectionId: string, termId: string): SubjectResult[] {
    const assessments = db.assessments.filter((a) => a.classSectionId === classSectionId && a.termId === termId);
    const assessmentIds = new Set(assessments.map((a) => a.id));
    const uniqueSubjectIds = [...new Set(assessments.map((a) => a.subjectId))];
    const results: SubjectResult[] = [];
    for (const subjectId of uniqueSubjectIds) {
      const subject = db.subjects.find((s) => s.id === subjectId);
      if (!subject) continue;
      const subjectAssessments = assessments
        .filter((a) => a.subjectId === subjectId)
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      const marks = db.marks.filter((m) => m.studentId === studentId && assessmentIds.has(m.assessmentId));
      const assignment = db.assignments.find((a) => a.classSectionId === classSectionId && a.subjectId === subjectId);
      const teacherName = assignment ? db.teachers.find((t) => t.id === assignment.teacherId)?.fullName ?? null : null;
      results.push(computeSubjectResult({ subject, assessments: subjectAssessments, marks, teacherName }));
    }
    return results.sort((a, b) => a.subjectName.localeCompare(b.subjectName));
  }

  private rankInClass(classSectionId: string, termId: string, studentId: string): { rank: number | null; size: number } {
    const classmates = db.enrollments
      .filter((e) => e.classSectionId === classSectionId && e.status === 'active')
      .map((e) => e.studentId);
    const percentages = new Map<string, number>();
    for (const sid of classmates) {
      const subjects = this.computeSubjectResultsFor(sid, classSectionId, termId);
      const summary = summarizeSubjects(subjects, db.gradingScale);
      percentages.set(sid, summary.weightedOverallPercentage ?? summary.overallPercentage);
    }
    return { rank: rankByPercentages(percentages, studentId), size: classmates.length };
  }

  private computeTermResult(studentId: string, termId: string): TermResult | null {
    const student = db.students.find((s) => s.id === studentId);
    const term = db.terms.find((t) => t.id === termId);
    if (!student || !term) return null;
    const year = db.academicYears.find((y) => y.id === term.academicYearId);
    const enrollment = db.enrollments
      .filter((e) => e.studentId === studentId && e.academicYearId === term.academicYearId && e.status === 'active')
      .sort((a, b) => b.enrolledAt.localeCompare(a.enrolledAt))[0];
    if (!enrollment || !year) return null;
    const subjects = this.computeSubjectResultsFor(studentId, enrollment.classSectionId, termId);
    const summary = summarizeSubjects(subjects, db.gradingScale);
    const { rank, size } = this.rankInClass(enrollment.classSectionId, termId, studentId);
    const publication = db.publications.find(
      (p) => p.classSectionId === enrollment.classSectionId && p.termId === termId,
    );
    return {
      studentId: student.id,
      studentName: student.fullName,
      studentNumber: student.studentId,
      classSectionId: enrollment.classSectionId,
      classSectionName: this.classLabel(enrollment.classSectionId),
      termId: term.id,
      termName: term.name,
      academicYearName: year.name,
      state: publication?.state ?? 'draft',
      subjects,
      totalObtained: summary.totalObtained,
      totalMaximum: summary.totalMaximum,
      overallPercentage: summary.overallPercentage,
      weightedOverallPercentage: summary.weightedOverallPercentage,
      overallGrade: summary.overallGrade,
      classSize: size,
      rank,
      generatedAt: nowIso(),
    };
  }

  async listResultSummaries(classSectionId: string, termId: string): Promise<TermResult[]> {
    const { profile } = this.auth();
    if (profile.role !== 'admin' && !this.isAssignedToClass(profile.id, classSectionId)) {
      throw new Error('You can only view results for classes you teach.');
    }
    const studentIds = db.enrollments
      .filter((e) => e.classSectionId === classSectionId && e.status === 'active')
      .map((e) => e.studentId);
    return studentIds
      .map((id) => this.computeTermResult(id, termId))
      .filter((r): r is TermResult => r !== null)
      .sort((a, b) =>
        a.rank !== null && b.rank !== null ? a.rank - b.rank : a.studentName.localeCompare(b.studentName),
      );
  }

  async getPublishedResult(studentId: string, termId: string): Promise<TermResult | null> {
    const { profile } = this.auth();
    if (profile.role === 'student') {
      const me = this.studentByProfile(profile.id);
      if (!me || me.id !== studentId) throw new Error('You can only view your own results.');
    } else if (profile.role === 'parent') {
      if (!this.childrenOf(profile.id).some((s) => s.id === studentId)) {
        throw new Error('You can only view results of your linked children.');
      }
    } else if (profile.role === 'teacher') {
      const classId = this.activeClassOf(studentId);
      if (!classId || !this.isAssignedToClass(profile.id, classId)) {
        throw new Error('You can only view results for classes you teach.');
      }
    }
    const term = db.terms.find((t) => t.id === termId);
    if (!term) return null;
    const enrollment = db.enrollments
      .filter((e) => e.studentId === studentId && e.academicYearId === term.academicYearId && e.status === 'active')
      .sort((a, b) => b.enrolledAt.localeCompare(a.enrolledAt))[0];
    if (!enrollment) return null;
    const publication = db.publications.find(
      (p) => p.classSectionId === enrollment.classSectionId && p.termId === termId,
    );
    // Unpublished results are never exposed to students, parents or teachers.
    if (!publication || publication.state !== 'published') return null;
    return this.computeTermResult(studentId, termId);
  }

  /* ---------------------------- grading scale ---------------------------- */

  async getGradingScale(): Promise<GradingScale> {
    this.auth();
    return db.gradingScale;
  }

  async updateGradingScale(scale: GradingScale): Promise<GradingScale> {
    const profile = this.assertPermission('academics.manage');
    if (scale.boundaries.length === 0) throw new Error('The grading scale needs at least one grade boundary.');
    db.gradingScale = { ...scale, isPlaceholder: false };
    this.writeAudit(profile, 'grading.update', 'grading_scale', scale.id, `Updated the grading scale to "${scale.name}".`);
    persistDb(db);
    return db.gradingScale;
  }

  /* ------------------------------- notices ------------------------------- */

  private audienceVisibleTo(audience: Notice['audience'], role: Role): boolean {
    switch (audience) {
      case 'public':
      case 'authenticated':
        return true;
      case 'staff':
        return role === 'admin' || role === 'teacher';
      case 'students':
        return role === 'student';
      case 'parents':
        return role === 'parent';
      default:
        return false;
    }
  }

  async listNotices(filter?: {
    audience?: Notice['audience'] | 'all';
    status?: Notice['status'];
    search?: string;
  }): Promise<Notice[]> {
    const now = Date.now();
    const session = this.session;
    let pool: Notice[];
    if (!session) {
      // Public website visitors: published, unexpired, public audience only.
      pool = db.notices.filter(
        (n) =>
          n.status === 'published' &&
          n.audience === 'public' &&
          (!n.expiresAt || new Date(n.expiresAt).getTime() >= now),
      );
    } else {
      const role = session.profile.role;
      if (role === 'admin') {
        pool = db.notices.filter((n) => {
          if (filter?.status) return n.status === filter.status;
          return n.status !== 'draft' || true; // admins manage every notice
        });
        if (filter?.audience && filter.audience !== 'all') {
          pool = pool.filter((n) => n.audience === filter.audience);
        }
      } else {
        pool = db.notices.filter(
          (n) =>
            n.status === 'published' &&
            this.audienceVisibleTo(n.audience, role) &&
            (!n.expiresAt || new Date(n.expiresAt).getTime() >= now),
        );
      }
    }
    return pool
      .filter((n) => !filter?.search || n.title.toLowerCase().includes(filter.search.toLowerCase()))
      .sort((a, b) => (b.publishedAt ?? b.createdAt).localeCompare(a.publishedAt ?? a.createdAt));
  }

  async createNotice(input: SaveNoticeInput): Promise<Notice> {
    const profile = this.assertPermission('notices.manage');
    const timestamp = nowIso();
    const notice: Notice = {
      id: uid('not'),
      title: input.title.trim(),
      body: input.body.trim(),
      category: input.category,
      audience: input.audience,
      status: input.publishedAt ? 'published' : 'draft',
      publishedAt: input.publishedAt ?? null,
      expiresAt: input.expiresAt ?? null,
      authorName: profile.fullName,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    db.notices.push(notice);
    this.writeAudit(profile, 'notice.create', 'notice', notice.id, `Created notice "${notice.title}" (${notice.audience}).`);
    persistDb(db);
    return notice;
  }

  async updateNotice(id: string, input: Partial<SaveNoticeInput>): Promise<Notice> {
    const profile = this.assertPermission('notices.manage');
    const notice = db.notices.find((n) => n.id === id);
    if (!notice) throw new Error('Notice not found.');
    if (input.title !== undefined) notice.title = input.title.trim();
    if (input.body !== undefined) notice.body = input.body.trim();
    if (input.category !== undefined) notice.category = input.category;
    if (input.audience !== undefined) notice.audience = input.audience;
    if (input.publishedAt !== undefined) notice.publishedAt = input.publishedAt;
    if (input.expiresAt !== undefined) notice.expiresAt = input.expiresAt;
    notice.updatedAt = nowIso();
    this.writeAudit(profile, 'notice.update', 'notice', notice.id, `Updated notice "${notice.title}".`);
    persistDb(db);
    return notice;
  }

  async setNoticeStatus(id: string, status: Notice['status']): Promise<Notice> {
    const profile = this.assertPermission('notices.manage');
    const notice = db.notices.find((n) => n.id === id);
    if (!notice) throw new Error('Notice not found.');
    notice.status = status;
    if (status === 'published' && !notice.publishedAt) notice.publishedAt = nowIso();
    notice.updatedAt = nowIso();
    this.writeAudit(profile, `notice.${status}`, 'notice', notice.id, `Set notice "${notice.title}" to ${status}.`);
    persistDb(db);
    return notice;
  }

  /* ------------------------------ dashboard ------------------------------ */

  async getDashboardStats() {
    this.assertPermission('dashboard.view.admin');
    return {
      students: db.students.filter((s) => s.status === 'active').length,
      teachers: db.teachers.filter((t) => t.status === 'active').length,
      classes: db.classSections.length,
      subjects: db.subjects.length,
      pendingApprovals: db.publications.filter((p) => p.state === 'submitted').length,
      publishedTerms: db.publications.filter((p) => p.state === 'published').length,
      publishedNotices: db.notices.filter((n) => n.status === 'published').length,
    };
  }

  /* ---------------------------- public intake ---------------------------- */

  async submitContactMessage(input: {
    name: string;
    email: string;
    phone?: string | null;
    subject: string;
    message: string;
  }): Promise<void> {
    db.contactMessages.push({
      id: uid('msg'),
      name: input.name.trim(),
      email: input.email.trim(),
      phone: input.phone ?? null,
      subject: input.subject.trim(),
      message: input.message.trim(),
      createdAt: nowIso(),
    });
    persistDb(db);
  }

  async submitAdmissionEnquiry(input: {
    childName: string;
    gradeApplying: string;
    parentName: string;
    email: string;
    phone: string;
    notes?: string | null;
  }): Promise<void> {
    db.admissionEnquiries.push({
      id: uid('enq'),
      childName: input.childName.trim(),
      gradeApplying: input.gradeApplying.trim(),
      parentName: input.parentName.trim(),
      email: input.email.trim(),
      phone: input.phone.trim(),
      notes: input.notes ?? null,
      createdAt: nowIso(),
    });
    persistDb(db);
  }
}
