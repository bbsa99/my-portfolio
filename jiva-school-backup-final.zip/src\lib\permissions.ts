import type { Role } from './types';

/**
 * Central role/permission matrix.
 *
 * This drives the UI (navigation, buttons, route guards). It is NOT the sole
 * security boundary: Supabase Row Level Security policies in
 * `supabase/migrations` enforce the same rules on the server, and the local
 * demo repository mirrors them in application code. UI checks alone are
 * never sufficient security.
 */
export type Permission =
  | 'students.manage'
  | 'staff.manage'
  | 'academics.manage'
  | 'enrollments.manage'
  | 'assessments.manage'
  | 'marks.enter'
  | 'marks.review'
  | 'marks.correct'
  | 'results.publish'
  | 'results.view.assigned'
  | 'results.view.own'
  | 'results.view.children'
  | 'notices.manage'
  | 'notices.view.private'
  | 'accounts.manage'
  | 'audit.view'
  | 'reports.export'
  | 'dashboard.view.admin'
  | 'dashboard.view.teacher'
  | 'dashboard.view.student'
  | 'dashboard.view.parent';

const MATRIX: Record<Role, ReadonlySet<Permission>> = {
  admin: new Set<Permission>([
    'students.manage',
    'staff.manage',
    'academics.manage',
    'enrollments.manage',
    'assessments.manage',
    'marks.review',
    'marks.correct',
    'results.publish',
    'notices.manage',
    'notices.view.private',
    'accounts.manage',
    'audit.view',
    'reports.export',
    'dashboard.view.admin',
  ]),
  teacher: new Set<Permission>([
    'assessments.manage',
    'marks.enter',
    'results.view.assigned',
    'notices.view.private',
    'dashboard.view.teacher',
  ]),
  student: new Set<Permission>(['results.view.own', 'notices.view.private', 'dashboard.view.student']),
  parent: new Set<Permission>(['results.view.children', 'notices.view.private', 'dashboard.view.parent']),
};

export function can(role: Role | undefined | null, permission: Permission): boolean {
  if (!role) return false;
  return MATRIX[role].has(permission);
}

export function permissionsFor(role: Role): Permission[] {
  return [...MATRIX[role]];
}

/** Where a role lands after signing in (inside the authenticated /app shell). */
export const HOME_BY_ROLE: Record<Role, string> = {
  admin: '/app/admin',
  teacher: '/app/teacher',
  student: '/app/student',
  parent: '/app/parent',
};

export const ROLE_LABELS: Record<Role, string> = {
  admin: 'Administrator',
  teacher: 'Teacher',
  student: 'Student',
  parent: 'Parent',
};
