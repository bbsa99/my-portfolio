import { Link } from 'react-router-dom';
import { schoolName } from '../../lib/env';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { PageSpinner } from '../../components/ui/Spinner';
import { Alert } from '../../components/ui/Alert';
import { ProgressiveImage } from '../../components/ui/ProgressiveImage';
import { useAsync } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';

const STAGES = [
  {
    title: 'Early years (Grades 1–2)',
    body: 'Play-based foundations in literacy and numeracy, building curiosity, confidence and good learning habits.',
  },
  {
    title: 'Primary (Grades 3–6)',
    body: 'A broad core curriculum with growing specialism, regular assessment and rich co-curricular activities.',
  },
  {
    title: 'Middle school (Grades 7–8)',
    body: 'Subject specialists deepen knowledge and independent study skills in preparation for senior school.',
  },
];

/** Public academics overview — reads the school's subjects from the repository. */
export function PublicAcademics() {
  const repo = useRepo();
  const { data: subjects, loading, error } = useAsync(() => repo.listSubjects(), [repo]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-14">
      <h1 className="text-3xl font-semibold text-ink-900">Academics at {schoolName}</h1>
      <p className="mt-3 max-w-2xl text-ink-500">
        Our curriculum blends rigorous core subjects with the arts, physical education and technology, supported by
        continuous assessment and clear reporting to families.
      </p>

      <ProgressiveImage
        src="/images/classroom.jpg"
        alt="Students learning together in a bright, modern classroom"
        wrapperClassName="mt-8 aspect-[21/9] w-full rounded-2xl"
      />

      <div className="mt-10 grid gap-5 sm:grid-cols-3">
        {STAGES.map((stage) => (
          <Card key={stage.title}>
            <CardBody>
              <h2 className="text-base font-semibold text-ink-900">{stage.title}</h2>
              <p className="mt-2 text-sm text-ink-500">{stage.body}</p>
            </CardBody>
          </Card>
        ))}
      </div>

      <Card className="mt-10">
        <CardHeader title="Subjects offered" subtitle="The core and foundation subjects taught across the school." />
        <CardBody>
          {loading && <PageSpinner />}
          {error && <Alert variant="danger">{error}</Alert>}
          {subjects && subjects.length === 0 && <p className="text-sm text-ink-500">Subject list coming soon.</p>}
          {subjects && subjects.length > 0 && (
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {subjects.map((subject) => (
                <li key={subject.id} className="flex items-center justify-between rounded-lg border border-ink-200 px-3 py-2">
                  <div>
                    <p className="text-sm font-medium text-ink-800">{subject.name}</p>
                    <p className="text-xs text-ink-400">{subject.code}</p>
                  </div>
                  {subject.isCore ? <Badge tone="brand">Core</Badge> : <Badge>Elective</Badge>}
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>

      <p className="mt-8 text-sm text-ink-500">
        Questions about our curriculum?{' '}
        <Link to="/contact" className="font-medium text-brand-700 hover:text-brand-800">
          Get in touch
        </Link>
        .
      </p>
    </div>
  );
}
