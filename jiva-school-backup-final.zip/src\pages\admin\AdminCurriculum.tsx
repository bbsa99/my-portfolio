import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { formatDate } from '../../lib/utils';
import { classSectionSchema, subjectSchema } from '../../lib/validation';
import type { AcademicYear, ClassSection, Subject, Teacher, TeacherAssignment, Term } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageSpinner } from '../../components/ui/Spinner';
import { useToast } from '../../components/Toast';
import { cn } from '../../lib/utils';

type Tab = 'classes' | 'subjects' | 'calendar' | 'assignments';

const TABS: Array<{ key: Tab; label: string }> = [
  { key: 'classes', label: 'Classes' },
  { key: 'subjects', label: 'Subjects' },
  { key: 'calendar', label: 'Academic calendar' },
  { key: 'assignments', label: 'Teacher assignments' },
];

interface CurriculumData {
  classes: ClassSection[];
  subjects: Subject[];
  years: AcademicYear[];
  terms: Term[];
  teachers: Teacher[];
  assignments: TeacherAssignment[];
}

/** Admin curriculum manager: classes, subjects, calendar and assignments. */
export function AdminCurriculum() {
  const repo = useRepo();
  const [tab, setTab] = useState<Tab>('classes');

  const { data, loading, error, reload } = useAsync<CurriculumData>(async () => {
    const [classes, subjects, years, terms, teachersPage, assignments] = await Promise.all([
      repo.listClassSections(),
      repo.listSubjects(),
      repo.listAcademicYears(),
      repo.listTerms(),
      repo.listTeachers({ pageSize: 100 }),
      repo.listTeacherAssignments(),
    ]);
    return { classes, subjects, years, terms, teachers: teachersPage.items, assignments };
  }, [repo]);

  return (
    <div>
      <PageHeader title="Curriculum" subtitle="Classes, subjects, the academic calendar and teaching assignments." />

      <div className="mb-6 flex flex-wrap gap-1 border-b border-ink-200">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={cn(
              '-mb-px border-b-2 px-4 py-2 text-sm font-medium transition-colors',
              tab === t.key ? 'border-brand-600 text-brand-700' : 'border-transparent text-ink-500 hover:text-ink-800',
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading && <PageSpinner />}
      {error && <Alert variant="danger">{error}</Alert>}

      {data && (
        <>
          {tab === 'classes' && <ClassesTab classes={data.classes} reload={reload} />}
          {tab === 'subjects' && <SubjectsTab subjects={data.subjects} reload={reload} />}
          {tab === 'calendar' && <CalendarTab years={data.years} terms={data.terms} reload={reload} />}
          {tab === 'assignments' && (
            <AssignmentsTab
              assignments={data.assignments}
              classes={data.classes}
              subjects={data.subjects}
              teachers={data.teachers}
              years={data.years}
              reload={reload}
            />
          )}
        </>
      )}
    </div>
  );
}

/* ------------------------------- Classes tab ------------------------------ */

function ClassesTab({ classes, reload }: { classes: ClassSection[]; reload: () => void }) {
  const repo = useRepo();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', section: '', gradeLevel: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function create() {
    const parsed = classSectionSchema.safeParse({ ...form, gradeLevel: Number(form.gradeLevel) });
    if (!parsed.success) {
      const fe: Record<string, string> = {};
      for (const issue of parsed.error.issues) fe[String(issue.path[0])] = issue.message;
      setErrors(fe);
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      await repo.createClassSection(parsed.data);
      toast.push('success', 'Class created.');
      setOpen(false);
      setForm({ name: '', section: '', gradeLevel: '' });
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader
        title="Classes & sections"
        subtitle="Class sections group students for a grade level."
        action={
          <Button size="sm" onClick={() => setOpen(true)}>
            + Add class
          </Button>
        }
      />
      <CardBody>
        {classes.length === 0 ? (
          <p className="text-sm text-ink-500">No classes yet.</p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {classes.map((c) => (
              <li key={c.id} className="rounded-lg border border-ink-200 px-3 py-2">
                <p className="text-sm font-medium text-ink-800">
                  {c.name} {c.section}
                </p>
                <p className="text-xs text-ink-400">Grade level {c.gradeLevel}</p>
              </li>
            ))}
          </ul>
        )}
      </CardBody>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Add class"
        footer={
          <>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void create()}>
              Create class
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input label="Class name" placeholder="e.g. Grade 7" value={form.name} error={errors.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Section" placeholder="e.g. A" value={form.section} error={errors.section} onChange={(e) => setForm({ ...form, section: e.target.value })} required />
            <Input label="Grade level" type="number" min={1} max={12} value={form.gradeLevel} error={errors.gradeLevel} onChange={(e) => setForm({ ...form, gradeLevel: e.target.value })} required />
          </div>
        </div>
      </Modal>
    </Card>
  );
}

/* ------------------------------ Subjects tab ------------------------------ */

function SubjectsTab({ subjects, reload }: { subjects: Subject[]; reload: () => void }) {
  const repo = useRepo();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ code: '', name: '', isCore: true });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function create() {
    const parsed = subjectSchema.safeParse(form);
    if (!parsed.success) {
      const fe: Record<string, string> = {};
      for (const issue of parsed.error.issues) fe[String(issue.path[0])] = issue.message;
      setErrors(fe);
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      await repo.createSubject(parsed.data);
      toast.push('success', 'Subject created.');
      setOpen(false);
      setForm({ code: '', name: '', isCore: true });
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader
        title="Subjects"
        subtitle="The subjects taught across the school."
        action={
          <Button size="sm" onClick={() => setOpen(true)}>
            + Add subject
          </Button>
        }
      />
      <CardBody>
        {subjects.length === 0 ? (
          <p className="text-sm text-ink-500">No subjects yet.</p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {subjects.map((s) => (
              <li key={s.id} className="flex items-center justify-between rounded-lg border border-ink-200 px-3 py-2">
                <div>
                  <p className="text-sm font-medium text-ink-800">{s.name}</p>
                  <p className="text-xs text-ink-400">{s.code}</p>
                </div>
                {s.isCore ? <Badge tone="brand">Core</Badge> : <Badge>Elective</Badge>}
              </li>
            ))}
          </ul>
        )}
      </CardBody>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Add subject"
        footer={
          <>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void create()}>
              Create subject
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input label="Subject code" placeholder="e.g. MATH" value={form.code} error={errors.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required />
          <Input label="Subject name" placeholder="e.g. Mathematics" value={form.name} error={errors.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input type="checkbox" checked={form.isCore} onChange={(e) => setForm({ ...form, isCore: e.target.checked })} />
            Core subject
          </label>
        </div>
      </Modal>
    </Card>
  );
}


/* ------------------------------ Calendar tab ------------------------------ */

function CalendarTab({ years, terms, reload }: { years: AcademicYear[]; terms: Term[]; reload: () => void }) {
  const repo = useRepo();
  const toast = useToast();
  const [termOpen, setTermOpen] = useState(false);
  const [form, setForm] = useState({ academicYearId: '', name: '', order: '1', startDate: '', endDate: '' });
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function createTerm() {
    setFormError(null);
    if (!form.academicYearId || !form.name.trim()) {
      setFormError('Select an academic year and enter a term name.');
      return;
    }
    setSaving(true);
    try {
      await repo.createTerm({
        academicYearId: form.academicYearId,
        name: form.name.trim(),
        order: Number(form.order) || 1,
        startDate: form.startDate,
        endDate: form.endDate,
      });
      toast.push('success', 'Term created.');
      setTermOpen(false);
      setForm({ academicYearId: '', name: '', order: '1', startDate: '', endDate: '' });
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  function setCurrent(kind: 'year' | 'term', id: string, label: string) {
    const action = kind === 'year' ? repo.setCurrentAcademicYear(id) : repo.setCurrentTerm(id);
    void action
      .then(() => {
        toast.push('success', `${label} is now the current ${kind}.`);
        reload();
      })
      .catch((e: unknown) => toast.push('error', errMessage(e)));
  }


  return (
    <div className="space-y-6">
      <Card>
        <CardHeader title="Academic years" subtitle="The current year drives enrolments and assignments." />
        <CardBody>
          <ul className="space-y-2">
            {years.map((y) => (
              <li key={y.id} className="flex items-center justify-between rounded-lg border border-ink-200 px-3 py-2">
                <div>
                  <p className="text-sm font-medium text-ink-800">{y.name}</p>
                  <p className="text-xs text-ink-400">
                    {formatDate(y.startDate)} – {formatDate(y.endDate)}
                  </p>
                </div>
                {y.isCurrent ? (
                  <Badge tone="brand">Current</Badge>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => setCurrent('year', y.id, y.name)}>
                    Set current
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </CardBody>
      </Card>

      <Card>
        <CardHeader
          title="Terms"
          subtitle="Assessment and reporting periods."
          action={
            <Button size="sm" onClick={() => setTermOpen(true)} disabled={years.length === 0}>
              + Add term
            </Button>
          }
        />
        <CardBody>
          {terms.length === 0 ? (
            <p className="text-sm text-ink-500">No terms yet.</p>
          ) : (
            <ul className="space-y-2">
              {terms.map((t) => (
                <li key={t.id} className="flex items-center justify-between rounded-lg border border-ink-200 px-3 py-2">
                  <div>
                    <p className="text-sm font-medium text-ink-800">{t.name}</p>
                    <p className="text-xs text-ink-400">
                      {formatDate(t.startDate)} – {formatDate(t.endDate)}
                    </p>
                  </div>
                  {t.isCurrent ? (
                    <Badge tone="brand">Current</Badge>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => setCurrent('term', t.id, t.name)}>
                      Set current
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>

      <Modal
        open={termOpen}
        onClose={() => setTermOpen(false)}
        title="Add term"
        footer={
          <>
            <Button variant="outline" onClick={() => setTermOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void createTerm()}>
              Create term
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Select label="Academic year" value={form.academicYearId} onChange={(e) => setForm({ ...form, academicYearId: e.target.value })} required>
            <option value="">Select a year…</option>
            {years.map((y) => (
              <option key={y.id} value={y.id}>
                {y.name}
              </option>
            ))}
          </Select>
          <Input label="Term name" placeholder="e.g. Term 1" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <div className="grid gap-4 sm:grid-cols-3">
            <Input label="Order" type="number" min={1} value={form.order} onChange={(e) => setForm({ ...form, order: e.target.value })} />
            <Input label="Start date" type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            <Input label="End date" type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
          </div>
        </div>
      </Modal>
    </div>
  );
}


/* ---------------------------- Assignments tab ----------------------------- */

function AssignmentsTab({
  assignments,
  classes,
  subjects,
  teachers,
  years,
  reload,
}: {
  assignments: TeacherAssignment[];
  classes: ClassSection[];
  subjects: Subject[];
  teachers: Teacher[];
  years: AcademicYear[];
  reload: () => void;
}) {
  const repo = useRepo();
  const toast = useToast();
  const currentYear = years.find((y) => y.isCurrent) ?? years[0];
  const [form, setForm] = useState({ teacherId: '', classSectionId: '', subjectId: '' });
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const teacherName = (id: string) => teachers.find((t) => t.id === id)?.fullName ?? id;
  const subjectName = (id: string) => subjects.find((s) => s.id === id)?.name ?? id;
  const classLabel = (id: string) => {
    const c = classes.find((x) => x.id === id);
    return c ? `${c.name} ${c.section}` : id;
  };

  async function create() {
    if (!currentYear) {
      setFormError('Create an academic year first.');
      return;
    }
    if (!form.teacherId || !form.classSectionId || !form.subjectId) {
      setFormError('Select a teacher, class and subject.');
      return;
    }
    setFormError(null);
    setSaving(true);
    try {
      await repo.createTeacherAssignment({ ...form, academicYearId: currentYear.id });
      toast.push('success', 'Teacher assigned.');
      setForm({ teacherId: '', classSectionId: '', subjectId: '' });
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader title="Teacher assignments" subtitle="Which teacher teaches which subject in which class." />
      <CardBody className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-4">
          <Select label="Teacher" value={form.teacherId} onChange={(e) => setForm({ ...form, teacherId: e.target.value })}>
            <option value="">Select…</option>
            {teachers.map((t) => (
              <option key={t.id} value={t.id}>
                {t.fullName}
              </option>
            ))}
          </Select>
          <Select label="Class" value={form.classSectionId} onChange={(e) => setForm({ ...form, classSectionId: e.target.value })}>
            <option value="">Select…</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} {c.section}
              </option>
            ))}
          </Select>
          <Select label="Subject" value={form.subjectId} onChange={(e) => setForm({ ...form, subjectId: e.target.value })}>
            <option value="">Select…</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
          <div className="flex items-end">
            <Button block loading={saving} onClick={() => void create()}>
              Assign
            </Button>
          </div>
        </div>

        {formError && <Alert variant="danger">{formError}</Alert>}

        {assignments.length === 0 ? (
          <p className="text-sm text-ink-500">No assignments yet.</p>
        ) : (
          <ul className="divide-y divide-ink-100">
            {assignments.map((a) => (
              <li key={a.id} className="flex items-center justify-between py-2 text-sm">
                <span className="text-ink-700">
                  <span className="font-medium text-ink-900">{teacherName(a.teacherId)}</span> · {subjectName(a.subjectId)} ·{' '}
                  {classLabel(a.classSectionId)}
                </span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    void repo
                      .deleteTeacherAssignment(a.id)
                      .then(() => {
                        toast.push('success', 'Assignment removed.');
                        reload();
                      })
                      .catch((e: unknown) => toast.push('error', errMessage(e)));
                  }}
                >
                  Remove
                </Button>
              </li>
            ))}
          </ul>
        )}
      </CardBody>
    </Card>
  );
}

