import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { ResultCard } from '../../components/ResultCard';
import type { Student, Term, TermResult } from '../../lib/types';

/** Student view of their own published term results. */
export function StudentResults() {
  const repo = useRepo();
  const [termId, setTermId] = useState('');

  const base = useAsync<{ me: Student | null; terms: Term[] }>(async () => {
    const [students, terms] = await Promise.all([repo.listStudents({ pageSize: 1 }), repo.listTerms()]);
    return { me: students.items[0] ?? null, terms };
  }, [repo]);

  const result = useAsync<TermResult | null>(
    async () => {
      if (!termId || !base.data?.me) return null;
      return repo.getPublishedResult(base.data.me.id, termId);
    },
    [repo, termId, base.data?.me?.id],
  );

  const currentTerm = base.data?.terms.find((t) => t.isCurrent) ?? base.data?.terms[0];

  return (
    <div>
      <PageHeader title="My results" subtitle="View your published term report cards." />

      {base.loading && <PageSpinner />}
      {base.error && <Alert variant="danger">{base.error}</Alert>}

      {base.data && (
        <Card className="mb-6">
          <CardBody>
            <Select
              label="Term"
              value={termId || currentTerm?.id || ''}
              onChange={(e) => setTermId(e.target.value)}
              className="max-w-xs"
            >
              {base.data.terms.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </Select>
          </CardBody>
        </Card>
      )}

      {termId !== '' || currentTerm ? (
        result.loading ? (
          <PageSpinner />
        ) : result.error ? (
          <Alert variant="danger">{errMessage(result.error)}</Alert>
        ) : result.data ? (
          <ResultCard result={result.data} />
        ) : (
          <EmptyState
            title="Results not published yet"
            description="Your results will appear here once your teachers submit them and the school publishes them."
          />
        )
      ) : null}
    </div>
  );
}
