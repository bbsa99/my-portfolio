import { useState, type FormEvent } from 'react';
import { schoolCity, schoolName } from '../../lib/env';
import { contactSchema, type ContactInput } from '../../lib/validation';
import { useRepo } from '../../state/useRepo';
import { errMessage } from '../../state/useAsync';
import { Button } from '../../components/ui/Button';
import { Input, Textarea } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Card, CardBody } from '../../components/ui/Card';
import { IconMail } from '../../components/ui/Icons';

/** Public contact page with an intake form that writes to the repository. */
export function PublicContact() {
  const repo = useRepo();
  const [form, setForm] = useState<ContactInput>({ name: '', email: '', phone: '', subject: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  function update<K extends keyof ContactInput>(key: K, value: ContactInput[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setFormError(null);
    const parsed = contactSchema.safeParse(form);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setBusy(true);
    try {
      await repo.submitContactMessage({
        name: parsed.data.name,
        email: parsed.data.email,
        phone: parsed.data.phone && parsed.data.phone.length > 0 ? parsed.data.phone : null,
        subject: parsed.data.subject,
        message: parsed.data.message,
      });
      setSent(true);
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-14">
      <h1 className="text-3xl font-semibold text-ink-900">Contact us</h1>
      <p className="mt-3 max-w-2xl text-ink-500">
        We'd love to hear from you. Send us a message and our office will respond during working hours.
      </p>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_1.3fr]">
        <div className="space-y-4">
          <Card>
            <CardBody>
              <h2 className="text-base font-semibold text-ink-900">School office</h2>
              <dl className="mt-3 space-y-2 text-sm text-ink-600">
                <div>
                  <dt className="font-medium text-ink-800">Address</dt>
                  <dd>{schoolCity}</dd>
                </div>
                <div>
                  <dt className="font-medium text-ink-800">Hours</dt>
                  <dd>Monday – Friday, 8:00 – 16:30</dd>
                </div>
                <div>
                  <dt className="font-medium text-ink-800">Email</dt>
                  <dd className="flex items-center gap-1.5">
                    <IconMail className="h-4 w-4 text-ink-400" />
                    office@{schoolName.split(' ')[0].toLowerCase()}.test
                  </dd>
                </div>
              </dl>
            </CardBody>
          </Card>
        </div>

        <Card className="p-6">
          {sent ? (
            <Alert variant="success" title="Message sent">
              Thank you for getting in touch — we'll be in contact shortly.
              <div className="mt-4">
                <Button variant="outline" onClick={() => setSent(false)}>
                  Send another message
                </Button>
              </div>
            </Alert>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-4">
              {formError && <Alert variant="danger">{formError}</Alert>}
              <Input
                label="Your name"
                value={form.name}
                error={errors.name}
                onChange={(e) => update('name', e.target.value)}
                required
              />
              <div className="grid gap-4 sm:grid-cols-2">
                <Input
                  label="Email"
                  type="email"
                  value={form.email}
                  error={errors.email}
                  onChange={(e) => update('email', e.target.value)}
                  required
                />
                <Input
                  label="Phone (optional)"
                  type="tel"
                  value={form.phone ?? ''}
                  error={errors.phone}
                  onChange={(e) => update('phone', e.target.value)}
                />
              </div>
              <Input
                label="Subject"
                value={form.subject}
                error={errors.subject}
                onChange={(e) => update('subject', e.target.value)}
                required
              />
              <Textarea
                label="Message"
                value={form.message}
                error={errors.message}
                onChange={(e) => update('message', e.target.value)}
                required
              />
              <Button type="submit" block loading={busy}>
                Send message
              </Button>
            </form>
          )}
        </Card>
      </div>
    </div>
  );
}
