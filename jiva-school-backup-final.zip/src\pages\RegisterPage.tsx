import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../state/AuthContext';
import { errMessage } from '../state/useAsync';
import { registerSchema } from '../lib/validation';
import { schoolName } from '../lib/env';
import { HOME_BY_ROLE } from '../lib/permissions';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { Card } from '../components/ui/Card';
import { IconGraduation } from '../components/ui/Icons';

/**
 * Self-service account creation. Limited to students and parents — staff
 * accounts are created by an administrator from the Accounts page.
 */
export function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'student' | 'parent'>('student');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setFormError(null);
    const parsed = registerSchema.safeParse({ fullName, email, password, confirm, role });
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = String(issue.path[0] ?? '');
        if (key && !fieldErrors[key]) fieldErrors[key] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setBusy(true);
    try {
      const session = await register(parsed.data);
      navigate(HOME_BY_ROLE[session.profile.role], { replace: true });
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink-50 px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-700 text-white">
            <IconGraduation className="h-7 w-7" />
          </span>
          <h1 className="mt-4 text-2xl font-semibold text-ink-900">Create your account</h1>
          <p className="mt-1 text-sm text-ink-500">Students and parents can sign up for {schoolName}.</p>
        </div>

        <Card className="p-6">
          <form onSubmit={onSubmit} noValidate className="space-y-4">
            {formError && <Alert variant="danger">{formError}</Alert>}
            <Input
              label="Full name"
              value={fullName}
              autoComplete="name"
              error={errors.fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
            />
            <Input
              label="Email address"
              type="email"
              value={email}
              autoComplete="email"
              error={errors.email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Select label="I am a" value={role} onChange={(e) => setRole(e.target.value === 'parent' ? 'parent' : 'student')}>
              <option value="student">Student</option>
              <option value="parent">Parent or guardian</option>
            </Select>
            <Input
              label="Password"
              type="password"
              value={password}
              autoComplete="new-password"
              error={errors.password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <Input
              label="Confirm password"
              type="password"
              value={confirm}
              autoComplete="new-password"
              error={errors.confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
            />
            <Button type="submit" block loading={busy}>
              Create account
            </Button>
          </form>
        </Card>

        <p className="mt-6 text-center text-sm text-ink-500">
          Already have an account?{' '}
          <Link to="/login" className="font-medium text-brand-700 hover:text-brand-800">
            Sign in
          </Link>
        </p>
        <p className="mt-2 text-center text-sm text-ink-500">
          <Link to="/" className="font-medium text-brand-700 hover:text-brand-800">
            ← Back to website
          </Link>
        </p>
      </div>
    </div>
  );
}
