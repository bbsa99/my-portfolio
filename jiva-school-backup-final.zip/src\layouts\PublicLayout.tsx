import { useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { schoolCity, schoolName } from '../lib/env';
import { cn } from '../lib/utils';
import { IconClose, IconGraduation, IconMenu } from '../components/ui/Icons';

const NAV = [
  { to: '/', label: 'Home' },
  { to: '/academics', label: 'Academics' },
  { to: '/admissions', label: 'Admissions' },
  { to: '/notices', label: 'Notices' },
  { to: '/contact', label: 'Contact' },
];

/** Public marketing + intake site shell. */
export function PublicLayout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="flex min-h-full flex-col bg-white">
      <header className="sticky top-0 z-30 border-b border-ink-100 bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-700 text-white">
              <IconGraduation className="h-5 w-5" />
            </span>
            <span className="leading-tight">
              <span className="block font-display text-lg font-semibold text-ink-900">{schoolName}</span>
              <span className="block text-xs text-ink-500">{schoolCity}</span>
            </span>
          </Link>

          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  cn(
                    'rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                    isActive ? 'bg-brand-50 text-brand-800' : 'text-ink-600 hover:bg-ink-50 hover:text-ink-900',
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="hidden md:block">
            <Link
              to="/login"
              className="inline-flex h-10 items-center rounded-lg bg-brand-700 px-4 text-sm font-medium text-white transition-colors hover:bg-brand-800"
            >
              Portal login
            </Link>
          </div>

          <button
            type="button"
            className="rounded-md p-2 text-ink-600 hover:bg-ink-100 md:hidden"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
          >
            {menuOpen ? <IconClose className="h-6 w-6" /> : <IconMenu className="h-6 w-6" />}
          </button>
        </div>

        {menuOpen && (
          <div className="border-t border-ink-100 px-4 py-3 md:hidden">
            <nav className="flex flex-col gap-1">
              {NAV.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === '/'}
                  onClick={() => setMenuOpen(false)}
                  className={() =>
                    cn(
                      'rounded-lg px-3 py-2 text-sm font-medium',
                      location.pathname === item.to ? 'bg-brand-50 text-brand-800' : 'text-ink-700 hover:bg-ink-50',
                    )
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <Link
                to="/login"
                onClick={() => setMenuOpen(false)}
                className="mt-2 inline-flex h-10 items-center justify-center rounded-lg bg-brand-700 px-4 text-sm font-medium text-white"
              >
                Portal login
              </Link>
            </nav>
          </div>
        )}
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t border-ink-100 bg-ink-50">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <p className="font-display text-lg font-semibold text-ink-900">{schoolName}</p>
              <p className="mt-2 text-sm text-ink-500">{schoolCity}</p>
            </div>
            <div>
              <p className="text-sm font-semibold text-ink-800">Explore</p>
              <ul className="mt-3 space-y-2 text-sm text-ink-600">
                {NAV.map((item) => (
                  <li key={item.to}>
                    <Link to={item.to} className="hover:text-brand-700">
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-sm font-semibold text-ink-800">Portals</p>
              <ul className="mt-3 space-y-2 text-sm text-ink-600">
                <li>
                  <Link to="/login" className="hover:text-brand-700">
                    Sign in
                  </Link>
                </li>
                <li>
                  <Link to="/forgot-password" className="hover:text-brand-700">
                    Reset password
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <p className="text-sm font-semibold text-ink-800">About</p>
              <p className="mt-3 text-sm text-ink-500">
                A modern school management portal for students, teachers, parents and administrators.
              </p>
            </div>
          </div>
          <div className="mt-8 border-t border-ink-200 pt-6 text-xs text-ink-400">
            &copy; {new Date().getFullYear()} {schoolName}. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
