﻿import type {
  AcademicYear,
  Assessment,
  AssessmentType,
  AuditLog,
  ClassSection,
  DashboardStats,
  Enrollment,
  GradingScale,
  Mark,
  Notice,
  NoticeAudience,
  NoticeCategory,
  NoticeStatus,
  Parent,
  ParentStudentLink,
  Profile,
  ResultPublication,
  Role,
  Session,
  Subject,
  Teacher,
  TeacherAssignment,
  Term,
  TermResult,
  Student,
  StudentStatus,
} from '../types';

/* ----------------------------- shared DTOs ----------------------------- */

export interface PageFilter {
  search?: string;
  page?: number;
  pageSize?: number;
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export function paginate<T>(items: T[], filter?: PageFilter): Paginated<T> {
  const pageSize = Math.max(1, filter?.pageSize ?? 10);
  const page = Math.max(1, filter?.page ?? 1);
  const start = (page - 1) * pageSize;
  return { items: items.slice(start, start + pageSize), total: items.length, page, pageSize };
}

export function matchesSearch(search: string | undefined, ...fields: Array<string | null | undefined>): boolean {
  if (!search || !search.trim()) return true;
  const needle = search.trim().toLowerCase();
  return fields.some((f) => (f ?? '').toLowerCase().includes(needle));
}

export interface CreateStudentInput {
  fullName: string;
  dateOfBirth?: string | null;
  gender?: 'male' | 'female' | 'other' | null;
  admissionDate?: string | null;
  guardianName?: string | null;
  guardianPhone?: string | null;
  address?: string | null;
  status: StudentStatus;
  /** Optional: enrol straight into a class for the current year. */
  classSectionId?: string | null;
}

export interface CreateTeacherInput {
  fullName: string;
  employeeNo: string;
  phone?: string | null;
  email?: string | null;
  status?: 'active' | 'inactive';
}

export interface SaveAssessmentInput {
  title: string;
  description?: string | null;
  type: AssessmentType;
  classSectionId: string;
  subjectId: string;
  termId: string;
  maxMarks: number;
  weight: number;
  dueDate?: string | null;
}

export interface SaveNoticeInput {
  title: string;
  body: string;
  category: NoticeCategory;
  audience: NoticeAudience;
  publishedAt?: string | null;
  expiresAt?: string | null;
}

export interface CreateAccountInput {
  email: string;
  fullName: string;
  role: Role;
  /** Initial password chosen by the admin; hashed before it is persisted. */
  password: string;
  /** Link the new auth user to an existing person record. */
  studentId?: string | null;
  teacherId?: string | null;
  parentId?: string | null;
}

/** Self-service sign-up — limited to students and parents. */
export interface RegisterInput {
  email: string;
  fullName: string;
  password: string;
  role: 'student' | 'parent';
}

export interface MarkDraftInput {
  assessmentId: string;
  studentId: string;
  score: number | null;
}

/** Marks grid for admin review of a class + term. */
export interface ClassResultSheet {
  classSection: ClassSection;
  term: Term;
  assessments: Assessment[];
  students: Student[];
  marks: Mark[];
  publication: ResultPublication | null;
}

export interface MarkSubmissionCheck {
  ok: boolean;
  missing: Array<{ assessmentId: string; assessmentTitle: string; studentNames: string[] }>;
}

/* ------------------------------ repository ------------------------------ */

/**
 * The SchoolRepository is the single data boundary of the application.
 * Implementations:
 *  - `LocalRepository` (demo): in-memory/localStorage store with fictional
 *    seed data and application-level guards that mirror the RLS policies.
 *  - `SupabaseRepository`: talks to a real Supabase project; authorization
 *    is enforced by Postgres Row Level Security + RPC functions.
 */
export interface SchoolRepository {
  /* auth */
  getSession(): Session | null;
  subscribe(callback: (session: Session | null) => void): () => void;
  signIn(email: string, password: string): Promise<Session>;
  signOut(): Promise<void>;
  requestPasswordReset(email: string): Promise<void>;
  /** Self-service sign-up (student/parent only); returns an active session. */
  register(input: RegisterInput): Promise<Session>;
  /** Admin action: replace an account's password (hashed before storage). */
  resetPassword(profileId: string, newPassword: string): Promise<void>;

  /* accounts & audit (admin) */
  listAccounts(filter?: PageFilter): Promise<Paginated<Profile>>;
  createAccount(input: CreateAccountInput): Promise<Profile>;
  updateAccountRole(profileId: string, role: Role): Promise<Profile>;
  listAuditLogs(filter?: PageFilter): Promise<Paginated<AuditLog>>;

  /* students */
  listStudents(
    filter?: PageFilter & { classSectionId?: string; status?: StudentStatus },
  ): Promise<Paginated<Student>>;
  getStudent(id: string): Promise<Student | null>;
  createStudent(input: CreateStudentInput): Promise<Student>;
  updateStudent(
    id: string,
    input: Partial<Omit<Student, 'id' | 'createdAt' | 'updatedAt'>>,
  ): Promise<Student>;

  /* parents & links */
  listParents(): Promise<Parent[]>;
  listParentLinks(): Promise<ParentStudentLink[]>;
  linkParentToStudent(input: {
    parentId: string;
    studentId: string;
    relationship: string;
  }): Promise<ParentStudentLink>;
  /** Parent portal: children linked to the signed-in parent â€” never arbitrary. */
  getMyChildren(): Promise<Student[]>;

  /* teachers & staff */
  listTeachers(filter?: PageFilter): Promise<Paginated<Teacher>>;
  createTeacher(input: CreateTeacherInput): Promise<Teacher>;
  updateTeacher(id: string, input: Partial<CreateTeacherInput>): Promise<Teacher>;

  /* classes, subjects, academic calendar */
  listClassSections(): Promise<ClassSection[]>;
  createClassSection(input: { name: string; section: string; gradeLevel: number }): Promise<ClassSection>;
  updateClassSection(
    id: string,
    input: Partial<{ name: string; section: string; gradeLevel: number; classTeacherId: string | null }>,
  ): Promise<ClassSection>;
  listSubjects(): Promise<Subject[]>;
  createSubject(input: { code: string; name: string; isCore: boolean }): Promise<Subject>;
  updateSubject(id: string, input: Partial<{ code: string; name: string; isCore: boolean }>): Promise<Subject>;
  listAcademicYears(): Promise<AcademicYear[]>;
  createAcademicYear(input: { name: string; startDate: string; endDate: string }): Promise<AcademicYear>;
  setCurrentAcademicYear(id: string): Promise<void>;
  listTerms(academicYearId?: string): Promise<Term[]>;
  createTerm(input: {
    academicYearId: string;
    name: string;
    order: number;
    startDate: string;
    endDate: string;
  }): Promise<Term>;
  setCurrentTerm(id: string): Promise<void>;

  /* enrolments & assignments */
  listEnrollments(filter?: {
    classSectionId?: string;
    academicYearId?: string;
    studentId?: string;
  }): Promise<Enrollment[]>;
  enrollStudent(input: { studentId: string; classSectionId: string; academicYearId: string }): Promise<Enrollment>;
  updateEnrollmentStatus(id: string, status: Enrollment['status']): Promise<Enrollment>;
  listTeacherAssignments(filter?: { teacherId?: string; classSectionId?: string }): Promise<TeacherAssignment[]>;
  createTeacherAssignment(input: {
    teacherId: string;
    classSectionId: string;
    subjectId: string;
    academicYearId: string;
  }): Promise<TeacherAssignment>;
  deleteTeacherAssignment(id: string): Promise<void>;

  /* assessments & marks */
  listAssessments(filter?: { classSectionId?: string; subjectId?: string; termId?: string }): Promise<Assessment[]>;
  createAssessment(input: SaveAssessmentInput): Promise<Assessment>;
  updateAssessment(id: string, input: Partial<SaveAssessmentInput>): Promise<Assessment>;
  deleteAssessment(id: string): Promise<void>;
  listMarks(assessmentId: string): Promise<Mark[]>;
  saveMarkDrafts(drafts: MarkDraftInput[]): Promise<Mark[]>;
  checkSubmissionReadiness(assessmentId: string): Promise<MarkSubmissionCheck>;
  submitAssessmentMarks(assessmentId: string): Promise<Assessment>;
  reopenAssessment(assessmentId: string): Promise<Assessment>;
  /** Admin correction of a locked/published mark â€” always audited, reason required. */
  correctMark(input: {
    assessmentId: string;
    studentId: string;
    score: number | null;
    reason: string;
  }): Promise<Mark>;

  /* results & publication */
  getPublication(classSectionId: string, termId: string): Promise<ResultPublication | null>;
  getClassResultSheet(classSectionId: string, termId: string): Promise<ClassResultSheet>;
  submitClassResults(classSectionId: string, termId: string): Promise<ResultPublication>;
  approveClassResults(classSectionId: string, termId: string): Promise<ResultPublication>;
  publishClassResults(classSectionId: string, termId: string): Promise<ResultPublication>;
  listResultSummaries(classSectionId: string, termId: string): Promise<TermResult[]>;
  /** Student/parent view â€” returns null unless the result is published AND the student is allowed. */
  getPublishedResult(studentId: string, termId: string): Promise<TermResult | null>;

  /* grading scale */
  getGradingScale(): Promise<GradingScale>;
  updateGradingScale(scale: GradingScale): Promise<GradingScale>;

  /* notices */
  listNotices(filter?: {
    audience?: NoticeAudience | 'all';
    status?: NoticeStatus;
    search?: string;
  }): Promise<Notice[]>;
  createNotice(input: SaveNoticeInput): Promise<Notice>;
  updateNotice(id: string, input: Partial<SaveNoticeInput>): Promise<Notice>;
  setNoticeStatus(id: string, status: NoticeStatus): Promise<Notice>;

  /* dashboards */
  getDashboardStats(): Promise<DashboardStats>;

  /* public website intake (unauthenticated visitors) */
  submitContactMessage(input: {
    name: string;
    email: string;
    phone?: string | null;
    subject: string;
    message: string;
  }): Promise<void>;
  submitAdmissionEnquiry(input: {
    childName: string;
    gradeApplying: string;
    parentName: string;
    email: string;
    phone: string;
    notes?: string | null;
  }): Promise<void>;
}

