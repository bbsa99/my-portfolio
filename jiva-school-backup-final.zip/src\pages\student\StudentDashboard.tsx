import { Link } from 'react-router-dom';
import { useAuth } from '../../state/AuthContext';
import { useAsync } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Alert } from '../../components/ui/Alert';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import type { Notice, Term } from '../../lib/types';

/** Student home: published results and notices addressed to students. */
export function StudentDashboard() {
  const { session } = useAuth();
  const repo = useRepo();
  const { data, loading, error } = useAsync<{ notices: Notice[]; terms: Term[] }>(async () => {
    const [notices, terms] = await Promise.all([repo.listNotices(), repo.listTerms()]);
    return { notices, terms };
  }, [repo]);

  return (
    <div>
      <PageHeader
        title={`Welcome, ${session?.profile.fullName.split(' ')[0] ?? 'student'}`}
        subtitle="Your latest results and school announcements."
        actions={
          <Link to="/app/student/results" className="rounded-lg bg-brand-700 px-4 py-2 text-sm font-medium text-white hover:bg-brand-800">
            View my results
          </Link>
        }
      />

      {loading && <PageSpinner />}
      {error && <Alert variant="danger">{error}</Alert>}

      {data && (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader title="My results" subtitle="Published term results." action={<Badge tone="brand">View only</Badge>} />
            <CardBody>
              {data.terms.length === 0 ? (
                <p className="text-sm text-ink-500">No terms available yet.</p>
              ) : (
                <p className="text-sm text-ink-600">
                  Results appear here once your teachers submit them and the school publishes them for the term.
                </p>
              )}
              <Link to="/app/student/results" className="mt-3 inline-block text-sm font-medium text-brand-700 hover:text-brand-800">
                Go to my results →
              </Link>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Notices for students" subtitle="Announcements addressed to you." />
            <CardBody>
              {data.notices.length === 0 ? (
                <EmptyState title="No notices" description="You're all caught up." />
              ) : (
                <ul className="space-y-2">
                  {data.notices.slice(0, 5).map((n) => (
                    <li key={n.id} className="rounded-lg border border-ink-100 px-3 py-2">
                      <p className="text-sm font-medium text-ink-800">{n.title}</p>
                      <p className="text-xs text-ink-400">{n.category}</p>
                    </li>
                  ))}
                </ul>
              )}
            </CardBody>
          </Card>
        </div>
      )}
    </div>
  );
}
