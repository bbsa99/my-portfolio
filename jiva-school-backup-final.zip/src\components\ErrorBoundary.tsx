import { Component, type ErrorInfo, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  error: Error | null;
}

/**
 * Keeps a render-time crash in one page from blanking the whole app.
 *
 * React unmounts the entire tree when a component throws and no boundary is
 * present — that is exactly what turned a missing ToastProvider into a white
 * screen on every toast-using page. This boundary catches the error and keeps
 * the surrounding shell (sidebar, top bar) alive.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('Render error caught by ErrorBoundary:', error, info.componentStack);
  }

  private reset = () => this.setState({ error: null });

  render(): ReactNode {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div className="m-6 rounded-xl border border-rose-200 bg-rose-50 p-6 text-center">
        <p className="text-base font-semibold text-rose-800">This section failed to load</p>
        <p className="mt-1 text-sm text-rose-700">
          Something went wrong while rendering this page. Your session is still active — try again or pick another
          item from the sidebar.
        </p>
        <p className="mt-2 font-mono text-xs text-rose-600">{error.message}</p>
        <button
          type="button"
          onClick={this.reset}
          className="mt-4 rounded-lg bg-rose-600 px-4 py-2 text-sm font-medium text-white hover:bg-rose-700"
        >
          Try again
        </button>
      </div>
    );
  }
}
