import { Badge } from './ui/Badge';
import { Card, CardBody, CardHeader } from './ui/Card';
import { PLACEHOLDER_SCALE_NOTE } from '../lib/grading';
import type { TermResult } from '../lib/types';

/** Read-only report card for one student in one term. */
export function ResultCard({ result }: { result: TermResult }) {
  return (
    <Card>
      <CardHeader
        title={`${result.classSectionName} · ${result.termName}`}
        subtitle={`${result.academicYearName} · ${result.studentName} (${result.studentNumber})`}
        action={<Badge tone="brand">Overall {result.overallGrade}</Badge>}
      />
      <CardBody className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl bg-brand-50 p-4">
            <p className="text-xs text-brand-700">Total</p>
            <p className="mt-1 text-lg font-semibold text-brand-900">
              {result.totalObtained} / {result.totalMaximum}
            </p>
          </div>
          <div className="rounded-xl bg-gold-50 p-4">
            <p className="text-xs text-gold-700">Percentage</p>
            <p className="mt-1 text-lg font-semibold text-gold-900">{result.overallPercentage.toFixed(1)}%</p>
          </div>
          <div className="rounded-xl bg-ink-100 p-4">
            <p className="text-xs text-ink-600">Class rank</p>
            <p className="mt-1 text-lg font-semibold text-ink-900">
              {result.rank !== null ? `${result.rank} of ${result.classSize}` : '—'}
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b border-ink-200 text-left text-xs font-semibold tracking-wide text-ink-500 uppercase">
                <th className="px-3 py-2">Subject</th>
                <th className="px-3 py-2">Teacher</th>
                <th className="px-3 py-2 text-right">Obtained</th>
                <th className="px-3 py-2 text-right">Maximum</th>
                <th className="px-3 py-2 text-right">%</th>
                <th className="px-3 py-2 text-center">Grade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {result.subjects.map((s) => (
                <tr key={s.subjectId}>
                  <td className="px-3 py-2 font-medium text-ink-800">
                    {s.subjectName} <span className="text-xs text-ink-400">({s.subjectCode})</span>
                  </td>
                  <td className="px-3 py-2 text-ink-500">{s.teacherName ?? '—'}</td>
                  <td className="px-3 py-2 text-right text-ink-700">{s.obtained}</td>
                  <td className="px-3 py-2 text-right text-ink-500">{s.maximum}</td>
                  <td className="px-3 py-2 text-right text-ink-700">{(s.weightedPercentage ?? s.percentage).toFixed(1)}%</td>
                  <td className="px-3 py-2 text-center">
                    <Badge tone="neutral">{s.grade}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <p className="text-xs text-ink-400">{PLACEHOLDER_SCALE_NOTE}</p>
      </CardBody>
    </Card>
  );
}
