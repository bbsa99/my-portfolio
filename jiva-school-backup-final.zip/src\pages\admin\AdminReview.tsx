import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { PLACEHOLDER_SCALE_NOTE } from '../../lib/grading';
import type { ClassSection, ResultPublication, Term } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { useToast } from '../../components/Toast';
import type { ClassResultSheet } from '../../lib/repo/types';

const STATE_TONE: Record<ResultPublication['state'], 'neutral' | 'info' | 'warning' | 'success'> = {
  draft: 'neutral',
  submitted: 'info',
  approved: 'warning',
  published: 'success',
};

interface ReviewData {
  classes: ClassSection[];
  terms: Term[];
}

/** Admin results review — inspect the marks grid and run submit/approve/publish. */
export function AdminReview() {
  const repo = useRepo();
  const toast = useToast();
  const [classId, setClassId] = useState('');
  const [termId, setTermId] = useState('');
  const [busy, setBusy] = useState(false);

  const options = useAsync<ReviewData>(async () => {
    const [classes, terms] = await Promise.all([repo.listClassSections(), repo.listTerms()]);
    return { classes, terms };
  }, [repo]);

  const sheet = useAsync<ClassResultSheet>(
    async () => {
      if (!classId || !termId) return null as unknown as ClassResultSheet;
      return repo.getClassResultSheet(classId, termId);
    },
    [repo, classId, termId],
  );

  async function run(action: 'submit' | 'approve' | 'publish') {
    if (!classId || !termId) return;
    setBusy(true);
    try {
      if (action === 'submit') await repo.submitClassResults(classId, termId);
      if (action === 'approve') await repo.approveClassResults(classId, termId);
      if (action === 'publish') await repo.publishClassResults(classId, termId);
      toast.push('success', `Results ${action}ed successfully.`);
      sheet.reload();
    } catch (err) {
      toast.push('error', errMessage(err));
    } finally {
      setBusy(false);
    }
  }

  const selected = classId && termId;
  const publication = sheet.data?.publication ?? null;
  const state: ResultPublication['state'] = publication?.state ?? 'draft';

  return (
    <div>
      <PageHeader title="Results review" subtitle="Approve and publish class results after teachers submit them." />

      <Card className="mb-6">
        <CardBody>
          {options.loading && <PageSpinner />}
          {options.data && (
            <div className="grid gap-4 sm:grid-cols-2">
              <Select
                label="Class"
                value={classId}
                onChange={(e) => setClassId(e.target.value)}
              >
                <option value="">Select a class…</option>
                {options.data.classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} {c.section}
                  </option>
                ))}
              </Select>
              <Select label="Term" value={termId} onChange={(e) => setTermId(e.target.value)}>
                <option value="">Select a term…</option>
                {options.data.terms.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </Select>
            </div>
          )}
        </CardBody>
      </Card>

      {!selected && (
        <EmptyState title="Select a class and term" description="Choose a class section and term to review its results." />
      )}

      {selected && sheet.loading && <PageSpinner />}
      {selected && sheet.error && <Alert variant="danger">{sheet.error}</Alert>}

      {selected && sheet.data && (
        <Card>
          <CardHeader
            title={`${sheet.data.classSection.name} ${sheet.data.classSection.section} · ${sheet.data.term.name}`}
            subtitle={`${sheet.data.students.length} students · ${sheet.data.assessments.length} assessments`}
            action={<Badge tone={STATE_TONE[state]}>{state}</Badge>}
          />
          <CardBody className="space-y-4">
            <Alert variant="warning" title="Placeholder grading scale">
              {PLACEHOLDER_SCALE_NOTE}
            </Alert>

            <div className="flex flex-wrap gap-2">
              <Button disabled={busy || state !== 'draft'} onClick={() => void run('submit')}>
                Submit for approval
              </Button>
              <Button disabled={busy || state !== 'submitted'} onClick={() => void run('approve')}>
                Approve
              </Button>
              <Button disabled={busy || state !== 'approved'} onClick={() => void run('publish')}>
                Publish to portals
              </Button>
            </div>

            <p className="text-sm text-ink-500">
              Results move draft → submitted → approved → published. Only published results are visible to students and
              parents.
            </p>
          </CardBody>
        </Card>
      )}
    </div>
  );
}
