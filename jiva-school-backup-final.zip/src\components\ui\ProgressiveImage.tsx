import { useState, type ImgHTMLAttributes } from 'react';

/**
 * Image with a graceful fallback. While loading (and if the file fails to load)
 * it shows a soft brand-tinted panel with the descriptive label, so the layout
 * never breaks and every image always has meaningful text. The photo itself is
 * lazy-loaded and revealed with a gentle fade once decoded.
 */
export function ProgressiveImage({
  alt,
  className,
  wrapperClassName,
  ...imgProps
}: ImgHTMLAttributes<HTMLImageElement> & { wrapperClassName?: string }) {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className={`relative overflow-hidden bg-gradient-to-br from-brand-100 to-brand-200 ${wrapperClassName ?? ''}`}>
      <img
        alt={alt}
        loading="lazy"
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => setLoaded(false)}
        className={`h-full w-full object-cover transition-opacity duration-500 ${
          loaded ? 'opacity-100' : 'opacity-0'
        } ${className ?? ''}`}
        {...imgProps}
      />
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center px-4 text-center text-sm font-medium text-brand-800/80">
          <span>{alt}</span>
        </div>
      )}
    </div>
  );
}

export default ProgressiveImage;
