import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { assessmentSchema } from '../../lib/validation';
import { formatDate } from '../../lib/utils';
import type { Assessment, AssessmentType, ClassSection, Subject, Term } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { useToast } from '../../components/Toast';

const TYPES: AssessmentType[] = ['assignment', 'quiz', 'test', 'exam'];

interface RefData {
  classes: ClassSection[];
  subjects: Subject[];
  terms: Term[];
  assignments: Array<{ classSectionId: string; subjectId: string }>;
}

/** Teacher assessment list — create assessments and open the marks grid. */
export function TeacherAssessments() {
  const repo = useRepo();
  const toast = useToast();
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    title: '',
    description: '',
    type: 'assignment' as AssessmentType,
    classSectionId: '',
    subjectId: '',
    termId: '',
    maxMarks: '100',
    weight: '10',
    dueDate: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const { data, loading, error, reload } = useAsync<{ assessments: Assessment[]; ref: RefData }>(async () => {
    const [assessments, classes, subjects, terms, teacherAssignments] = await Promise.all([
      repo.listAssessments(),
      repo.listClassSections(),
      repo.listSubjects(),
      repo.listTerms(),
      repo.listTeacherAssignments(),
    ]);
    return {
      assessments,
      ref: {
        classes,
        subjects,
        terms,
        assignments: teacherAssignments.map((a) => ({ classSectionId: a.classSectionId, subjectId: a.subjectId })),
      },
    };
  }, [repo]);

  const allowedSubjectIds = new Set(
    data?.ref.assignments.filter((a) => a.classSectionId === form.classSectionId).map((a) => a.subjectId) ?? [],
  );
  const allowedClassIds = new Set(data?.ref.assignments.map((a) => a.classSectionId) ?? []);
  const classLabel = (id: string) => {
    const c = data?.ref.classes.find((x) => x.id === id);
    return c ? `${c.name} ${c.section}` : id;
  };
  const subjectLabel = (id: string) => data?.ref.subjects.find((s) => s.id === id)?.name ?? id;

  async function create() {
    const parsed = assessmentSchema.safeParse({
      title: form.title,
      description: form.description,
      type: form.type,
      subjectId: form.subjectId,
      classSectionId: form.classSectionId,
      termId: form.termId,
      maxMarks: Number(form.maxMarks),
      weight: Number(form.weight),
      dueDate: form.dueDate || undefined,
    });
    if (!parsed.success) {
      const fe: Record<string, string> = {};
      for (const issue of parsed.error.issues) fe[String(issue.path[0])] = issue.message;
      setErrors(fe);
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      await repo.createAssessment({
        title: parsed.data.title,
        description: parsed.data.description ?? null,
        type: parsed.data.type,
        subjectId: parsed.data.subjectId,
        classSectionId: parsed.data.classSectionId,
        termId: parsed.data.termId,
        maxMarks: parsed.data.maxMarks,
        weight: parsed.data.weight,
        dueDate: parsed.data.dueDate ?? null,
      });
      toast.push('success', 'Assessment created.');
      setModalOpen(false);
      setForm({ title: '', description: '', type: 'assignment', classSectionId: '', subjectId: '', termId: '', maxMarks: '100', weight: '10', dueDate: '' });
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  const columns: Array<Column<Assessment>> = [
    { key: 'title', header: 'Assessment', render: (a) => <span className="font-medium text-ink-800">{a.title}</span> },
    { key: 'class', header: 'Class', render: (a) => classLabel(a.classSectionId) },
    { key: 'subject', header: 'Subject', render: (a) => subjectLabel(a.subjectId) },
    { key: 'type', header: 'Type', render: (a) => <Badge>{a.type}</Badge> },
    { key: 'max', header: 'Max', render: (a) => a.maxMarks },
    { key: 'due', header: 'Due', render: (a) => formatDate(a.dueDate) },
    { key: 'status', header: 'Status', render: (a) => <Badge tone={a.status === 'draft' ? 'warning' : 'success'}>{a.status}</Badge> },
    {
      key: 'actions',
      header: '',
      headerClassName: 'text-right',
      className: 'text-right',
      render: (a) => (
        <Link to={`/app/teacher/assessments/${a.id}/marks`}>
          <Button size="sm" variant="outline">
            Enter marks
          </Button>
        </Link>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Assessments"
        subtitle="Create assessments and enter marks for your classes."
        actions={
          <Button onClick={() => setModalOpen(true)}>
            <span className="text-lg leading-none">+</span> New assessment
          </Button>
        }
      />

      <Card>
        {loading && <PageSpinner />}
        {error && (
          <div className="p-4">
            <Alert variant="danger">{error}</Alert>
          </div>
        )}
        {data && (
          <DataTable
            columns={columns}
            rows={data.assessments}
            rowKey={(a) => a.id}
            caption="My assessments"
            empty={<EmptyState title="No assessments yet" description="Create your first assessment to start entering marks." />}
          />
        )}
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="New assessment"
        size="lg"
        footer={
          <>
            <Button variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void create()}>
              Create assessment
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input label="Title" value={form.title} error={errors.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <Textarea label="Description (optional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <div className="grid gap-4 sm:grid-cols-2">
            <Select label="Type" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as AssessmentType })}>
              {TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </Select>
            <Select
              label="Class"
              value={form.classSectionId}
              error={errors.classSectionId}
              onChange={(e) => setForm({ ...form, classSectionId: e.target.value, subjectId: '' })}
            >
              <option value="">Select a class…</option>
              {data?.ref.classes.filter((c) => allowedClassIds.has(c.id)).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.section}
                </option>
              ))}
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Select
              label="Subject"
              value={form.subjectId}
              error={errors.subjectId}
              disabled={!form.classSectionId}
              onChange={(e) => setForm({ ...form, subjectId: e.target.value })}
            >
              <option value="">Select a subject…</option>
              {data?.ref.subjects.filter((s) => allowedSubjectIds.has(s.id)).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
            <Select label="Term" value={form.termId} error={errors.termId} onChange={(e) => setForm({ ...form, termId: e.target.value })}>
              <option value="">Select a term…</option>
              {data?.ref.terms.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            <Input label="Max marks" type="number" min={1} value={form.maxMarks} error={errors.maxMarks} onChange={(e) => setForm({ ...form, maxMarks: e.target.value })} required />
            <Input label="Weight (%)" type="number" min={1} max={100} value={form.weight} error={errors.weight} onChange={(e) => setForm({ ...form, weight: e.target.value })} required />
            <Input label="Due date (optional)" type="date" value={form.dueDate} error={errors.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
