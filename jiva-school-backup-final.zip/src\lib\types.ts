/**
 * Core domain types for the Jiva School management system.
 * These types mirror the SQL schema in `supabase/migrations`
 * and are shared by the local demo repository and the Supabase repository.
 */

export type Role = 'admin' | 'teacher' | 'student' | 'parent';

export interface Profile {
  id: string;
  email: string;
  fullName: string;
  role: Role;
  createdAt: string;
}

export interface SessionUser {
  id: string;
  email: string;
}

export interface Session {
  user: SessionUser;
  profile: Profile;
}

/* ------------------------------- People ------------------------------- */

export type StudentStatus = 'active' | 'inactive' | 'graduated' | 'transferred';

export interface Student {
  id: string;
  /** Human friendly school roll number, assigned by administration. */
  studentId: string;
  fullName: string;
  dateOfBirth?: string | null;
  gender?: 'male' | 'female' | 'other' | null;
  status: StudentStatus;
  admissionDate?: string | null;
  /** Auth profile linked to the student portal, if any. */
  profileId?: string | null;
  guardianName?: string | null;
  guardianPhone?: string | null;
  address?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Parent {
  id: string;
  profileId?: string | null;
  fullName: string;
  phone?: string | null;
  email?: string | null;
  createdAt: string;
}


/* ---------------------------- Academics ------------------------------ */

export interface ClassSection {
  id: string;
  name: string;
  section: string;
  gradeLevel: number;
  classTeacherId?: string | null;
  createdAt: string;
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  isCore: boolean;
}

export interface AcademicYear {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
}

export interface Term {
  id: string;
  academicYearId: string;
  name: string;
  order: number;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
}

export interface Enrollment {
  id: string;
  studentId: string;
  classSectionId: string;
  academicYearId: string;
  status: 'active' | 'completed' | 'withdrawn';
  enrolledAt: string;
}

export interface TeacherAssignment {
  id: string;
  teacherId: string;
  classSectionId: string;
  subjectId: string;
  academicYearId: string;
  createdAt: string;
}

/* ----------------------------- Assessments ---------------------------- */

export type AssessmentType = 'assignment' | 'quiz' | 'test' | 'exam';

export interface Assessment {
  id: string;
  title: string;
  description?: string | null;
  type: AssessmentType;
  classSectionId: string;
  subjectId: string;
  termId: string;
  maxMarks: number;
  /** Relative weight of this assessment inside the subject/term grade. */
  weight: number;
  dueDate?: string | null;
  /** Draft: accepting marks. Submitted: locked pending review. */
  status: 'draft' | 'submitted';
  submittedAt?: string | null;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export type MarkStatus = 'draft' | 'submitted';

export interface Mark {
  id: string;
  assessmentId: string;
  studentId: string;
  score: number | null;
  status: MarkStatus;
  enteredBy: string;
  createdAt: string;
  updatedAt: string;
}

/* ------------------------------- Results ------------------------------ */

export type ResultState = 'draft' | 'submitted' | 'approved' | 'published';

/** Publication workflow state per class section + term. */
export interface ResultPublication {
  id: string;
  classSectionId: string;
  termId: string;
  state: ResultState;
  submittedBy?: string | null;
  submittedAt?: string | null;
  approvedBy?: string | null;
  approvedAt?: string | null;
  publishedBy?: string | null;
  publishedAt?: string | null;
  updatedAt: string;
}

export interface GradeBoundary {
  letter: string;
  minPercent: number;
  maxPercent: number;
  gpaPoints: number;
  remark: string;
}

export interface GradingScale {
  id: string;
  name: string;
  isDefault: boolean;
  boundaries: GradeBoundary[];
  /** True when the scale is a technical placeholder, not school-approved. */
  isPlaceholder: boolean;
  note?: string | null;
}

export interface SubjectResult {
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  obtained: number;
  maximum: number;
  percentage: number;
  /** Percentage using configured assessment weights; null when weights are incomplete. */
  weightedPercentage: number | null;
  grade: string;
  gradeRemark: string;
  assessmentCount: number;
  teacherName?: string | null;
}

export interface TermResult {
  studentId: string;
  studentName: string;
  studentNumber: string;
  classSectionId: string;
  classSectionName: string;
  termId: string;
  termName: string;
  academicYearName: string;
  state: ResultState | null;
  subjects: SubjectResult[];
  totalObtained: number;
  totalMaximum: number;
  overallPercentage: number;
  weightedOverallPercentage: number | null;
  overallGrade: string;
  classSize: number | null;
  rank: number | null;
  generatedAt: string;
}

/* ------------------------------- Notices ------------------------------ */

export type NoticeCategory = 'general' | 'admissions' | 'academic' | 'events' | 'exams' | 'urgent';

export type NoticeAudience = 'public' | 'staff' | 'students' | 'parents' | 'authenticated';

export type NoticeStatus = 'draft' | 'published' | 'archived';

export interface Notice {
  id: string;
  title: string;
  body: string;
  category: NoticeCategory;
  audience: NoticeAudience;
  status: NoticeStatus;
  publishedAt?: string | null;
  expiresAt?: string | null;
  authorName: string;
  createdAt: string;
  updatedAt: string;
}

/* ------------------------------ Audit log ----------------------------- */

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  action: string;
  entityType: string;
  entityId: string;
  summary: string;
  details?: string | null;
  createdAt: string;
}

/* ------------------------------ Dashboard ----------------------------- */

export interface DashboardStats {
  students: number;
  teachers: number;
  classes: number;
  subjects: number;
  pendingApprovals: number;
  publishedTerms: number;
  publishedNotices: number;
}

/* --------------------------- public intake ----------------------------- */

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  subject: string;
  message: string;
  createdAt: string;
}

export interface AdmissionEnquiry {
  id: string;
  childName: string;
  gradeApplying: string;
  parentName: string;
  email: string;
  phone: string;
  notes?: string | null;
  createdAt: string;
}


export interface ParentStudentLink {
  id: string;
  parentId: string;
  studentId: string;
  relationship: string;
  createdAt: string;
}

export interface Teacher {
  id: string;
  employeeNo: string;
  profileId?: string | null;
  fullName: string;
  phone?: string | null;
  email?: string | null;
  status: 'active' | 'inactive';
  createdAt: string;
}
