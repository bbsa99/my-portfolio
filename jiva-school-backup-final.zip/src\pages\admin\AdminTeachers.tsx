import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { formatDate } from '../../lib/utils';
import type { Teacher } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { useToast } from '../../components/Toast';
import type { Paginated } from '../../lib/repo/types';

interface TeacherForm {
  fullName: string;
  employeeNo: string;
  phone: string;
  email: string;
  status: 'active' | 'inactive';
}

const EMPTY_FORM: TeacherForm = { fullName: '', employeeNo: '', phone: '', email: '', status: 'active' };

/** Admin staff register — search, create and edit teachers. */
export function AdminTeachers() {
  const repo = useRepo();
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Teacher | null>(null);
  const [form, setForm] = useState<TeacherForm>(EMPTY_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const { data, loading, error, reload } = useAsync<Paginated<Teacher>>(
    () => repo.listTeachers({ search, page, pageSize: 10 }),
    [repo, search, page],
  );

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setErrors({});
    setFormError(null);
    setModalOpen(true);
  }

  function openEdit(teacher: Teacher) {
    setEditing(teacher);
    setForm({
      fullName: teacher.fullName,
      employeeNo: teacher.employeeNo,
      phone: teacher.phone ?? '',
      email: teacher.email ?? '',
      status: teacher.status,
    });
    setErrors({});
    setFormError(null);
    setModalOpen(true);
  }

  async function save() {
    const fieldErrors: Record<string, string> = {};
    if (form.fullName.trim().length < 2) fieldErrors.fullName = "Enter the staff member's full name.";
    if (form.employeeNo.trim().length < 2) fieldErrors.employeeNo = 'Enter an employee number.';
    if (form.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) fieldErrors.email = 'Enter a valid email address.';
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      const payload = {
        fullName: form.fullName.trim(),
        employeeNo: form.employeeNo.trim(),
        phone: form.phone.trim() || null,
        email: form.email.trim() || null,
        status: form.status,
      };
      if (editing) {
        await repo.updateTeacher(editing.id, payload);
        toast.push('success', 'Staff record updated.');
      } else {
        await repo.createTeacher(payload);
        toast.push('success', 'Staff member added.');
      }
      setModalOpen(false);
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  const columns: Array<Column<Teacher>> = [
    { key: 'employeeNo', header: 'Employee no.', render: (t) => <span className="font-medium text-ink-800">{t.employeeNo}</span> },
    { key: 'name', header: 'Name', render: (t) => t.fullName },
    { key: 'email', header: 'Email', render: (t) => t.email ?? '—' },
    { key: 'phone', header: 'Phone', render: (t) => t.phone ?? '—' },
    { key: 'joined', header: 'Joined', render: (t) => formatDate(t.createdAt) },
    { key: 'status', header: 'Status', render: (t) => <Badge tone={t.status === 'active' ? 'success' : 'neutral'}>{t.status}</Badge> },
    {
      key: 'actions',
      header: '',
      headerClassName: 'text-right',
      className: 'text-right',
      render: (t) => (
        <Button size="sm" variant="outline" onClick={() => openEdit(t)}>
          Edit
        </Button>
      ),
    },
  ];

  const total = data?.total ?? 0;
  const pageSize = data?.pageSize ?? 10;
  const pageCount = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <PageHeader
        title="Staff"
        subtitle="Teaching staff directory."
        actions={
          <Button onClick={openCreate}>
            <span className="text-lg leading-none">+</span> Add staff
          </Button>
        }
      />

      <Card>
        <div className="border-b border-ink-100 p-4">
          <Input
            placeholder="Search by name, employee number or email…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>

        {loading && <PageSpinner />}
        {error && (
          <div className="p-4">
            <Alert variant="danger">{error}</Alert>
          </div>
        )}
        {data && (
          <DataTable
            columns={columns}
            rows={data.items}
            rowKey={(t) => t.id}
            caption="Staff directory"
            empty={<EmptyState title="No staff found" description="Try a different search, or add a new staff member." />}
          />
        )}

        {data && total > pageSize && (
          <div className="flex items-center justify-between border-t border-ink-100 px-4 py-3 text-sm text-ink-500">
            <span>
              Page {data.page} of {pageCount} · {total} staff
            </span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <Button size="sm" variant="outline" disabled={page >= pageCount} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          </div>
        )}
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? `Edit ${editing.fullName}` : 'Add staff'}
        footer={
          <>
            <Button variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void save()}>
              {editing ? 'Save changes' : 'Add staff'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input label="Full name" value={form.fullName} error={errors.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
          <Input label="Employee number" value={form.employeeNo} error={errors.employeeNo} disabled={Boolean(editing)} onChange={(e) => setForm({ ...form, employeeNo: e.target.value })} required />
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Email" type="email" value={form.email} error={errors.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <Input label="Phone" value={form.phone} error={errors.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <Select label="Status" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as 'active' | 'inactive' })}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </Select>
        </div>
      </Modal>
    </div>
  );
}
