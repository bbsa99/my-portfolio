import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { ROLE_LABELS } from '../../lib/permissions';
import { passwordSchema } from '../../lib/validation';
import { formatDate } from '../../lib/utils';
import type { Profile, Role } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { useToast } from '../../components/Toast';
import type { Paginated } from '../../lib/repo/types';

const ROLES: Role[] = ['admin', 'teacher', 'student', 'parent'];

/** Admin account manager — create portal accounts and change roles. */
export function AdminAccounts() {
  const repo = useRepo();
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [createOpen, setCreateOpen] = useState(false);
  const [roleEdit, setRoleEdit] = useState<Profile | null>(null);
  const [resetEdit, setResetEdit] = useState<Profile | null>(null);
  const [newRole, setNewRole] = useState<Role>('student');
  const [newPassword, setNewPassword] = useState('');
  const [form, setForm] = useState({ email: '', fullName: '', role: 'student' as Role, password: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const { data, loading, error, reload } = useAsync<Paginated<Profile>>(
    () => repo.listAccounts({ search, page, pageSize: 10 }),
    [repo, search, page],
  );

  async function createAccount() {
    const fe: Record<string, string> = {};
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email.trim())) fe.email = 'Enter a valid email address.';
    if (form.fullName.trim().length < 2) fe.fullName = 'Enter the full name.';
    if (!passwordSchema.safeParse(form.password).success) {
      fe.password = 'At least 8 characters, including a letter and a number.';
    }
    if (Object.keys(fe).length > 0) {
      setErrors(fe);
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      await repo.createAccount({
        email: form.email.trim(),
        fullName: form.fullName.trim(),
        role: form.role,
        password: form.password,
      });
      toast.push('success', 'Account created. Give the user their initial password — they can sign in right away.');
      setCreateOpen(false);
      setForm({ email: '', fullName: '', role: 'student', password: '' });
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  async function saveReset() {
    if (!resetEdit) return;
    const parsed = passwordSchema.safeParse(newPassword);
    if (!parsed.success) {
      setErrors({ newPassword: parsed.error.issues[0]?.message ?? 'Invalid password.' });
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      await repo.resetPassword(resetEdit.id, parsed.data);
      toast.push('success', `Password updated for ${resetEdit.fullName}.`);
      setResetEdit(null);
      setNewPassword('');
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  async function saveRole() {
    if (!roleEdit) return;
    setSaving(true);
    setFormError(null);
    try {
      await repo.updateAccountRole(roleEdit.id, newRole);
      toast.push('success', `${roleEdit.fullName} is now ${ROLE_LABELS[newRole]}.`);
      setRoleEdit(null);
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  const columns: Array<Column<Profile>> = [
    { key: 'name', header: 'Name', render: (p) => <span className="font-medium text-ink-800">{p.fullName}</span> },
    { key: 'email', header: 'Email', render: (p) => p.email },
    { key: 'role', header: 'Role', render: (p) => <Badge tone={p.role === 'admin' ? 'brand' : 'neutral'}>{ROLE_LABELS[p.role]}</Badge> },
    { key: 'created', header: 'Created', render: (p) => formatDate(p.createdAt) },
    {
      key: 'actions',
      header: '',
      headerClassName: 'text-right',
      className: 'text-right',
      render: (p) => (
        <div className="flex justify-end gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setResetEdit(p);
              setNewPassword('');
              setErrors({});
              setFormError(null);
            }}
          >
            Reset password
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setRoleEdit(p);
              setNewRole(p.role);
              setFormError(null);
            }}
          >
            Change role
          </Button>
        </div>
      ),
    },
  ];

  const total = data?.total ?? 0;
  const pageSize = data?.pageSize ?? 10;
  const pageCount = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <PageHeader
        title="Accounts"
        subtitle="Portal user accounts and their roles."
        actions={
          <Button onClick={() => setCreateOpen(true)}>
            <span className="text-lg leading-none">+</span> New account
          </Button>
        }
      />

      <Card>
        <div className="border-b border-ink-100 p-4">
          <Input
            placeholder="Search by name, email or role…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>
        {loading && <PageSpinner />}
        {error && (
          <div className="p-4">
            <Alert variant="danger">{error}</Alert>
          </div>
        )}
        {data && (
          <DataTable
            columns={columns}
            rows={data.items}
            rowKey={(p) => p.id}
            caption="Portal accounts"
            empty={<EmptyState title="No accounts found" description="Try a different search, or create a new account." />}
          />
        )}
        {data && total > pageSize && (
          <div className="flex items-center justify-between border-t border-ink-100 px-4 py-3 text-sm text-ink-500">
            <span>
              Page {data.page} of {pageCount} · {total} accounts
            </span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <Button size="sm" variant="outline" disabled={page >= pageCount} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          </div>
        )}
      </Card>

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="New account"
        description="Choose an initial password — the user can sign in immediately and change it later."
        footer={
          <>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void createAccount()}>
              Create account
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input label="Full name" value={form.fullName} error={errors.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
          <Input label="Email" type="email" value={form.email} error={errors.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
          <Select label="Role" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Role })}>
            {ROLES.map((r) => (
              <option key={r} value={r}>
                {ROLE_LABELS[r]}
              </option>
            ))}
          </Select>
          <Input
            label="Initial password"
            type="password"
            autoComplete="new-password"
            value={form.password}
            error={errors.password}
            hint="At least 8 characters, including a letter and a number."
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />
        </div>
      </Modal>

      <Modal
        open={Boolean(roleEdit)}
        onClose={() => setRoleEdit(null)}
        title={`Change role — ${roleEdit?.fullName ?? ''}`}
        size="sm"
        footer={
          <>
            <Button variant="outline" onClick={() => setRoleEdit(null)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void saveRole()}>
              Save role
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Select label="Role" value={newRole} onChange={(e) => setNewRole(e.target.value as Role)}>
            {ROLES.map((r) => (
              <option key={r} value={r}>
                {ROLE_LABELS[r]}
              </option>
            ))}
          </Select>
        </div>
      </Modal>

      <Modal
        open={Boolean(resetEdit)}
        onClose={() => setResetEdit(null)}
        title={`Reset password — ${resetEdit?.fullName ?? ''}`}
        size="sm"
        footer={
          <>
            <Button variant="outline" onClick={() => setResetEdit(null)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void saveReset()}>
              Update password
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input
            label="New password"
            type="password"
            autoComplete="new-password"
            value={newPassword}
            error={errors.newPassword}
            hint="At least 8 characters, including a letter and a number."
            onChange={(e) => setNewPassword(e.target.value)}
            required
          />
        </div>
      </Modal>
    </div>
  );
}
