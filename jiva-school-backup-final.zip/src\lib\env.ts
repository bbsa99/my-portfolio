export type DataMode = 'local' | 'supabase';

const rawMode = (import.meta.env.VITE_DATA_MODE as string | undefined)?.toLowerCase();
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

/**
 * Effective data mode.
 * - 'supabase' only when explicitly requested AND credentials are present.
 * - otherwise the local demo repository (fictional data) is used so the app
 *   and its tests run without any backend.
 */
export const dataMode: DataMode = rawMode === 'supabase' && supabaseUrl && supabaseAnonKey ? 'supabase' : 'local';

export const supabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const schoolName = (import.meta.env.VITE_SCHOOL_NAME as string | undefined) ?? 'Jiva School';
export const schoolCity = (import.meta.env.VITE_SCHOOL_CITY as string | undefined) ?? 'Addis Ababa, Ethiopia';
export { supabaseUrl, supabaseAnonKey };

/** True when running the demo repository — used to show a clear "Demo mode" banner. */
export const isDemoMode = dataMode === 'local';
