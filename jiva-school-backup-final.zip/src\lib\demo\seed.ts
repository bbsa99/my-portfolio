import type {
  AcademicYear,
  AdmissionEnquiry,
  Assessment,
  AuditLog,
  ClassSection,
  ContactMessage,
  Enrollment,
  GradingScale,
  Mark,
  Notice,
  Parent,
  ParentStudentLink,
  Profile,
  ResultPublication,
  Subject,
  Teacher,
  TeacherAssignment,
  Term,
  Student,
} from '../types';
import { PLACEHOLDER_GRADING_SCALE } from '../grading';

/**
 * DEMO MODE ONLY — every record below is FICTIONAL and exists solely so the
 * application can be explored without a Supabase project. None of these
 * names, emails or numbers belong to real Jiva School students or staff.
 * Setting VITE_DATA_MODE=supabase disables this dataset entirely.
 */

export interface DemoCredential {
  email: string;
  /** Legacy plain-text password from old demo data — upgraded to a hash on first sign-in. */
  password?: string;
  /** PBKDF2-SHA256 hash in the `pbkdf2$<iterations>$<salt>$<hash>` format. */
  passwordHash?: string;
  profileId: string;
}

export interface DemoDb {
  profiles: Profile[];
  credentials: DemoCredential[];
  students: Student[];
  parents: Parent[];
  parentLinks: ParentStudentLink[];
  teachers: Teacher[];
  classSections: ClassSection[];
  subjects: Subject[];
  academicYears: AcademicYear[];
  terms: Term[];
  enrollments: Enrollment[];
  assignments: TeacherAssignment[];
  assessments: Assessment[];
  marks: Mark[];
  publications: ResultPublication[];
  notices: Notice[];
  audit: AuditLog[];
  gradingScale: GradingScale;
  contactMessages: ContactMessage[];
  admissionEnquiries: AdmissionEnquiry[];
}

/** Demo sign-in accounts (fictional). Shown on the login pages in demo mode. */
export const DEMO_ACCOUNTS = [
  { label: 'Administrator', email: 'admin@jivademo.test', password: 'DemoAdmin!23' },
  { label: 'Teacher (Mathematics)', email: 'teacher1@jivademo.test', password: 'DemoTeacher!23' },
  { label: 'Teacher (English/Science)', email: 'teacher2@jivademo.test', password: 'DemoTeacher!23' },
  { label: 'Student (Grade 7A)', email: 'student@jivademo.test', password: 'DemoStudent!23' },
  { label: 'Parent (2 children)', email: 'parent@jivademo.test', password: 'DemoParent!23' },
] as const;

const T = (iso: string) => new Date(iso).toISOString();

export function createSeedDb(): DemoDb {
  const yearId = 'yr-2026';
  const term1Id = 'term-t1-2026';

  const profiles: Profile[] = [
    { id: 'prof-admin', email: 'admin@jivademo.test', fullName: 'Sara Girma (demo)', role: 'admin', createdAt: T('2026-08-20T08:00:00Z') },
    { id: 'prof-t1', email: 'teacher1@jivademo.test', fullName: 'Daniel Tesfaye (demo)', role: 'teacher', createdAt: T('2026-08-22T08:00:00Z') },
    { id: 'prof-t2', email: 'teacher2@jivademo.test', fullName: 'Hanna Mulugeta (demo)', role: 'teacher', createdAt: T('2026-08-22T08:05:00Z') },
    { id: 'prof-stu1', email: 'student@jivademo.test', fullName: 'David Bekele (demo)', role: 'student', createdAt: T('2026-09-01T08:00:00Z') },
    { id: 'prof-par1', email: 'parent@jivademo.test', fullName: 'Aster Bekele (demo)', role: 'parent', createdAt: T('2026-09-01T08:10:00Z') },
  ];

  const credentials: DemoCredential[] = [
    { email: 'admin@jivademo.test', password: 'DemoAdmin!23', profileId: 'prof-admin' },
    { email: 'teacher1@jivademo.test', password: 'DemoTeacher!23', profileId: 'prof-t1' },
    { email: 'teacher2@jivademo.test', password: 'DemoTeacher!23', profileId: 'prof-t2' },
    { email: 'student@jivademo.test', password: 'DemoStudent!23', profileId: 'prof-stu1' },
    { email: 'parent@jivademo.test', password: 'DemoParent!23', profileId: 'prof-par1' },
  ];

  const mkStudent = (
    id: string,
    n: number,
    fullName: string,
    profileId: string | null,
    guardian: string,
  ): Student => ({
    id,
    studentId: `JS-2026-${String(n).padStart(4, '0')}`,
    fullName,
    dateOfBirth: '2014-05-12',
    gender: null,
    status: 'active',
    admissionDate: '2026-09-01',
    profileId,
    guardianName: guardian,
    guardianPhone: '+251 911 000 000',
    address: 'Addis Ababa (demo address)',
    createdAt: T('2026-08-25T08:00:00Z'),
    updatedAt: T('2026-08-25T08:00:00Z'),
  });

  const students: Student[] = [
    mkStudent('stu-01', 1, 'David Bekele', 'prof-stu1', 'Aster Bekele'),
    mkStudent('stu-02', 2, 'Ruth Bekele', null, 'Aster Bekele'),
    mkStudent('stu-03', 3, 'Samuel Alemu', null, 'Girma Alemu'),
    mkStudent('stu-04', 4, 'Selamawit Getu', null, 'Tigist Getu'),
    mkStudent('stu-05', 5, 'Yonas Tadesse', null, 'Marta Tadesse'),
    mkStudent('stu-06', 6, 'Hana Dessalegn', null, 'Bekele Dessalegn'),
    mkStudent('stu-07', 7, 'Natnael Haile', null, 'Solomon Haile'),
    mkStudent('stu-08', 8, 'Bereket Assefa', null, 'Rahel Assefa'),
    mkStudent('stu-09', 9, 'Fatiha Omar', null, 'Idris Omar'),
    mkStudent('stu-10', 10, 'Kalkidan Mekonnen', null, 'Alem Mekonnen'),
  ];

  const parents: Parent[] = [
    { id: 'par-01', profileId: 'prof-par1', fullName: 'Aster Bekele (demo)', phone: '+251 911 111 111', email: 'parent@jivademo.test', createdAt: T('2026-08-26T08:00:00Z') },
  ];

  const parentLinks: ParentStudentLink[] = [
    { id: 'lnk-01', parentId: 'par-01', studentId: 'stu-01', relationship: 'Mother', createdAt: T('2026-08-26T08:00:00Z') },
    { id: 'lnk-02', parentId: 'par-01', studentId: 'stu-02', relationship: 'Mother', createdAt: T('2026-08-26T08:00:00Z') },
  ];

  const teachers: Teacher[] = [
    { id: 'tch-01', employeeNo: 'DEMO-T001', profileId: 'prof-t1', fullName: 'Daniel Tesfaye (demo)', phone: '+251 911 222 222', email: 'teacher1@jivademo.test', status: 'active', createdAt: T('2026-08-22T08:00:00Z') },
    { id: 'tch-02', employeeNo: 'DEMO-T002', profileId: 'prof-t2', fullName: 'Hanna Mulugeta (demo)', phone: '+251 911 333 333', email: 'teacher2@jivademo.test', status: 'active', createdAt: T('2026-08-22T08:05:00Z') },
  ];

  const classSections: ClassSection[] = [
    { id: 'cls-7a', name: 'Grade 7', section: 'A', gradeLevel: 7, classTeacherId: 'tch-01', createdAt: T('2026-08-20T08:00:00Z') },
    { id: 'cls-8a', name: 'Grade 8', section: 'A', gradeLevel: 8, classTeacherId: 'tch-02', createdAt: T('2026-08-20T08:00:00Z') },
  ];

  const subjects: Subject[] = [
    { id: 'sub-eng', code: 'ENG', name: 'English', isCore: true },
    { id: 'sub-math', code: 'MATH', name: 'Mathematics', isCore: true },
    { id: 'sub-amh', code: 'AMH', name: 'Amharic', isCore: true },
    { id: 'sub-sci', code: 'SCI', name: 'General Science', isCore: true },
    { id: 'sub-sst', code: 'SST', name: 'Social Studies', isCore: true },
  ];

  const academicYears: AcademicYear[] = [
    { id: yearId, name: '2026/2027', startDate: '2026-09-01', endDate: '2027-07-15', isCurrent: true },
  ];

  const terms: Term[] = [
    { id: term1Id, academicYearId: yearId, name: 'Term 1', order: 1, startDate: '2026-09-01', endDate: '2026-12-15', isCurrent: true },
    { id: 'term-t2-2026', academicYearId: yearId, name: 'Term 2', order: 2, startDate: '2027-01-05', endDate: '2027-03-31', isCurrent: false },
    { id: 'term-t3-2026', academicYearId: yearId, name: 'Term 3', order: 3, startDate: '2027-04-01', endDate: '2027-07-15', isCurrent: false },
  ];

  const enrollStudent = (id: string, studentId: string, classSectionId: string): Enrollment => ({
    id,
    studentId,
    classSectionId,
    academicYearId: yearId,
    status: 'active',
    enrolledAt: T('2026-09-01T08:00:00Z'),
  });

  const enrollments: Enrollment[] = [
    enrollStudent('enr-01', 'stu-01', 'cls-7a'),
    enrollStudent('enr-02', 'stu-02', 'cls-7a'),
    enrollStudent('enr-03', 'stu-03', 'cls-7a'),
    enrollStudent('enr-04', 'stu-04', 'cls-7a'),
    enrollStudent('enr-05', 'stu-05', 'cls-7a'),
    enrollStudent('enr-06', 'stu-06', 'cls-7a'),
    enrollStudent('enr-07', 'stu-07', 'cls-8a'),
    enrollStudent('enr-08', 'stu-08', 'cls-8a'),
    enrollStudent('enr-09', 'stu-09', 'cls-8a'),
    enrollStudent('enr-10', 'stu-10', 'cls-8a'),
  ];

  const mkAssignment = (id: string, teacherId: string, classSectionId: string, subjectId: string): TeacherAssignment => ({
    id,
    teacherId,
    classSectionId,
    subjectId,
    academicYearId: yearId,
    createdAt: T('2026-08-28T08:00:00Z'),
  });

  const assignments: TeacherAssignment[] = [
    mkAssignment('asg-01', 'tch-01', 'cls-7a', 'sub-math'),
    mkAssignment('asg-02', 'tch-01', 'cls-8a', 'sub-math'),
    mkAssignment('asg-03', 'tch-02', 'cls-7a', 'sub-eng'),
    mkAssignment('asg-04', 'tch-02', 'cls-8a', 'sub-sci'),
  ];

  const mkAssessment = (
    id: string,
    title: string,
    type: Assessment['type'],
    classSectionId: string,
    subjectId: string,
    maxMarks: number,
    weight: number,
    status: 'draft' | 'submitted',
    createdBy: string,
  ): Assessment => ({
    id,
    title,
    description: null,
    type,
    classSectionId,
    subjectId,
    termId: term1Id,
    maxMarks,
    weight,
    dueDate: null,
    status,
    submittedAt: status === 'submitted' ? T('2026-10-02T12:00:00Z') : null,
    createdBy,
    createdAt: T('2026-09-10T08:00:00Z'),
    updatedAt: T('2026-10-02T12:00:00Z'),
  });

  const assessments: Assessment[] = [
    // Grade 7A Mathematics — complete and submitted (results published)
    mkAssessment('asmt-7a-math-quiz1', 'Mathematics Quiz 1', 'quiz', 'cls-7a', 'sub-math', 20, 20, 'submitted', 'prof-t1'),
    mkAssessment('asmt-7a-math-test1', 'Mathematics Test 1', 'test', 'cls-7a', 'sub-math', 40, 30, 'submitted', 'prof-t1'),
    mkAssessment('asmt-7a-math-exam', 'Mathematics Term Exam', 'exam', 'cls-7a', 'sub-math', 100, 50, 'submitted', 'prof-t1'),
    // Grade 7A English — complete and submitted (results published)
    mkAssessment('asmt-7a-eng-asg1', 'English Essay Assignment', 'assignment', 'cls-7a', 'sub-eng', 20, 40, 'submitted', 'prof-t2'),
    mkAssessment('asmt-7a-eng-quiz1', 'English Vocabulary Quiz', 'quiz', 'cls-7a', 'sub-eng', 20, 60, 'submitted', 'prof-t2'),
    // Grade 8A Mathematics — drafts for the teacher marks-entry workflow
    mkAssessment('asmt-8a-math-quiz1', 'Mathematics Quiz 1', 'quiz', 'cls-8a', 'sub-math', 20, 40, 'draft', 'prof-t1'),
    mkAssessment('asmt-8a-math-test1', 'Mathematics Test 1', 'test', 'cls-8a', 'sub-math', 50, 60, 'draft', 'prof-t1'),
    // Grade 8A Science — submitted, awaiting publication; English — draft, untouched
    mkAssessment('asmt-8a-sci-test1', 'Science Test 1', 'test', 'cls-8a', 'sub-sci', 30, 100, 'submitted', 'prof-t2'),
    mkAssessment('asmt-8a-eng-asg1', 'English Composition Assignment', 'assignment', 'cls-8a', 'sub-eng', 20, 100, 'draft', 'prof-t2'),
  ];

  const mkMark = (
    id: string,
    assessmentId: string,
    studentId: string,
    score: number | null,
    status: Mark['status'],
  ): Mark => ({
    id,
    assessmentId,
    studentId,
    score,
    status,
    enteredBy: assessmentId.includes('math') ? 'prof-t1' : 'prof-t2',
    createdAt: T('2026-10-01T09:00:00Z'),
    updatedAt: T('2026-10-02T12:00:00Z'),
  });

  const g7 = ['stu-01', 'stu-02', 'stu-03', 'stu-04', 'stu-05', 'stu-06'];
  const g8 = ['stu-07', 'stu-08', 'stu-09', 'stu-10'];

  const marks: Mark[] = [
    ...['18', '15', '12', '19', '10', '16'].map((s, i) => mkMark(`mk-q1-${i}`, 'asmt-7a-math-quiz1', g7[i], Number(s), 'submitted')),
    ...['34', '28', '22', '36', '18', '30'].map((s, i) => mkMark(`mk-t1-${i}`, 'asmt-7a-math-test1', g7[i], Number(s), 'submitted')),
    ...['82', '74', '61', '90', '45', '77'].map((s, i) => mkMark(`mk-ex-${i}`, 'asmt-7a-math-exam', g7[i], Number(s), 'submitted')),
    ...['17', '14', '13', '18', '11', '15'].map((s, i) => mkMark(`mk-ea-${i}`, 'asmt-7a-eng-asg1', g7[i], Number(s), 'submitted')),
    ...['16', '15', '11', '19', '12', '14'].map((s, i) => mkMark(`mk-eq-${i}`, 'asmt-7a-eng-quiz1', g7[i], Number(s), 'submitted')),
    ...['25', '20', '27', '15'].map((s, i) => mkMark(`mk-s8-${i}`, 'asmt-8a-sci-test1', g8[i], Number(s), 'submitted')),
    mkMark('mk-8q-0', 'asmt-8a-math-quiz1', 'stu-07', 15, 'draft'),
    mkMark('mk-8q-1', 'asmt-8a-math-quiz1', 'stu-08', 18, 'draft'),
    mkMark('mk-8q-3', 'asmt-8a-math-quiz1', 'stu-10', 12, 'draft'),
  ];

  const publications: ResultPublication[] = [
    {
      id: 'pub-7a-t1',
      classSectionId: 'cls-7a',
      termId: term1Id,
      state: 'published',
      submittedBy: 'prof-t1',
      submittedAt: T('2026-10-05T10:00:00Z'),
      approvedBy: 'prof-admin',
      approvedAt: T('2026-10-07T09:00:00Z'),
      publishedBy: 'prof-admin',
      publishedAt: T('2026-10-08T09:00:00Z'),
      updatedAt: T('2026-10-08T09:00:00Z'),
    },
    {
      id: 'pub-8a-t1',
      classSectionId: 'cls-8a',
      termId: term1Id,
      state: 'draft',
      updatedAt: T('2026-10-03T09:00:00Z'),
    },
  ];


  const mkNotice = (
    id: string,
    title: string,
    body: string,
    category: Notice['category'],
    audience: Notice['audience'],
    status: Notice['status'],
    publishedAt: string | null,
  ): Notice => ({
    id,
    title,
    body,
    category,
    audience,
    status,
    publishedAt,
    expiresAt: null,
    authorName: 'School Administration (demo)',
    createdAt: T('2026-09-20T08:00:00Z'),
    updatedAt: T(publishedAt ?? '2026-09-20T08:00:00Z'),
  });

  const notices: Notice[] = [
    mkNotice(
      'not-01',
      'Admissions open for the next academic year',
      'Applications for the next academic year are now being received.\nVisit the Admissions page for the enquiry form, or contact the school office during working hours. Places are limited and are confirmed only after the admissions process is complete.',
      'admissions',
      'public',
      'published',
      '2026-10-01T08:00:00Z',
    ),
    mkNotice(
      'not-02',
      'Annual sports day',
      'Our annual sports day will be held on the school grounds. Students should arrive in their sports kit. Families will receive detailed programme information from their class teachers.',
      'events',
      'public',
      'published',
      '2026-09-28T08:00:00Z',
    ),
    mkNotice(
      'not-03',
      'Staff development workshop (staff only)',
      'A curriculum alignment workshop will be held this Friday after classes. Attendance is compulsory for all teaching staff.',
      'academic',
      'staff',
      'published',
      '2026-10-03T08:00:00Z',
    ),
    mkNotice(
      'not-04',
      'Term 1 assessment timetable published (students)',
      'The Term 1 assessment timetable is available from your class teacher. Prepare well and revise consistently.',
      'exams',
      'students',
      'published',
      '2026-10-04T08:00:00Z',
    ),
    mkNotice(
      'not-05',
      'Parent–teacher conference schedule (parents)',
      'Parent–teacher conferences will take place over two afternoons. Please book a slot through the school office. Results published in the parent portal are view-only.',
      'academic',
      'parents',
      'published',
      '2026-10-06T08:00:00Z',
    ),
    mkNotice(
      'not-06',
      'Draft: public holiday closure notice',
      'This notice is a draft example. It is not visible to the public until an administrator publishes it.',
      'general',
      'public',
      'draft',
      null,
    ),
  ];

  const audit: AuditLog[] = [
    {
      id: 'aud-01',
      actorId: 'prof-t1',
      actorName: 'Daniel Tesfaye (demo)',
      action: 'results.submit',
      entityType: 'result_publication',
      entityId: 'pub-7a-t1',
      summary: 'Submitted Grade 7A Term 1 results for review.',
      createdAt: T('2026-10-05T10:00:00Z'),
    },
    {
      id: 'aud-02',
      actorId: 'prof-admin',
      actorName: 'Sara Girma (demo)',
      action: 'results.approve',
      entityType: 'result_publication',
      entityId: 'pub-7a-t1',
      summary: 'Approved Grade 7A Term 1 results.',
      createdAt: T('2026-10-07T09:00:00Z'),
    },
    {
      id: 'aud-03',
      actorId: 'prof-admin',
      actorName: 'Sara Girma (demo)',
      action: 'results.publish',
      entityType: 'result_publication',
      entityId: 'pub-7a-t1',
      summary: 'Published Grade 7A Term 1 results for students and parents.',
      createdAt: T('2026-10-08T09:00:00Z'),
    },
  ];

  return {
    profiles,
    credentials,
    students,
    parents,
    parentLinks,
    teachers,
    classSections,
    subjects,
    academicYears,
    terms,
    enrollments,
    assignments,
    assessments,
    marks,
    publications,
    notices,
    audit,
    gradingScale: PLACEHOLDER_GRADING_SCALE,
    contactMessages: [],
    admissionEnquiries: [],
  };
}
