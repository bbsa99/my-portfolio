import { useState, type FormEvent } from 'react';
import { schoolName } from '../../lib/env';
import { admissionEnquirySchema, type AdmissionEnquiryInput } from '../../lib/validation';
import { useRepo } from '../../state/useRepo';
import { errMessage } from '../../state/useAsync';
import { Button } from '../../components/ui/Button';
import { Input, Textarea, Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Card } from '../../components/ui/Card';
import { ProgressiveImage } from '../../components/ui/ProgressiveImage';

const GRADES = ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8'];

const STEPS = [
  'Submit an enquiry using the form below.',
  'Our admissions office will contact you to arrange a visit and assessment.',
  'Receive an offer letter and complete enrolment.',
];

/** Public admissions page with an enquiry form that writes to the repository. */
export function PublicAdmissions() {
  const repo = useRepo();
  const [form, setForm] = useState<AdmissionEnquiryInput>({
    childName: '',
    gradeApplying: '',
    parentName: '',
    email: '',
    phone: '',
    notes: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [busy, setBusy] = useState(false);

  function update<K extends keyof AdmissionEnquiryInput>(key: K, value: AdmissionEnquiryInput[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setFormError(null);
    const parsed = admissionEnquirySchema.safeParse(form);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setBusy(true);
    try {
      await repo.submitAdmissionEnquiry({
        childName: parsed.data.childName,
        gradeApplying: parsed.data.gradeApplying,
        parentName: parsed.data.parentName,
        email: parsed.data.email,
        phone: parsed.data.phone,
        notes: parsed.data.notes && parsed.data.notes.length > 0 ? parsed.data.notes : null,
      });
      setSubmitted(true);
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-14">
      <h1 className="text-3xl font-semibold text-ink-900">Admissions</h1>
      <p className="mt-3 max-w-2xl text-ink-500">
        We welcome enquiries from families throughout the year. Places are limited and confirmed only after the
        admissions process is complete.
      </p>

      <ProgressiveImage
        src="/images/collaboration.jpg"
        alt="Prospective families and students being welcomed at the school"
        wrapperClassName="mt-8 aspect-[21/9] w-full rounded-2xl"
      />

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <h2 className="text-lg font-semibold text-ink-900">How to apply</h2>
          <ol className="mt-4 space-y-4">
            {STEPS.map((step, index) => (
              <li key={step} className="flex gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-800">
                  {index + 1}
                </span>
                <p className="text-sm text-ink-600">{step}</p>
              </li>
            ))}
          </ol>
          <div className="mt-6 rounded-xl border border-ink-200 bg-white p-4 text-sm text-ink-600">
            <p className="font-medium text-ink-800">What to bring</p>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>Child's birth certificate or ID</li>
              <li>Most recent school report (if transferring)</li>
              <li>Parent/guardian contact details</li>
            </ul>
          </div>
        </div>

        <Card className="p-6">
          {submitted ? (
            <Alert variant="success" title="Thank you — enquiry received">
              Our admissions office will be in touch about your enquiry for {form.childName || 'your child'} at{' '}
              {schoolName}. You can submit another enquiry below.
              <div className="mt-4">
                <Button variant="outline" onClick={() => setSubmitted(false)}>
                  Submit another enquiry
                </Button>
              </div>
            </Alert>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-4">
              <h2 className="text-lg font-semibold text-ink-900">Admission enquiry</h2>
              {formError && <Alert variant="danger">{formError}</Alert>}
              <Input
                label="Child's full name"
                value={form.childName}
                error={errors.childName}
                onChange={(e) => update('childName', e.target.value)}
                required
              />
              <Select
                label="Grade applying for"
                value={form.gradeApplying}
                error={errors.gradeApplying}
                onChange={(e) => update('gradeApplying', e.target.value)}
                required
              >
                <option value="">Select a grade…</option>
                {GRADES.map((grade) => (
                  <option key={grade} value={grade}>
                    {grade}
                  </option>
                ))}
              </Select>
              <Input
                label="Parent / guardian name"
                value={form.parentName}
                error={errors.parentName}
                onChange={(e) => update('parentName', e.target.value)}
                required
              />
              <div className="grid gap-4 sm:grid-cols-2">
                <Input
                  label="Email"
                  type="email"
                  value={form.email}
                  error={errors.email}
                  onChange={(e) => update('email', e.target.value)}
                  required
                />
                <Input
                  label="Phone"
                  type="tel"
                  value={form.phone}
                  error={errors.phone}
                  onChange={(e) => update('phone', e.target.value)}
                  required
                />
              </div>
              <Textarea
                label="Anything else we should know? (optional)"
                value={form.notes ?? ''}
                error={errors.notes}
                onChange={(e) => update('notes', e.target.value)}
              />
              <Button type="submit" block loading={busy}>
                Submit enquiry
              </Button>
            </form>
          )}
        </Card>
      </div>
    </div>
  );
}
