/**
 * Password hashing for the demo repository.
 *
 * Passwords are never stored in plain text. We derive a PBKDF2-SHA256 key
 * from the password with a per-credential random salt (100 000 iterations)
 * using the WebCrypto API available in every modern browser, and store:
 *
 *   `pbkdf2$<iterations>$<saltBase64>$<hashBase64>`
 *
 * The same rules define "strong enough" for both the UI (zod) and the
 * repository (mirrors the Supabase-side checks).
 */

const ITERATIONS = 100_000;
const KEY_BITS = 256;

const encoder = new TextEncoder();

function subtle(): SubtleCrypto {
  const api = globalThis.crypto;
  if (!api?.subtle) {
    throw new Error('WebCrypto is unavailable — passwords require a secure context (HTTPS or localhost).');
  }
  return api.subtle;
}

function toBase64(bytes: Uint8Array): string {
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

function fromBase64(value: string): Uint8Array {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function derive(password: string, salt: Uint8Array, iterations: number): Promise<Uint8Array> {
  const key = await subtle().importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await subtle().deriveBits(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    key,
    KEY_BITS,
  );
  return new Uint8Array(bits);
}

/** Hash `password` with a fresh random salt. */
export async function hashPassword(password: string): Promise<string> {
  const salt = globalThis.crypto.getRandomValues(new Uint8Array(16));
  const hash = await derive(password, salt, ITERATIONS);
  return `pbkdf2$${ITERATIONS}$${toBase64(salt)}$${toBase64(hash)}`;
}

/** Verify `password` against a stored `pbkdf2$…` string. */
export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
  const iterations = Number(parts[1]);
  if (!Number.isFinite(iterations) || iterations <= 0) return false;
  try {
    const salt = fromBase64(parts[2]);
    const expected = fromBase64(parts[3]);
    const actual = await derive(password, salt, iterations);
    if (actual.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < actual.length; i += 1) diff |= actual[i] ^ expected[i];
    return diff === 0;
  } catch {
    return false;
  }
}

/** Shared strength rule (mirrored by `passwordSchema` in validation.ts). */
export function isStrongPassword(value: string): boolean {
  return value.length >= 8 && value.length <= 128 && /[A-Za-z]/.test(value) && /\d/.test(value);
}
