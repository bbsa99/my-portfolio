import { Link } from 'react-router-dom';
import { Alert } from './ui/Alert';
import { isDemoMode, schoolName } from '../lib/env';

/** Shown only to signed-in users when the app runs against the local demo
 *  repository (no real authentication provider configured). Hidden on the
 *  public marketing site and hidden entirely when a real auth provider is
 *  configured. */
export function DemoBanner({ inline = false }: { inline?: boolean }) {
  if (!isDemoMode) return null;
  return (
    <Alert
      variant="warning"
      className={`rounded-none border-x-0 border-t-0 px-4 py-2 text-center ${inline ? '' : 'mt-6'}`}
    >
      <span className="font-medium">Demo mode.</span> You are exploring fictional sample data for {schoolName}.{' '}
      Nothing here is a real student record. The secure portal sign-in is not yet wired to a live
      authentication provider.{' '}
      <Link to="/login" className="underline">
        Sign in
      </Link>{' '}
      only works with the sample demo accounts.
    </Alert>
  );
}
