import { useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

const inputBase =
  'block w-full rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 ' +
  'focus:border-brand-500 focus:ring-1 focus:ring-brand-500 disabled:cursor-not-allowed disabled:bg-slate-50';

interface CommonProps {
  label: string;
  error?: string;
  hint?: string;
  required?: boolean;
}

function Wrapper({
  label,
  error,
  hint,
  required,
  htmlFor,
  children,
}: CommonProps & { htmlFor: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={htmlFor} className="block text-sm font-medium text-slate-700">
        {label}
        {required && <span className="ml-0.5 text-red-600">*</span>}
      </label>
      {children}
      {error ? (
        <p className="text-xs text-red-600">{error}</p>
      ) : hint ? (
        <p className="text-xs text-slate-500">{hint}</p>
      ) : null}
    </div>
  );
}

export function TextField({
  label,
  error,
  hint,
  required,
  className,
  id,
  ...rest
}: CommonProps & InputHTMLAttributes<HTMLInputElement>) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  return (
    <Wrapper label={label} error={error} hint={hint} required={required} htmlFor={fieldId}>
      <input
        id={fieldId}
        aria-invalid={error ? true : undefined}
        className={cn(inputBase, error ? 'border-red-400' : 'border-slate-300', className)}
        {...rest}
      />
    </Wrapper>
  );
}

export function SelectField({
  label,
  error,
  hint,
  required,
  className,
  id,
  children,
  ...rest
}: CommonProps & SelectHTMLAttributes<HTMLSelectElement>) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  return (
    <Wrapper label={label} error={error} hint={hint} required={required} htmlFor={fieldId}>
      <select
        id={fieldId}
        aria-invalid={error ? true : undefined}
        className={cn(inputBase, error ? 'border-red-400' : 'border-slate-300', className)}
        {...rest}
      >
        {children}
      </select>
    </Wrapper>
  );
}

export function TextareaField({
  label,
  error,
  hint,
  required,
  className,
  id,
  ...rest
}: CommonProps & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  return (
    <Wrapper label={label} error={error} hint={hint} required={required} htmlFor={fieldId}>
      <textarea
        id={fieldId}
        aria-invalid={error ? true : undefined}
        className={cn(inputBase, 'min-h-24', error ? 'border-red-400' : 'border-slate-300', className)}
        {...rest}
      />
    </Wrapper>
  );
}
