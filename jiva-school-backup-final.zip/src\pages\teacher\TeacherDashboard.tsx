import { Link } from 'react-router-dom';
import { useAsync } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import type { Assessment, ClassSection, TeacherAssignment } from '../../lib/types';

interface TeacherData {
  assignments: TeacherAssignment[];
  classes: ClassSection[];
  assessments: Assessment[];
}

/** Teacher home: the classes/subjects they teach and their assessments. */
export function TeacherDashboard() {
  const repo = useRepo();
  const { data, loading, error } = useAsync<TeacherData>(async () => {
    const [assignments, classes, assessments] = await Promise.all([
      repo.listTeacherAssignments(),
      repo.listClassSections(),
      repo.listAssessments(),
    ]);
    return { assignments, classes, assessments };
  }, [repo]);

  const classLabel = (id: string) => {
    const c = data?.classes.find((x) => x.id === id);
    return c ? `${c.name} ${c.section}` : id;
  };

  const drafts = data?.assessments.filter((a) => a.status === 'draft') ?? [];
  const submitted = data?.assessments.filter((a) => a.status === 'submitted') ?? [];

  return (
    <div>
      <PageHeader
        title="Teacher overview"
        subtitle="Your classes, subjects and assessments."
        actions={
          <Link to="/app/teacher/assessments">
            <Button>Manage assessments</Button>
          </Link>
        }
      />

      {loading && <PageSpinner />}
      {error && <Alert variant="danger">{error}</Alert>}

      {data && (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader title="My teaching load" subtitle="Class and subject assignments for the current year." />
            <CardBody>
              {data.assignments.length === 0 ? (
                <EmptyState title="No assignments yet" description="An administrator will assign your classes and subjects." />
              ) : (
                <ul className="space-y-2">
                  {data.assignments.map((a) => (
                    <li key={a.id} className="flex items-center justify-between rounded-lg border border-ink-200 px-3 py-2 text-sm">
                      <span className="text-ink-700">{classLabel(a.classSectionId)}</span>
                      <Badge tone="brand">Assigned</Badge>
                    </li>
                  ))}
                </ul>
              )}
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Assessments" subtitle="Draft and submitted marks at a glance." />
            <CardBody>
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-xl bg-gold-50 p-4">
                  <p className="text-sm text-gold-800">Drafts</p>
                  <p className="mt-1 font-display text-3xl font-semibold text-gold-900">{drafts.length}</p>
                </div>
                <div className="rounded-xl bg-emerald-50 p-4">
                  <p className="text-sm text-emerald-800">Submitted</p>
                  <p className="mt-1 font-display text-3xl font-semibold text-emerald-900">{submitted.length}</p>
                </div>
              </div>
              <Link
                to="/app/teacher/assessments"
                className="mt-4 inline-block text-sm font-medium text-brand-700 hover:text-brand-800"
              >
                Go to assessments →
              </Link>
            </CardBody>
          </Card>
        </div>
      )}
    </div>
  );
}
