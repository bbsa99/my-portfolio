import { useState, type ReactElement } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../state/AuthContext';
import { ROLE_LABELS, can, type Permission } from '../lib/permissions';
import { schoolName } from '../lib/env';
import { cn } from '../lib/utils';
import type { Role } from '../lib/types';
import { IconBook, IconChart, IconClipboard, IconCog, IconFile, IconGraduation, IconHome, IconLogout, IconMenu, IconShield, IconUsers } from '../components/ui/Icons';
import { PageSpinner } from '../components/ui/Spinner';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { DemoBanner } from '../components/DemoBanner';

interface NavItem { to: string; label: string; icon: (p: { className?: string }) => ReactElement; end?: boolean; permission?: Permission; }

const ADMIN_NAV: NavItem[] = [
  { to: '/app/admin', label: 'Overview', icon: IconHome, end: true },
  { to: '/app/admin/students', label: 'Students', icon: IconUsers, permission: 'students.manage' },
  { to: '/app/admin/teachers', label: 'Staff', icon: IconShield, permission: 'staff.manage' },
  { to: '/app/admin/curriculum', label: 'Curriculum', icon: IconBook, permission: 'academics.manage' },
  { to: '/app/admin/accounts', label: 'Accounts', icon: IconCog, permission: 'accounts.manage' },
  { to: '/app/admin/notices', label: 'Notices', icon: IconFile, permission: 'notices.manage' },
  { to: '/app/admin/review', label: 'Results review', icon: IconClipboard, permission: 'marks.review' },
  { to: '/app/admin/audit', label: 'Audit log', icon: IconChart, permission: 'audit.view' },
];

const TEACHER_NAV: NavItem[] = [
  { to: '/app/teacher', label: 'Overview', icon: IconHome, end: true },
  { to: '/app/teacher/assessments', label: 'Assessments', icon: IconClipboard },
];

const STUDENT_NAV: NavItem[] = [
  { to: '/app/student', label: 'Overview', icon: IconHome, end: true },
  { to: '/app/student/results', label: 'My results', icon: IconFile },
];

const PARENT_NAV: NavItem[] = [{ to: '/app/parent', label: 'Overview', icon: IconHome, end: true }];

const NAV_BY_ROLE: Record<Role, NavItem[]> = { admin: ADMIN_NAV, teacher: TEACHER_NAV, student: STUDENT_NAV, parent: PARENT_NAV };

function SidebarLink({ item, onNavigate }: { item: NavItem; onNavigate?: () => void }) {
  const Icon = item.icon;
  return (
    <NavLink to={item.to} end={item.end} onClick={onNavigate} className={({ isActive }) => cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors', isActive ? 'bg-brand-700 text-white' : 'text-ink-200 hover:bg-brand-800 hover:text-white')}>
      <Icon className="h-5 w-5 shrink-0" />
      {item.label}
    </NavLink>
  );
}

export function DashboardLayout() {
  const { session, signOut } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  if (!session) return <PageSpinner />;
  const { profile } = session;
  const nav = NAV_BY_ROLE[profile.role].filter((item) => !item.permission || can(profile.role, item.permission));

  return (
    <div className="flex min-h-screen bg-ink-50">
      <DemoBanner />
      <aside className={cn('fixed inset-y-0 left-0 z-40 w-64 transform overflow-y-auto bg-brand-900 transition-transform lg:static lg:translate-x-0', menuOpen ? 'translate-x-0' : '-translate-x-full')}>
        <div className="flex h-16 items-center gap-2.5 border-b border-brand-800 px-5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 text-white">
            <IconGraduation className="h-5 w-5" />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-base font-semibold text-white">{schoolName}</span>
            <span className="block text-xs text-brand-200">Staff &amp; student portal</span>
          </span>
        </div>
        <nav className="flex flex-col gap-1 p-3">
          {nav.map((item) => <SidebarLink key={item.to} item={item} onNavigate={() => setMenuOpen(false)} />)}
        </nav>
      </aside>

      {menuOpen && <button type="button" aria-label="Close menu" className="fixed inset-0 z-30 bg-ink-900/40 lg:hidden" onClick={() => setMenuOpen(false)} />}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-ink-200 bg-white px-4 lg:px-8">
          <button type="button" className="rounded-md p-2 text-ink-600 hover:bg-ink-100 lg:hidden" aria-label="Toggle menu" onClick={() => setMenuOpen((v) => !v)}>
            <IconMenu className="h-6 w-6" />
          </button>
          <div className="ml-auto flex items-center gap-3">
            <div className="hidden text-right leading-tight sm:block">
              <p className="text-sm font-medium text-ink-900">{profile.fullName}</p>
              <p className="text-xs text-ink-500">{ROLE_LABELS[profile.role]}</p>
            </div>
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-800">
              {profile.fullName.trim().charAt(0).toUpperCase()}
            </span>
            <Link to="/" className="hidden rounded-lg px-3 py-2 text-sm font-medium text-ink-600 hover:bg-ink-100 md:block">View site</Link>
            <button type="button" onClick={() => void signOut()} className="inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-ink-600 hover:bg-ink-100">
              <IconLogout className="h-4 w-4" /> Sign out
            </button>
          </div>
        </header>

        <main key={location.pathname} className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 lg:px-8">
          <ErrorBoundary key={location.pathname}>
            <Outlet />
          </ErrorBoundary>
        </main>
      </div>
    </div>
  );
}
