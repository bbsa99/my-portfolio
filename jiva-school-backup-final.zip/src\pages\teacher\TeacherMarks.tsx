import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { validateMarkScore } from '../../lib/grading';
import type { Assessment, Mark, Student } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { PageSpinner } from '../../components/ui/Spinner';
import { useToast } from '../../components/Toast';

interface MarksData {
  assessment: Assessment;
  students: Student[];
  marks: Mark[];
}

/** Marks entry grid for one assessment — save drafts, then submit to lock. */
export function TeacherMarks() {
  const { assessmentId = '' } = useParams();
  const repo = useRepo();
  const toast = useToast();
  const navigate = useNavigate();

  const [scores, setScores] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const { data, loading, error, reload } = useAsync<MarksData>(async () => {
    const assessments = await repo.listAssessments();
    const assessment = assessments.find((a) => a.id === assessmentId);
    if (!assessment) throw new Error('Assessment not found.');
    const marks = await repo.listMarks(assessment.id);
    // Enrolled students in the assessment's class.
    const enrollments = await repo.listEnrollments({ classSectionId: assessment.classSectionId });
    const students = await repo.listStudents({ classSectionId: assessment.classSectionId, pageSize: 500 });
    void enrollments;
    return { assessment, students: students.items, marks };
  }, [repo, assessmentId]);

  function markFor(studentId: string): Mark | undefined {
    return data?.marks.find((m) => m.studentId === studentId);
  }

  function scoreValue(studentId: string): string {
    if (scores[studentId] !== undefined) return scores[studentId];
    const mark = markFor(studentId);
    return mark && mark.score !== null ? String(mark.score) : '';
  }

  function onScoreChange(studentId: string, value: string) {
    setScores((prev) => ({ ...prev, [studentId]: value }));
  }

  async function saveDrafts() {
    if (!data) return;
    setSaving(true);
    try {
      const drafts = data.students.map((s) => {
        const raw = scores[s.id];
        const value = raw === undefined || raw.trim() === '' ? null : Number(raw);
        return { assessmentId: data.assessment.id, studentId: s.id, score: value };
      });
      // Client-side validation mirrors the server rules.
      for (const d of drafts) {
        const check = validateMarkScore(d.score, data.assessment.maxMarks);
        if (!check.ok) {
          toast.push('error', check.error ?? 'Invalid mark.');
          setSaving(false);
          return;
        }
      }
      await repo.saveMarkDrafts(drafts);
      toast.push('success', 'Draft marks saved.');
      setScores({});
      reload();
    } catch (err) {
      toast.push('error', errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  async function submit() {
    if (!data) return;
    setSubmitting(true);
    try {
      await repo.submitAssessmentMarks(data.assessment.id);
      toast.push('success', 'Marks submitted for review.');
      reload();
    } catch (err) {
      toast.push('error', errMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  async function reopen() {
    if (!data) return;
    try {
      await repo.reopenAssessment(data.assessment.id);
      toast.push('success', 'Assessment reopened for editing.');
      reload();
    } catch (err) {
      toast.push('error', errMessage(err));
    }
  }

  if (loading) return <PageSpinner />;
  if (error) return <Alert variant="danger">{error}</Alert>;
  if (!data) return <Alert variant="warning">Assessment not found.</Alert>;

  const { assessment, students } = data;
  const locked = assessment.status === 'submitted';

  return (
    <div>
      <PageHeader
        title={assessment.title}
        subtitle={`Max marks: ${assessment.maxMarks} · Weight: ${assessment.weight}%`}
        actions={
          <Button variant="outline" onClick={() => navigate('/app/teacher/assessments')}>
            ← Back to assessments
          </Button>
        }
      />

      <Card>
        <CardHeader
          title="Marks"
          subtitle={`${students.length} students`}
          action={<Badge tone={locked ? 'success' : 'warning'}>{locked ? 'Submitted (locked)' : 'Draft'}</Badge>}
        />
        <CardBody className="space-y-4">
          {locked && (
            <Alert variant="info">
              These marks have been submitted and are locked. Reopen the assessment to make further changes.
            </Alert>
          )}

          {students.length === 0 ? (
            <p className="text-sm text-ink-500">No students are enrolled in this class.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-ink-200 text-left text-xs font-semibold tracking-wide text-ink-500 uppercase">
                    <th className="px-3 py-2">Student</th>
                    <th className="px-3 py-2">Student ID</th>
                    <th className="px-3 py-2 text-right">Mark (out of {assessment.maxMarks})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-100">
                  {students.map((s) => (
                    <tr key={s.id}>
                      <td className="px-3 py-2 text-ink-800">{s.fullName}</td>
                      <td className="px-3 py-2 text-ink-500">{s.studentId}</td>
                      <td className="px-3 py-2 text-right">
                        <input
                          type="number"
                          min={0}
                          max={assessment.maxMarks}
                          step="0.01"
                          disabled={locked}
                          value={scoreValue(s.id)}
                          onChange={(e) => onScoreChange(s.id, e.target.value)}
                          className="w-28 rounded-lg border border-ink-300 px-2 py-1 text-right disabled:bg-ink-100"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {!locked && students.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <Button loading={saving} onClick={() => void saveDrafts()}>
                Save drafts
              </Button>
              <Button variant="secondary" loading={submitting} onClick={() => void submit()}>
                Submit marks for review
              </Button>
            </div>
          )}

          {locked && (
            <Button variant="outline" onClick={() => void reopen()}>
              Reopen for editing
            </Button>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
