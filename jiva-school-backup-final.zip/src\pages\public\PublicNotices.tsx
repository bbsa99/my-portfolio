import { formatDate, noticeParagraphs } from '../../lib/utils';
import { Badge } from '../../components/ui/Badge';
import { Card, CardBody } from '../../components/ui/Card';
import { PageSpinner } from '../../components/ui/Spinner';
import { EmptyState } from '../../components/ui/Spinner';
import { Alert } from '../../components/ui/Alert';
import { useAsync } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import type { NoticeCategory } from '../../lib/types';

const CATEGORY_TONE: Record<NoticeCategory, 'neutral' | 'brand' | 'gold' | 'info' | 'warning' | 'danger'> = {
  general: 'neutral',
  admissions: 'brand',
  academic: 'info',
  events: 'gold',
  exams: 'warning',
  urgent: 'danger',
};

/** Public notices board — published, public-audience notices only. */
export function PublicNotices() {
  const repo = useRepo();
  const { data: notices, loading, error } = useAsync(() => repo.listNotices({ status: 'published' }), [repo]);

  return (
    <div className="mx-auto max-w-4xl px-4 py-14">
      <h1 className="text-3xl font-semibold text-ink-900">Notices &amp; announcements</h1>
      <p className="mt-3 text-ink-500">The latest news and announcements for our school community.</p>

      <div className="mt-8 space-y-4">
        {loading && <PageSpinner />}
        {error && <Alert variant="danger">{error}</Alert>}
        {notices && notices.length === 0 && (
          <EmptyState title="No notices yet" description="Please check back soon for the latest announcements." />
        )}
        {notices?.map((notice) => (
          <Card key={notice.id}>
            <CardBody>
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={CATEGORY_TONE[notice.category]}>{notice.category}</Badge>
                <span className="text-xs text-ink-400">
                  {notice.publishedAt ? formatDate(notice.publishedAt) : formatDate(notice.createdAt)}
                </span>
              </div>
              <h2 className="mt-2 text-lg font-semibold text-ink-900">{notice.title}</h2>
              <div className="mt-2 space-y-2 text-sm text-ink-600">
                {noticeParagraphs(notice.body).map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
