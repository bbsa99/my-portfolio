import { useState } from 'react';
import { useAsync } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { formatDateTime } from '../../lib/utils';
import type { AuditLog } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card } from '../../components/ui/Card';
import { Input } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { DataTable, type Column } from '../../components/ui/DataTable';
import type { Paginated } from '../../lib/repo/types';

/** Read-only audit trail of privileged actions across the system. */
export function AdminAudit() {
  const repo = useRepo();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data, loading, error } = useAsync<Paginated<AuditLog>>(
    () => repo.listAuditLogs({ search, page, pageSize: 15 }),
    [repo, search, page],
  );

  const columns: Array<Column<AuditLog>> = [
    { key: 'when', header: 'When', render: (a) => <span className="whitespace-nowrap text-ink-500">{formatDateTime(a.createdAt)}</span> },
    { key: 'actor', header: 'Actor', render: (a) => a.actorName },
    { key: 'action', header: 'Action', render: (a) => <Badge tone="neutral">{a.action}</Badge> },
    {
      key: 'summary',
      header: 'Details',
      render: (a) => (
        <div>
          <p className="text-ink-700">{a.summary}</p>
          {a.details && <p className="mt-0.5 text-xs text-ink-400">{a.details}</p>}
        </div>
      ),
    },
  ];

  const total = data?.total ?? 0;
  const pageSize = data?.pageSize ?? 15;
  const pageCount = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <PageHeader title="Audit log" subtitle="A record of privileged actions for accountability." />

      <Card>
        <div className="border-b border-ink-100 p-4">
          <Input
            placeholder="Search by actor, action or summary…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>
        {loading && <PageSpinner />}
        {error && (
          <div className="p-4">
            <Alert variant="danger">{error}</Alert>
          </div>
        )}
        {data && (
          <DataTable
            columns={columns}
            rows={data.items}
            rowKey={(a) => a.id}
            caption="Audit log"
            empty={<EmptyState title="No audit entries" description="Privileged actions will appear here." />}
          />
        )}
        {data && total > pageSize && (
          <div className="flex items-center justify-between border-t border-ink-100 px-4 py-3 text-sm text-ink-500">
            <span>
              Page {data.page} of {pageCount} · {total} entries
            </span>
            <div className="flex gap-2">
              <button className="rounded border border-ink-300 px-2 py-1 disabled:opacity-50" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </button>
              <button className="rounded border border-ink-300 px-2 py-1 disabled:opacity-50" disabled={page >= pageCount} onClick={() => setPage((p) => p + 1)}>
                Next
              </button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
