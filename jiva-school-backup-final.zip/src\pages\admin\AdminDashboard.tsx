import { Link } from 'react-router-dom';
import { useAsync } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Alert } from '../../components/ui/Alert';
import { PageSpinner } from '../../components/ui/Spinner';
import { Badge } from '../../components/ui/Badge';
import type { DashboardStats } from '../../lib/types';

function StatCard({ label, value, to }: { label: string; value: number | string; to?: string }) {
  const content = (
    <Card className={to ? 'transition-colors hover:border-brand-300' : undefined}>
      <CardBody>
        <p className="text-sm text-ink-500">{label}</p>
        <p className="mt-1 font-display text-3xl font-semibold text-ink-900">{value}</p>
      </CardBody>
    </Card>
  );
  return to ? <Link to={to}>{content}</Link> : content;
}

/** Administrator overview: key counts and shortcuts. */
export function AdminDashboard() {
  const repo = useRepo();
  const { data, loading, error } = useAsync<DashboardStats>(() => repo.getDashboardStats(), [repo]);

  return (
    <div>
      <PageHeader title="Administrator overview" subtitle="A snapshot of activity across the school." />

      {loading && <PageSpinner />}
      {error && <Alert variant="danger">{error}</Alert>}

      {data && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Active students" value={data.students} to="/app/admin/students" />
            <StatCard label="Teaching staff" value={data.teachers} to="/app/admin/teachers" />
            <StatCard label="Classes" value={data.classes} to="/app/admin/curriculum" />
            <StatCard label="Subjects" value={data.subjects} to="/app/admin/curriculum" />
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            <StatCard label="Results awaiting approval" value={data.pendingApprovals} to="/app/admin/review" />
            <StatCard label="Published terms" value={data.publishedTerms} to="/app/admin/review" />
            <StatCard label="Published notices" value={data.publishedNotices} to="/app/admin/notices" />
          </div>

          <Card className="mt-6">
            <CardHeader
              title="Quick actions"
              subtitle="Common administrative tasks."
              action={<Badge tone="brand">{data.pendingApprovals} to review</Badge>}
            />
            <CardBody className="flex flex-wrap gap-2">
              <Link to="/app/admin/students" className="rounded-lg bg-brand-700 px-3 py-2 text-sm font-medium text-white hover:bg-brand-800">
                Manage students
              </Link>
              <Link to="/app/admin/teachers" className="rounded-lg border border-ink-300 px-3 py-2 text-sm font-medium text-ink-700 hover:bg-ink-50">
                Manage staff
              </Link>
              <Link to="/app/admin/accounts" className="rounded-lg border border-ink-300 px-3 py-2 text-sm font-medium text-ink-700 hover:bg-ink-50">
                Manage accounts
              </Link>
              <Link to="/app/admin/review" className="rounded-lg border border-ink-300 px-3 py-2 text-sm font-medium text-ink-700 hover:bg-ink-50">
                Review results
              </Link>
            </CardBody>
          </Card>
        </>
      )}
    </div>
  );
}
