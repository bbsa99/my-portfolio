import { z } from 'zod';

/** Shared field-level rules used by forms AND mirrored by the database. */

export const emailSchema = z.string().trim().min(1, 'Email is required.').email('Enter a valid email address.');

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters.')
  .max(128, 'Password is too long.')
  .refine((value) => /[A-Za-z]/.test(value) && /\d/.test(value), {
    message: 'Include at least one letter and one number.',
  });

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Password is required.'),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const contactSchema = z.object({
  name: z.string().trim().min(2, 'Please enter your full name.').max(120),
  email: emailSchema,
  phone: z
    .string()
    .trim()
    .max(30, 'Phone number is too long.')
    .regex(/^[0-9+\-\s()]*$/, 'Phone number contains invalid characters.')
    .optional()
    .or(z.literal('')),
  subject: z.string().trim().min(2, 'Please add a subject.').max(160),
  message: z
    .string()
    .trim()
    .min(10, 'Message must be at least 10 characters.')
    .max(3000, 'Message must be 3000 characters or fewer.'),
});
export type ContactInput = z.infer<typeof contactSchema>;

export const admissionEnquirySchema = z.object({
  childName: z.string().trim().min(2, "Enter the child's full name.").max(120),
  gradeApplying: z.string().trim().min(1, 'Select the grade being applied for.'),
  parentName: z.string().trim().min(2, 'Enter the parent or guardian name.').max(120),
  email: emailSchema,
  phone: z
    .string()
    .trim()
    .min(7, 'Enter a contact phone number.')
    .max(30)
    .regex(/^[0-9+\-\s()]+$/, 'Phone number contains invalid characters.'),
  notes: z.string().trim().max(1000).optional().or(z.literal('')),
});
export type AdmissionEnquiryInput = z.infer<typeof admissionEnquirySchema>;

export const studentSchema = z.object({
  fullName: z.string().trim().min(2, "Enter the student's full name.").max(120),
  dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD format.').optional().or(z.literal('')),
  gender: z.enum(['male', 'female', 'other', '']).optional(),
  admissionDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD format.').optional().or(z.literal('')),
  guardianName: z.string().trim().max(120).optional().or(z.literal('')),
  guardianPhone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s()]*$/, 'Phone number contains invalid characters.')
    .max(30)
    .optional()
    .or(z.literal('')),
  address: z.string().trim().max(300).optional().or(z.literal('')),
  status: z.enum(['active', 'inactive', 'graduated', 'transferred']),
});
export type StudentInput = z.infer<typeof studentSchema>;

export const classSectionSchema = z.object({
  name: z.string().trim().min(2, 'Enter the class name, e.g. "Grade 7".').max(60),
  section: z.string().trim().min(1, 'Enter a section, e.g. "A".').max(10),
  gradeLevel: z.coerce.number().int('Grade must be a whole number.').min(1).max(12),
});
export type ClassSectionInput = z.infer<typeof classSectionSchema>;

export const subjectSchema = z.object({
  code: z.string().trim().min(2, 'Enter a subject code.').max(12),
  name: z.string().trim().min(2, 'Enter the subject name.').max(80),
  isCore: z.boolean(),
});
export type SubjectInput = z.infer<typeof subjectSchema>;

export const assessmentSchema = z
  .object({
    title: z.string().trim().min(2, 'Enter the assessment title.').max(140),
    type: z.enum(['assignment', 'quiz', 'test', 'exam']),
    subjectId: z.string().min(1, 'Select a subject.'),
    classSectionId: z.string().min(1, 'Select a class.'),
    termId: z.string().min(1, 'Select a term.'),
    maxMarks: z.coerce.number().positive('Maximum marks must be greater than zero.').max(1000),
    weight: z.coerce
      .number()
      .positive('Weight must be greater than zero.')
      .max(100, 'Weight cannot exceed 100.'),
    dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD format.').optional().or(z.literal('')),
    description: z.string().trim().max(1000).optional().or(z.literal('')),
  });
export type AssessmentInput = z.infer<typeof assessmentSchema>;

/** Self-service sign-up — mirrored by `LocalRepository.register`. */
export const registerSchema = z
  .object({
    fullName: z.string().trim().min(2, 'Enter your full name.').max(120),
    email: emailSchema,
    password: passwordSchema,
    confirm: z.string(),
    role: z.enum(['student', 'parent']),
  })
  .refine((value) => value.password === value.confirm, {
    message: 'Passwords do not match.',
    path: ['confirm'],
  });
export type RegisterFormInput = z.infer<typeof registerSchema>;
