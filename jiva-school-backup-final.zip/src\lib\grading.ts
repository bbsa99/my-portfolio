import type { Assessment, GradeBoundary, GradingScale, Mark, Subject, SubjectResult } from './types';

/**
 * Grading engine — pure, deterministic functions.
 *
 * IMPORTANT: The default scale below is a TECHNICAL PLACEHOLDER so the system
 * can be demonstrated end-to-end. Jiva School management must supply the
 * official, approved grade boundaries (letters, thresholds, remarks) before
 * real report cards are issued. See README -> "Configuring the grading scale".
 */

export const PLACEHOLDER_SCALE_NOTE =
  'Placeholder grading scale for demonstration only. Replace with the school-approved grading rules before issuing real report cards.';

/** Placeholder scale — NOT an official Jiva School grading scale. */
export const PLACEHOLDER_GRADING_SCALE: GradingScale = {
  id: 'scale-placeholder',
  name: 'Default (placeholder) scale',
  isDefault: true,
  isPlaceholder: true,
  note: PLACEHOLDER_SCALE_NOTE,
  boundaries: [
    { letter: 'A', minPercent: 90, maxPercent: 100, gpaPoints: 4, remark: 'Outstanding' },
    { letter: 'B', minPercent: 80, maxPercent: 89.99, gpaPoints: 3, remark: 'Very good' },
    { letter: 'C', minPercent: 70, maxPercent: 79.99, gpaPoints: 2, remark: 'Good' },
    { letter: 'D', minPercent: 60, maxPercent: 69.99, gpaPoints: 1, remark: 'Satisfactory' },
    { letter: 'E', minPercent: 50, maxPercent: 59.99, gpaPoints: 0.5, remark: 'Needs improvement' },
    { letter: 'F', minPercent: 0, maxPercent: 49.99, gpaPoints: 0, remark: 'Fail' },
  ],
};

/** Find the grade boundary matching a percentage (inclusive range). */
export function boundaryForPercent(
  percent: number,
  scale: GradingScale = PLACEHOLDER_GRADING_SCALE,
): GradeBoundary | null {
  if (!Number.isFinite(percent)) return null;
  const match = scale.boundaries.find((b) => percent >= b.minPercent && percent <= b.maxPercent);
  return match ?? null;
}

export interface MarkValidationResult {
  ok: boolean;
  error?: string;
}

/**
 * Server/database-enforced rule mirrored on the client:
 * a mark must be a number (or null while unmarked) within [0, maxMarks].
 * At most 2 decimal places are accepted.
 */
export function validateMarkScore(
  score: number | null | undefined,
  maxMarks: number,
): MarkValidationResult {
  if (score === null || score === undefined) return { ok: true };
  if (typeof score !== 'number' || Number.isNaN(score) || !Number.isFinite(score)) {
    return { ok: false, error: 'Mark must be a valid number.' };
  }
  if (score < 0) return { ok: false, error: 'Mark cannot be negative.' };
  if (maxMarks <= 0) {
    return { ok: false, error: 'Assessment maximum marks must be greater than zero.' };
  }
  if (score > maxMarks) return { ok: false, error: `Mark cannot exceed the maximum of ${maxMarks}.` };
  const rounded = Math.round(score * 100) / 100;
  if (Math.abs(rounded - score) > 1e-9) {
    return { ok: false, error: 'Mark may have at most 2 decimal places.' };
  }
  return { ok: true };
}

export function clampMark(score: number, maxMarks: number): number {
  const safe = Math.max(0, Math.min(maxMarks, score));
  return Math.round(safe * 100) / 100;
}

export function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

export interface SubjectResultInput {
  subject: Subject;
  assessments: Assessment[];
  marks: Mark[];
  teacherName?: string | null;
  scale?: GradingScale;
}

/**
 * Compute the result of one student in one subject for one term.
 * - `percentage` uses raw totals (obtained / maximum).
 * - `weightedPercentage` applies configured weights when they are complete
 *   (weights sum to 100 and every assessment has a numeric mark).
 */
export function computeSubjectResult(input: SubjectResultInput): SubjectResult {
  const { subject, assessments, marks, teacherName } = input;
  const scale = input.scale ?? PLACEHOLDER_GRADING_SCALE;

  const markByAssessment = new Map<string, Mark>();
  for (const mark of marks) markByAssessment.set(mark.assessmentId, mark);

  let obtained = 0;
  let maximum = 0;
  let weightedNumerator = 0;
  let weightTotal = 0;
  let completeForWeighting = assessments.length > 0;

  for (const assessment of assessments) {
    maximum += assessment.maxMarks;
    weightTotal += assessment.weight;
    const mark = markByAssessment.get(assessment.id);
    if (mark && mark.score !== null) {
      obtained += mark.score;
      weightedNumerator += (mark.score / assessment.maxMarks) * assessment.weight;
    } else {
      completeForWeighting = false;
    }
  }

  const percentage = maximum > 0 ? (obtained / maximum) * 100 : 0;
  const weightsSumTo100 = Math.abs(weightTotal - 100) < 0.01;
  const weightedPercentage =
    completeForWeighting && weightsSumTo100 ? round2(weightedNumerator) : null;

  const effectivePercent = weightedPercentage ?? percentage;
  const boundary = boundaryForPercent(effectivePercent, scale);

  return {
    subjectId: subject.id,
    subjectName: subject.name,
    subjectCode: subject.code,
    obtained: round2(obtained),
    maximum: round2(maximum),
    percentage: round2(percentage),
    weightedPercentage,
    grade: boundary?.letter ?? '—',
    gradeRemark: boundary?.remark ?? 'Not available',
    assessmentCount: assessments.length,
    teacherName: teacherName ?? null,
  };
}

/** Overall grade + totals across subjects. */
export function summarizeSubjects(
  subjects: SubjectResult[],
  scale: GradingScale = PLACEHOLDER_GRADING_SCALE,
): {
  totalObtained: number;
  totalMaximum: number;
  overallPercentage: number;
  weightedOverallPercentage: number | null;
  overallGrade: string;
} {
  const totalObtained = round2(subjects.reduce((s, r) => s + r.obtained, 0));
  const totalMaximum = round2(subjects.reduce((s, r) => s + r.maximum, 0));
  const overallPercentage = totalMaximum > 0 ? round2((totalObtained / totalMaximum) * 100) : 0;

  const weightedValues = subjects.map((s) => s.weightedPercentage).filter((v): v is number => v !== null);
  const weightedOverallPercentage =
    weightedValues.length > 0 && weightedValues.length === subjects.length
      ? round2(weightedValues.reduce((a, b) => a + b, 0) / weightedValues.length)
      : null;

  const boundary = boundaryForPercent(weightedOverallPercentage ?? overallPercentage, scale);
  return {
    totalObtained,
    totalMaximum,
    overallPercentage,
    weightedOverallPercentage,
    overallGrade: boundary?.letter ?? '—',
  };
}

/** Rank students within a class by percentage (1 = best). Ties share a rank. */
export function rankByPercentages(percentages: Map<string, number>, studentId: string): number | null {
  const values = [...percentages.values()].sort((a, b) => b - a);
  const target = percentages.get(studentId);
  if (target === undefined) return null;
  const index = values.findIndex((v) => Math.abs(v - target) < 1e-9);
  return index === -1 ? null : index + 1;
}
