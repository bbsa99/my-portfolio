import { beforeEach, describe, expect, it } from 'vitest';
import { LocalRepository, resetDemoDb } from './localRepository';

/**
 * Behavioural tests for the demo repository. These run in local mode (see
 * vite.config test.env) and exercise the same application-level guards that
 * mirror the Supabase RLS policies.
 */

const TERM = 'term-t1-2026';

async function signIn(repo: LocalRepository, email: string, password: string) {
  return repo.signIn(email, password);
}

describe('LocalRepository', () => {
  let repo: LocalRepository;

  beforeEach(() => {
    resetDemoDb();
    repo = new LocalRepository();
  });

  describe('auth', () => {
    it('signs in a known account and exposes a session', async () => {
      const session = await signIn(repo, 'admin@jivademo.test', 'DemoAdmin!23');
      expect(session.profile.role).toBe('admin');
      expect(repo.getSession()?.profile.email).toBe('admin@jivademo.test');
    });

    it('rejects a wrong password with a generic error', async () => {
      await expect(signIn(repo, 'admin@jivademo.test', 'nope')).rejects.toThrow('Invalid email or password.');
    });

    it('clears the session on sign out', async () => {
      await signIn(repo, 'admin@jivademo.test', 'DemoAdmin!23');
      await repo.signOut();
      expect(repo.getSession()).toBeNull();
    });
  });

  describe('role scoping', () => {
    it('student sees only their own record', async () => {
      await signIn(repo, 'student@jivademo.test', 'DemoStudent!23');
      const page = await repo.listStudents({ pageSize: 100 });
      expect(page.items).toHaveLength(1);
      expect(page.items[0].fullName).toBe('David Bekele');
    });

    it('parent sees only their linked children', async () => {
      await signIn(repo, 'parent@jivademo.test', 'DemoParent!23');
      const children = await repo.getMyChildren();
      expect(children.map((c) => c.fullName).sort()).toEqual(['David Bekele', 'Ruth Bekele']);
    });

    it('student cannot read another student result', async () => {
      await signIn(repo, 'student@jivademo.test', 'DemoStudent!23');
      await expect(repo.getPublishedResult('stu-02', TERM)).rejects.toThrow('You can only view your own results.');
    });
  });

  describe('permission guards', () => {
    it('a student cannot manage students', async () => {
      await signIn(repo, 'student@jivademo.test', 'DemoStudent!23');
      await expect(repo.listTeachers()).rejects.toThrow('You do not have permission');
    });

    it('requires auth before listing classes', async () => {
      await expect(repo.listClassSections()).rejects.toThrow('Please sign in');
    });
  });

  describe('published results', () => {
    it('returns the published Grade 7A result for the student', async () => {
      await signIn(repo, 'student@jivademo.test', 'DemoStudent!23');
      const result = await repo.getPublishedResult('stu-01', TERM);
      expect(result).not.toBeNull();
      expect(result?.classSectionName).toContain('Grade 7');
      expect(result?.subjects.map((s) => s.subjectName)).toContain('Mathematics');
      expect(result?.state).toBe('published');
    });

    it('does not expose unpublished Grade 8A results', async () => {
      await signIn(repo, 'student@jivademo.test', 'DemoStudent!23');
      // stu-07 is in Grade 8A whose results are only a draft.
      const me = repo.getSession()?.profile;
      expect(me?.role).toBe('student');
      await expect(repo.getPublishedResult('stu-07', TERM)).rejects.toThrow();
    });
  });

  describe('marks entry workflow', () => {
    it('blocks submitting when marks are missing for enrolled students', async () => {
      await signIn(repo, 'teacher1@jivademo.test', 'DemoTeacher!23');
      // asmt-8a-math-quiz1 is a draft with only some marks entered.
      const check = await repo.checkSubmissionReadiness('asmt-8a-math-quiz1');
      expect(check.ok).toBe(false);
      expect(check.missing[0].studentNames.length).toBeGreaterThan(0);
    });

    it('validates draft marks against the assessment maximum', async () => {
      await signIn(repo, 'teacher1@jivademo.test', 'DemoTeacher!23');
      await expect(
        repo.saveMarkDrafts([{ assessmentId: 'asmt-8a-math-quiz1', studentId: 'stu-07', score: 999 }]),
      ).rejects.toThrow(/exceed the maximum/);
    });
  });

  describe('results publication workflow', () => {
    it('admin can approve and publish Grade 8A after it is submitted', async () => {
      // Teacher submits Grade 8A first.
      await signIn(repo, 'teacher2@jivademo.test', 'DemoTeacher!23');
      // Grade 8A science is submitted but English is a draft, so submitting the
      // class fails until all assessments are submitted. Use admin to drive it.
      await repo.signOut();

      await signIn(repo, 'admin@jivademo.test', 'DemoAdmin!23');
      // Approve requires a prior submission; seed 8A is draft so this should fail.
      await expect(repo.approveClassResults('cls-8a', TERM)).rejects.toThrow('Only submitted results');
    });

    it('admin dashboard stats count active records', async () => {
      await signIn(repo, 'admin@jivademo.test', 'DemoAdmin!23');
      const stats = await repo.getDashboardStats();
      expect(stats.students).toBe(10);
      expect(stats.teachers).toBe(2);
      expect(stats.classes).toBe(2);
      expect(stats.publishedTerms).toBe(1);
    });
  });
});
