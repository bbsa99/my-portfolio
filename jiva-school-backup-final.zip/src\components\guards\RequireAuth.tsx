import { Navigate, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { useAuth } from '../../state/AuthContext';

const FullPageSpinner = (
  <div className="flex min-h-[50vh] items-center justify-center">
    <span className="h-6 w-6 animate-spin rounded-full border-2 border-brand-600 border-t-transparent" />
  </div>
);

/** Require any authenticated session; otherwise bounce to /login. */
export function RequireAuth({ children }: { children: ReactNode }) {
  const { session, ready } = useAuth();
  const location = useLocation();
  if (!ready) return FullPageSpinner;
  if (!session) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return <>{children}</>;
}
