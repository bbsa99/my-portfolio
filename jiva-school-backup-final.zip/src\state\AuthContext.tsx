import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import type { Session } from '../lib/types';
import type { RegisterInput } from '../lib/repo/types';
import { useRepo } from './useRepo';
import { errMessage } from './useAsync';

/**
 * Authentication state for the whole app.
 *
 * The repository owns the session (localStorage in demo mode, Supabase auth
 * otherwise). This context subscribes to it and exposes a tiny API the UI
 * uses: the current session, a `ready` flag, and sign-in / sign-out actions.
 */
export interface AuthContextValue {
  session: Session | null;
  /** True once the initial session has been read from the repository. */
  ready: boolean;
  /** Alias of `ready` kept for guard components that expect `loading`. */
  loading: boolean;
  signIn: (email: string, password: string) => Promise<Session>;
  /** Self-service sign-up (student/parent only); signs the user in on success. */
  register: (input: RegisterInput) => Promise<Session>;
  signOut: () => Promise<void>;
  refresh: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const repo = useRepo();
  const [session, setSession] = useState<Session | null>(() => repo.getSession());
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Adopt whatever session the repository restored on construction, then
    // subscribe for subsequent changes (sign-in/out from any component).
    setSession(repo.getSession());
    setReady(true);
    const unsubscribe = repo.subscribe((next) => setSession(next));
    return unsubscribe;
  }, [repo]);

  const signIn = useCallback(
    async (email: string, password: string) => {
      const next = await repo.signIn(email, password);
      setSession(next);
      return next;
    },
    [repo],
  );

  const register = useCallback(
    async (input: RegisterInput) => {
      const next = await repo.register(input);
      setSession(next);
      return next;
    },
    [repo],
  );

  const signOut = useCallback(async () => {
    await repo.signOut();
    setSession(null);
  }, [repo]);

  const refresh = useCallback(() => setSession(repo.getSession()), [repo]);

  const value = useMemo<AuthContextValue>(
    () => ({ session, ready, loading: ready, signIn, register, signOut, refresh }),
    [session, ready, signIn, register, signOut, refresh],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}

/** Helper for pages that need to surface a thrown error as a string. */
export { errMessage };
