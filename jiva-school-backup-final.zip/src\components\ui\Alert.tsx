import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

type Variant = 'info' | 'success' | 'warning' | 'danger' | 'brand';

const VARIANT_CLASS: Record<Variant, string> = {
  info: 'bg-sky-50 text-sky-800 border-sky-200',
  success: 'bg-emerald-50 text-emerald-800 border-emerald-200',
  warning: 'bg-amber-50 text-amber-800 border-amber-200',
  danger: 'bg-rose-50 text-rose-800 border-rose-200',
  brand: 'bg-brand-50 text-brand-800 border-brand-200',
};

export function Alert({ variant = 'info', title, className, children }: { variant?: Variant; title?: ReactNode; className?: string; children?: ReactNode }) {
  return (
    <div className={cn('rounded-lg border px-4 py-3 text-sm', VARIANT_CLASS[variant], className)} role={variant === 'danger' ? 'alert' : 'status'}>
      {title && <p className="font-semibold">{title}</p>}
      {children && <div className={cn(Boolean(title) && 'mt-1', 'space-y-1')}>{children}</div>}
    </div>
  );
}
