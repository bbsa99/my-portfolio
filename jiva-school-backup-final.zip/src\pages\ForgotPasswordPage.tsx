import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { useRepo } from '../state/useRepo';
import { errMessage } from '../state/useAsync';
import { emailSchema } from '../lib/validation';
import { isDemoMode, schoolName } from '../lib/env';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { Card } from '../components/ui/Card';
import { IconGraduation } from '../components/ui/Icons';

/** Password reset request. Always shows the same confirmation (no enumeration). */
export function ForgotPasswordPage() {
  const repo = useRepo();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setFormError(null);
    const parsed = emailSchema.safeParse(email);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? 'Enter a valid email address.');
      return;
    }
    setError(null);
    setBusy(true);
    try {
      await repo.requestPasswordReset(parsed.data);
      setSent(true);
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink-50 px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-700 text-white">
            <IconGraduation className="h-7 w-7" />
          </span>
          <h1 className="mt-4 text-2xl font-semibold text-ink-900">Reset your password</h1>
          <p className="mt-1 text-sm text-ink-500">
            {isDemoMode
              ? 'Password resets in demo mode are handled by the school office.'
              : `Enter your ${schoolName} account email and we'll send reset instructions.`}
          </p>
        </div>

        <Card className="p-6">
          {isDemoMode ? (
            <div className="space-y-4">
              <Alert variant="warning" title="Resets are handled by the school office">
                This deployment runs in demo mode without an email service, so reset links can't be sent
                automatically. An administrator can set a new password for you from the Accounts page.
              </Alert>
              <Link
                to="/login"
                className="inline-flex h-10 w-full items-center justify-center rounded-lg bg-brand-700 px-4 text-sm font-medium text-white hover:bg-brand-800"
              >
                Back to sign in
              </Link>
            </div>
          ) : sent ? (
            <div className="space-y-4">
              <Alert variant="success" title="Check your email">
                If an account exists for {email}, a password reset link is on its way.
              </Alert>
              <Link
                to="/login"
                className="inline-flex h-10 w-full items-center justify-center rounded-lg bg-brand-700 px-4 text-sm font-medium text-white hover:bg-brand-800"
              >
                Back to sign in
              </Link>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-4">
              {formError && <Alert variant="danger">{formError}</Alert>}
              <Input
                label="Email address"
                type="email"
                autoComplete="email"
                value={email}
                error={error}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button type="submit" block loading={busy}>
                Send reset link
              </Button>
            </form>
          )}
        </Card>

        <p className="mt-6 text-center text-sm text-ink-500">
          <Link to="/login" className="font-medium text-brand-700 hover:text-brand-800">
            ← Back to sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
