import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { formatDate, noticeParagraphs, todayIsoDate } from '../../lib/utils';
import type { Notice, NoticeAudience, NoticeCategory, NoticeStatus } from '../../lib/types';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageSpinner } from '../../components/ui/Spinner';
import { useToast } from '../../components/Toast';

const CATEGORIES: NoticeCategory[] = ['general', 'admissions', 'academic', 'events', 'exams', 'urgent'];
const AUDIENCES: NoticeAudience[] = ['public', 'staff', 'students', 'parents', 'authenticated'];
const STATUSES: NoticeStatus[] = ['draft', 'published', 'archived'];

const STATUS_TONE: Record<NoticeStatus, 'neutral' | 'success' | 'warning'> = {
  draft: 'neutral',
  published: 'success',
  archived: 'warning',
};

interface NoticeForm {
  title: string;
  body: string;
  category: NoticeCategory;
  audience: NoticeAudience;
  publishedAt: string;
  expiresAt: string;
}

const EMPTY_FORM: NoticeForm = {
  title: '',
  body: '',
  category: 'general',
  audience: 'public',
  publishedAt: '',
  expiresAt: '',
};

/** Admin notice board — create, edit and publish/archive notices. */
export function AdminNotices() {
  const repo = useRepo();
  const toast = useToast();
  const [statusFilter, setStatusFilter] = useState<NoticeStatus | 'all'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Notice | null>(null);
  const [form, setForm] = useState<NoticeForm>(EMPTY_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const { data, loading, error, reload } = useAsync<Notice[]>(
    () => repo.listNotices(statusFilter === 'all' ? {} : { status: statusFilter }),
    [repo, statusFilter],
  );

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setErrors({});
    setFormError(null);
    setModalOpen(true);
  }

  function openEdit(notice: Notice) {
    setEditing(notice);
    setForm({
      title: notice.title,
      body: notice.body,
      category: notice.category,
      audience: notice.audience,
      publishedAt: notice.publishedAt ? notice.publishedAt.slice(0, 10) : '',
      expiresAt: notice.expiresAt ? notice.expiresAt.slice(0, 10) : '',
    });
    setErrors({});
    setFormError(null);
    setModalOpen(true);
  }

  async function save() {
    const fe: Record<string, string> = {};
    if (form.title.trim().length < 2) fe.title = 'Enter a title.';
    if (form.body.trim().length < 10) fe.body = 'The body must be at least 10 characters.';
    if (Object.keys(fe).length > 0) {
      setErrors(fe);
      return;
    }
    setErrors({});
    setSaving(true);
    setFormError(null);
    try {
      const payload = {
        title: form.title.trim(),
        body: form.body.trim(),
        category: form.category,
        audience: form.audience,
        publishedAt: form.publishedAt ? new Date(form.publishedAt).toISOString() : null,
        expiresAt: form.expiresAt ? new Date(form.expiresAt).toISOString() : null,
      };
      if (editing) {
        await repo.updateNotice(editing.id, payload);
        toast.push('success', 'Notice updated.');
      } else {
        await repo.createNotice(payload);
        toast.push('success', 'Notice created.');
      }
      setModalOpen(false);
      reload();
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  async function setStatus(notice: Notice, status: NoticeStatus) {
    try {
      await repo.setNoticeStatus(notice.id, status);
      toast.push('success', `Notice set to ${status}.`);
      reload();
    } catch (err) {
      toast.push('error', errMessage(err));
    }
  }

  return (
    <div>
      <PageHeader
        title="Notices"
        subtitle="Publish announcements to the public site or private audiences."
        actions={
          <Button onClick={openCreate}>
            <span className="text-lg leading-none">+</span> New notice
          </Button>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span className="text-sm text-ink-500">Filter:</span>
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as NoticeStatus | 'all')} className="max-w-40">
          <option value="all">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </Select>
      </div>

      {loading && <PageSpinner />}
      {error && <Alert variant="danger">{error}</Alert>}

      {data && data.length === 0 && <p className="text-sm text-ink-500">No notices match this filter.</p>}

      <div className="space-y-4">
        {data?.map((notice) => (
          <Card key={notice.id}>
            <CardBody>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-base font-semibold text-ink-900">{notice.title}</h2>
                    <Badge tone={STATUS_TONE[notice.status]}>{notice.status}</Badge>
                    <Badge tone="info">{notice.audience}</Badge>
                    <Badge>{notice.category}</Badge>
                  </div>
                  <p className="mt-1 text-xs text-ink-400">
                    By {notice.authorName} · {notice.publishedAt ? formatDate(notice.publishedAt) : formatDate(notice.createdAt)}
                  </p>
                  <div className="mt-2 space-y-1 text-sm text-ink-600">
                    {noticeParagraphs(notice.body)
                      .slice(0, 2)
                      .map((para, i) => (
                        <p key={i}>{para}</p>
                      ))}
                  </div>
                </div>
                <div className="flex shrink-0 flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => openEdit(notice)}>
                    Edit
                  </Button>
                  {notice.status !== 'published' && (
                    <Button size="sm" onClick={() => void setStatus(notice, 'published')}>
                      Publish
                    </Button>
                  )}
                  {notice.status !== 'archived' && (
                    <Button size="sm" variant="ghost" onClick={() => void setStatus(notice, 'archived')}>
                      Archive
                    </Button>
                  )}
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit notice' : 'New notice'}
        size="lg"
        footer={
          <>
            <Button variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={() => void save()}>
              {editing ? 'Save changes' : 'Create notice'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && <Alert variant="danger">{formError}</Alert>}
          <Input label="Title" value={form.title} error={errors.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <Textarea label="Body" rows={6} value={form.body} error={errors.body} onChange={(e) => setForm({ ...form, body: e.target.value })} required />
          <div className="grid gap-4 sm:grid-cols-2">
            <Select label="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as NoticeCategory })}>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
            <Select label="Audience" value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value as NoticeAudience })}>
              {AUDIENCES.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Input
              label="Publish date (optional)"
              type="date"
              value={form.publishedAt}
              hint={editing?.status === 'published' ? 'Already published.' : 'Leave blank to save as a draft.'}
              onChange={(e) => setForm({ ...form, publishedAt: e.target.value })}
            />
            <Input
              label="Expiry date (optional)"
              type="date"
              min={todayIsoDate()}
              value={form.expiresAt}
              onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}
