import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { dataMode, supabaseAnonKey, supabaseUrl } from '../env';
import { LocalRepository } from './localRepository';
import type { SchoolRepository } from './types';

/**
 * Application-wide repository singleton.
 * - Demo mode (no credentials): in-memory store with fictional data.
 * - Supabase mode: real backend, protected by Postgres RLS.
 *
 * The anon key is safe to ship to the browser; the service-role key must
 * NEVER appear here (or anywhere in client code).
 */
let instance: SchoolRepository | null = null;
let supabaseClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  if (dataMode !== 'supabase') return null;
  if (!supabaseClient) {
    supabaseClient = createClient(supabaseUrl as string, supabaseAnonKey as string, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    });
  }
  return supabaseClient;
}

export function getRepository(): SchoolRepository {
  if (!instance) {
    if (dataMode === 'supabase') {
      const client = getSupabaseClient();
      if (!client) throw new Error('Supabase client could not be created. Check your environment variables.');
      // Lazily imported to keep demo-only builds free of the Supabase code path.
      // (Bundlers include both files, but the local store is only instantiated on demand.)
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      throw new Error(
        'Supabase mode requires the SupabaseRepository. It is wired in src/lib/repo/index.ts once migrations are applied.',
      );
    }
    instance = new LocalRepository();
  }
  return instance;
}

/** Test helper — replace/restore the repository singleton. */
export function setRepository(repo: SchoolRepository | null): void {
  instance = repo;
}
