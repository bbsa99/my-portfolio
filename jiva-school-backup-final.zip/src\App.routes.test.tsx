import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import App from './App';
import { AuthProvider } from './state/AuthContext';
import { getRepository } from './lib/repo';
import { resetDemoDb } from './lib/repo/localRepository';

/**
 * Route-level smoke tests: mount EVERY sidebar route for each role and assert
 * the page actually renders its heading. A missing provider/context (e.g. the
 * ToastProvider regression) makes React unmount the whole tree — these tests
 * fail loudly instead of the deployed app going blank.
 */

const repo = () => getRepository();

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <AuthProvider>
        <App />
      </AuthProvider>
    </MemoryRouter>,
  );
}

async function expectHeading(path: string, name: string) {
  renderAt(path);
  expect(await screen.findByRole('heading', { level: 1, name })).toBeInTheDocument();
}

describe('public routes', () => {
  beforeEach(async () => {
    resetDemoDb();
    await repo().signOut();
  });
  afterEach(cleanup);

  it('renders the public home page', async () => {
    renderAt('/');
    expect(await screen.findByRole('navigation')).toBeInTheDocument();
  });

  it('renders the login page', async () => {
    renderAt('/login');
    expect(await screen.findByRole('heading', { level: 1, name: /Sign in to/ })).toBeInTheDocument();
  });

  it('renders the forgot-password page', async () => {
    renderAt('/forgot-password');
    expect(await screen.findByRole('heading', { level: 1, name: 'Reset your password' })).toBeInTheDocument();
  });

  it('redirects unauthenticated visitors of /app/admin to the login page', async () => {
    renderAt('/app/admin');
    expect(await screen.findByRole('heading', { level: 1, name: /Sign in to/ })).toBeInTheDocument();
  });
});

describe('admin routes', () => {
  beforeEach(async () => {
    resetDemoDb();
    await repo().signIn('admin@jivademo.test', 'DemoAdmin!23');
  });
  afterEach(async () => {
    cleanup();
    await repo().signOut();
  });

  const ROUTES: Array<[string, string]> = [
    ['/app/admin', 'Administrator overview'],
    ['/app/admin/students', 'Students'],
    ['/app/admin/teachers', 'Staff'],
    ['/app/admin/curriculum', 'Curriculum'],
    ['/app/admin/accounts', 'Accounts'],
    ['/app/admin/notices', 'Notices'],
    ['/app/admin/review', 'Results review'],
    ['/app/admin/audit', 'Audit log'],
  ];

  for (const [path, heading] of ROUTES) {
    it(`renders ${path}`, async () => {
      await expectHeading(path, heading);
    });
  }

  it('keeps the shell alive when navigating the sidebar', async () => {
    const user = userEvent.setup();
    renderAt('/app/admin');
    await screen.findByRole('heading', { level: 1, name: 'Administrator overview' });

    // Navigate through every admin sidebar item — the reported white-screen path.
    for (const label of ['Students', 'Staff', 'Curriculum', 'Accounts', 'Notices', 'Results review', 'Audit log']) {
      await user.click(screen.getByRole('link', { name: label }));
      const main = document.querySelector('main');
      expect(main, `<main> missing after clicking ${label}`).not.toBeNull();
      expect(main!.textContent!.replace(/\s+/g, ' ').trim().length).toBeGreaterThan(10);
      expect(screen.getByRole('navigation')).toBeInTheDocument();
    }
  });
});

describe('teacher routes', () => {
  beforeEach(async () => {
    resetDemoDb();
    await repo().signIn('teacher1@jivademo.test', 'DemoTeacher!23');
  });
  afterEach(async () => {
    cleanup();
    await repo().signOut();
  });

  it('renders /app/teacher', async () => {
    await expectHeading('/app/teacher', 'Teacher overview');
  });

  it('renders /app/teacher/assessments', async () => {
    await expectHeading('/app/teacher/assessments', 'Assessments');
  });
});

describe('student routes', () => {
  beforeEach(async () => {
    resetDemoDb();
    await repo().signIn('student@jivademo.test', 'DemoStudent!23');
  });
  afterEach(async () => {
    cleanup();
    await repo().signOut();
  });

  it('renders /app/student', async () => {
    await expectHeading('/app/student', 'Welcome, David');
  });

  it('renders /app/student/results', async () => {
    await expectHeading('/app/student/results', 'My results');
  });
});

describe('parent routes', () => {
  beforeEach(async () => {
    resetDemoDb();
    await repo().signIn('parent@jivademo.test', 'DemoParent!23');
  });
  afterEach(async () => {
    cleanup();
    await repo().signOut();
  });

  it('renders /app/parent', async () => {
    await expectHeading('/app/parent', 'Parent portal');
  });
});
