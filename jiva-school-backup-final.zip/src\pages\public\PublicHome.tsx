import { Link } from 'react-router-dom';
import { schoolCity, schoolName } from '../../lib/env';
import { Button, LinkButton } from '../../components/ui/Button';
import { Card, CardBody } from '../../components/ui/Card';
import { IconBook, IconClipboard, IconShield, IconUsers } from '../../components/ui/Icons';
import { ProgressiveImage } from '../../components/ui/ProgressiveImage';

/** Learning environments shown in the campus-life gallery. */
const ENVIRONMENTS = [
  {
    src: '/images/library.jpg',
    alt: 'School library with tall bookshelves filled with books and warm natural light',
    title: 'Library & reading',
    body: 'A calm, well-lit library that encourages reading for pleasure and research across every subject.',
  },
  {
    src: '/images/classroom.jpg',
    alt: 'Bright, modern classroom with students learning together at their desks',
    title: 'Bright classrooms',
    body: 'Modern, comfortable classrooms designed for focused, collaborative and inclusive learning.',
  },
  {
    src: '/images/science-lab.jpg',
    alt: 'School science laboratory with equipment for hands-on experiments',
    title: 'Science & computer labs',
    body: 'Practical, well-equipped labs where students learn by investigating, experimenting and building.',
  },
  {
    src: '/images/playground.jpg',
    alt: 'School playground and outdoor recreation area for students',
    title: 'Sport & play',
    body: 'Safe outdoor space for sport, play and physical education that supports healthy, active lifestyles.',
  },
  {
    src: '/images/students-learning.jpg',
    alt: 'Teacher supporting and guiding students during a classroom lesson',
    title: 'Expert teaching',
    body: 'Dedicated subject specialists who know every child and give them the support they need to thrive.',
  },
  {
    src: '/images/collaboration.jpg',
    alt: 'Students collaborating together on a group learning activity',
    title: 'Collaboration',
    body: 'Group work, discussion and projects that build confidence, communication and teamwork.',
  },
];


const HIGHLIGHTS = [
  {
    icon: IconBook,
    title: 'Strong academics',
    body: 'A broad, balanced curriculum from the early years through senior school, taught by dedicated subject specialists.',
  },
  {
    icon: IconUsers,
    title: 'Caring community',
    body: 'Small class sizes and committed staff who know every child by name and support them as individuals.',
  },
  {
    icon: IconShield,
    title: 'Safe & modern campus',
    body: 'Secure facilities, well-equipped science and computer labs, a library and space to learn and play.',
  },
  {
    icon: IconClipboard,
    title: 'Clear reporting',
    body: 'Transparent termly results published securely to the parent portal, so families stay informed.',
  },
];

/** Public home / marketing landing page. */
export function PublicHome() {
  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient text-white">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-20 lg:grid-cols-2 lg:items-center lg:py-28">
          <div>
            <p className="inline-flex rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-brand-100">
              {schoolCity}
            </p>
            <h1 className="mt-5 text-4xl font-semibold leading-tight text-white lg:text-5xl">
              A place to grow, learn and belong
            </h1>
            <p className="mt-5 max-w-xl text-lg text-brand-100">
              {schoolName} nurtures curious, confident and kind young people through excellent
              teaching and a warm, supportive community.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <LinkButton href="/admissions" variant="secondary" size="lg">
                Apply for admission
              </LinkButton>
              <LinkButton
                href="/academics"
                size="lg"
                className="border border-white/30 bg-transparent text-white hover:bg-white/10"
              >
                Explore academics
              </LinkButton>
            </div>
          </div>
          <div className="relative hidden lg:block">
            <ProgressiveImage
              src="/images/campus.jpg"
              alt="Jiva School campus courtyard with landscaped grounds"
              wrapperClassName="aspect-[4/3] w-full rounded-2xl"
            />
            <div className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/20" />
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="max-w-2xl">
          <h2 className="text-2xl font-semibold text-ink-900">Why families choose {schoolName}</h2>
          <p className="mt-2 text-ink-500">
            We combine high expectations with genuine care, so every student is known, challenged and encouraged.
          </p>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2">
          {HIGHLIGHTS.map(({ icon: Icon, title, body }) => (
            <Card key={title}>
              <CardBody className="flex gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                  <Icon className="h-6 w-6" />
                </span>
                <div>
                  <h3 className="text-base font-semibold text-ink-900">{title}</h3>
                  <p className="mt-1 text-sm text-ink-500">{body}</p>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </section>

      {/* Learning environments */}
      <section className="border-t border-ink-100 bg-ink-50">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <div className="max-w-2xl">
            <h2 className="text-2xl font-semibold text-ink-900">Spaces designed for learning</h2>
            <p className="mt-2 text-ink-500">
              From our library and modern classrooms to science labs and outdoor space, our campus gives students
              inspiring places to learn, explore and grow.
            </p>
          </div>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {ENVIRONMENTS.map(({ src, alt, title, body }) => (
              <Card key={src} className="overflow-hidden">
                <ProgressiveImage
                  src={src}
                  alt={alt}
                  wrapperClassName="aspect-[16/10] w-full"
                />
                <CardBody>
                  <h3 className="text-base font-semibold text-ink-900">{title}</h3>
                  <p className="mt-1 text-sm text-ink-500">{body}</p>
                </CardBody>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-y border-ink-100 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-4 py-14 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-ink-900">Admissions are open</h2>
            <p className="mt-2 max-w-xl text-ink-500">
              Places are limited and confirmed only after the admissions process is complete. Start an enquiry and our
              office will be in touch.
            </p>
          </div>
          <div className="flex gap-3">
            <Link to="/admissions">
              <Button size="lg">Start an enquiry</Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="outline">
                Contact us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
