import { Navigate, Route, Routes } from 'react-router-dom';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ToastProvider } from './components/Toast';
import { PublicLayout } from './layouts/PublicLayout';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { DashboardLayout } from './layouts/DashboardLayout';
import { RequireAuth } from './components/guards/RequireAuth';
import { RequireRole } from './components/guards/RequireRole';
import { useAuth } from './state/AuthContext';
import { HOME_BY_ROLE } from './lib/permissions';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { AdminStudents } from './pages/admin/AdminStudents';
import { AdminTeachers } from './pages/admin/AdminTeachers';
import { AdminCurriculum } from './pages/admin/AdminCurriculum';
import { AdminAccounts } from './pages/admin/AdminAccounts';
import { AdminNotices } from './pages/admin/AdminNotices';
import { AdminReview } from './pages/admin/AdminReview';
import { AdminAudit } from './pages/admin/AdminAudit';
import { TeacherDashboard } from './pages/teacher/TeacherDashboard';
import { TeacherAssessments } from './pages/teacher/TeacherAssessments';
import { TeacherMarks } from './pages/teacher/TeacherMarks';
import { StudentDashboard } from './pages/student/StudentDashboard';
import { StudentResults } from './pages/student/StudentResults';
import { ParentDashboard } from './pages/parent/ParentDashboard';
import { PublicHome } from './pages/public/PublicHome';
import { PublicAcademics } from './pages/public/PublicAcademics';
import { PublicAdmissions } from './pages/public/PublicAdmissions';
import { PublicNotices } from './pages/public/PublicNotices';
import { PublicContact } from './pages/public/PublicContact';
import { NotFoundPage } from './pages/NotFoundPage';

/** Route table. `/app/*` is the authenticated area (role-aware via RequireAuth
 *  + the role index routes below). Everything else is the public site. */
export function App() {
  return (
    <ToastProvider>
      <ErrorBoundary>
        <Routes>
          {/* Public marketing + intake site */}
          <Route element={<PublicLayout />}>
            <Route index element={<PublicHome />} />
            <Route path="academics" element={<PublicAcademics />} />
            <Route path="admissions" element={<PublicAdmissions />} />
            <Route path="notices" element={<PublicNotices />} />
            <Route path="contact" element={<PublicContact />} />
          </Route>

          {/* Auth */}
          <Route path="login" element={<LoginPage />} />
          <Route path="register" element={<RegisterPage />} />
          <Route path="forgot-password" element={<ForgotPasswordPage />} />

          {/* Authenticated app — demo banner is rendered inside the portal shell
           * by DashboardLayout so the public marketing site stays clean. */}
          <Route
            path="app"
            element={
              <RequireAuth>
                <DashboardLayout />
              </RequireAuth>
            }
          >
            <Route index element={<RoleIndex />} />
            {/* admin */}
            <Route path="admin" element={<RequireRole role="admin"><AdminDashboard /></RequireRole>} />
            <Route path="admin/students" element={<RequireRole role="admin"><AdminStudents /></RequireRole>} />
            <Route path="admin/teachers" element={<RequireRole role="admin"><AdminTeachers /></RequireRole>} />
            <Route path="admin/curriculum" element={<RequireRole role="admin"><AdminCurriculum /></RequireRole>} />
            <Route path="admin/accounts" element={<RequireRole role="admin"><AdminAccounts /></RequireRole>} />
            <Route path="admin/notices" element={<RequireRole role="admin"><AdminNotices /></RequireRole>} />
            <Route path="admin/review" element={<RequireRole role="admin"><AdminReview /></RequireRole>} />
            <Route path="admin/audit" element={<RequireRole role="admin"><AdminAudit /></RequireRole>} />
            {/* teacher */}
            <Route path="teacher" element={<RequireRole role="teacher"><TeacherDashboard /></RequireRole>} />
            <Route path="teacher/assessments" element={<RequireRole role="teacher"><TeacherAssessments /></RequireRole>} />
            <Route
              path="teacher/assessments/:assessmentId/marks"
              element={<RequireRole role="teacher"><TeacherMarks /></RequireRole>}
            />
            {/* student */}
            <Route path="student" element={<RequireRole role="student"><StudentDashboard /></RequireRole>} />
            <Route path="student/results" element={<RequireRole role="student"><StudentResults /></RequireRole>} />
            {/* parent */}
            <Route path="parent" element={<RequireRole role="parent"><ParentDashboard /></RequireRole>} />
            {/* shared */}
            <Route path="*" element={<NotFoundPage />} />
          </Route>

          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </ErrorBoundary>
    </ToastProvider>
  );
}

/** Sends a signed-in user to the home page for their role. */
function RoleIndex() {
  const { session, loading } = useAuth();
  if (loading) return null;
  if (!session) return <Navigate to="/login" replace />;
  return <Navigate to={HOME_BY_ROLE[session.profile.role]} replace />;
}

export default App;
