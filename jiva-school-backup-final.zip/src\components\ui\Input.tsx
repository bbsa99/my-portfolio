import { forwardRef, useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

const FIELD_BASE =
  'w-full rounded-lg border border-ink-300 bg-white px-3 py-2 text-sm text-ink-800 shadow-sm placeholder:text-ink-400 focus:border-brand-600 focus:ring-1 focus:ring-brand-600 focus:outline-none disabled:bg-ink-100 disabled:text-ink-500';

export function Field({
  label,
  htmlFor,
  error,
  hint,
  required,
  className,
  children,
}: {
  label?: string;
  htmlFor?: string;
  error?: string | null;
  hint?: string;
  required?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={cn('space-y-1.5', className)}>
      {label && (
        <label htmlFor={htmlFor} className="block text-sm font-medium text-ink-700">
          {label}
          {required && <span className="ml-0.5 text-rose-600">*</span>}
        </label>
      )}
      {children}
      {hint && !error && <p className="text-xs text-ink-500">{hint}</p>}
      {error && <p className="text-xs font-medium text-rose-600">{error}</p>}
    </div>
  );
}

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string | null;
  hint?: string;
  wrapClassName?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, error, hint, className, wrapClassName, id, required, ...rest },
  ref,
) {
  const autoId = useId();
  const inputId = id ?? autoId;
  const control = (
    <input
      ref={ref}
      id={inputId}
      required={required}
      className={cn(FIELD_BASE, error && 'border-rose-400 focus:border-rose-500 focus:ring-rose-500', className)}
      aria-invalid={error ? true : undefined}
      {...rest}
    />
  );
  if (!label && !error && !hint) return control;
  return (
    <Field label={label} htmlFor={inputId} error={error} hint={hint} required={required} className={wrapClassName}>
      {control}
    </Field>
  );
});

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string | null;
  hint?: string;
  wrapClassName?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { label, error, hint, className, wrapClassName, id, required, rows = 4, ...rest },
  ref,
) {
  const autoId = useId();
  const areaId = id ?? autoId;
  const control = (
    <textarea
      ref={ref}
      id={areaId}
      rows={rows}
      required={required}
      className={cn(FIELD_BASE, 'resize-y', error && 'border-rose-400 focus:border-rose-500 focus:ring-rose-500', className)}
      aria-invalid={error ? true : undefined}
      {...rest}
    />
  );
  if (!label && !error && !hint) return control;
  return (
    <Field label={label} htmlFor={areaId} error={error} hint={hint} required={required} className={wrapClassName}>
      {control}
    </Field>
  );
});

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string | null;
  hint?: string;
  wrapClassName?: string;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(function Select(
  { label, error, hint, className, wrapClassName, id, required, children, ...rest },
  ref,
) {
  const autoId = useId();
  const selectId = id ?? autoId;
  const control = (
    <select
      ref={ref}
      id={selectId}
      required={required}
      className={cn(FIELD_BASE, error && 'border-rose-400 focus:border-rose-500 focus:ring-rose-500', className)}
      aria-invalid={error ? true : undefined}
      {...rest}
    >
      {children}
    </select>
  );
  if (!label && !error && !hint) return control;
  return (
    <Field label={label} htmlFor={selectId} error={error} hint={hint} required={required} className={wrapClassName}>
      {control}
    </Field>
  );
});
