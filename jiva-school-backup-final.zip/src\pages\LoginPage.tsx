import { useState, type FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../state/AuthContext';
import { errMessage } from '../state/useAsync';
import { loginSchema } from '../lib/validation';
import { isDemoMode, schoolName } from '../lib/env';
import { DEMO_ACCOUNTS } from '../lib/demo/seed';
import { HOME_BY_ROLE } from '../lib/permissions';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { Card } from '../components/ui/Card';
import { IconGraduation } from '../components/ui/Icons';

/** Shared sign-in screen for every role. */
export function LoginPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setFormError(null);
    const parsed = loginSchema.safeParse({ email, password });
    if (!parsed.success) {
      const fieldErrors: { email?: string; password?: string } = {};
      for (const issue of parsed.error.issues) {
        if (issue.path[0] === 'email') fieldErrors.email = issue.message;
        if (issue.path[0] === 'password') fieldErrors.password = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setBusy(true);
    try {
      const session = await signIn(parsed.data.email, parsed.data.password);
      navigate(from ?? HOME_BY_ROLE[session.profile.role], { replace: true });
    } catch (err) {
      setFormError(errMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink-50 px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-700 text-white">
            <IconGraduation className="h-7 w-7" />
          </span>
          <h1 className="mt-4 text-2xl font-semibold text-ink-900">Sign in to {schoolName}</h1>
          <p className="mt-1 text-sm text-ink-500">Access your dashboard as staff, student or parent.</p>
        </div>

        <Card className="p-6">
          <form onSubmit={onSubmit} noValidate className="space-y-4">
            {formError && <Alert variant="danger">{formError}</Alert>}
            <Input
              label="Email address"
              type="email"
              autoComplete="email"
              value={email}
              error={errors.email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Input
              label="Password"
              type="password"
              autoComplete="current-password"
              value={password}
              error={errors.password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <div className="flex items-center justify-between">
              <Link to="/forgot-password" className="text-sm font-medium text-brand-700 hover:text-brand-800">
                Forgot password?
              </Link>
            </div>
            <p className="text-center text-sm text-ink-500">
              New student or parent?{' '}
              <Link to="/register" className="font-medium text-brand-700 hover:text-brand-800">
                Create an account
              </Link>
            </p>
            <Button type="submit" block loading={busy}>
              Sign in
            </Button>
          </form>
        </Card>

        {isDemoMode && (
          <Card className="mt-4 p-5">
            <p className="text-sm font-semibold text-ink-800">Demo accounts</p>
            <p className="mt-1 text-xs text-ink-500">
              Fictional sample data. Pick a role to explore — the password is pre-filled for you.
            </p>
            <ul className="mt-3 space-y-2">
              {DEMO_ACCOUNTS.map((account) => (
                <li key={account.email}>
                  <button
                    type="button"
                    className="flex w-full items-center justify-between rounded-lg border border-ink-200 px-3 py-2 text-left text-sm hover:bg-ink-50"
                    onClick={() => {
                      setEmail(account.email);
                      setPassword(account.password);
                      setFormError(null);
                      setErrors({});
                    }}
                  >
                    <span className="font-medium text-ink-800">{account.label}</span>
                    <span className="text-xs text-ink-500">{account.email}</span>
                  </button>
                </li>
              ))}
            </ul>
          </Card>
        )}

        <p className="mt-6 text-center text-sm text-ink-500">
          <Link to="/" className="font-medium text-brand-700 hover:text-brand-800">
            ← Back to website
          </Link>
        </p>
      </div>
    </div>
  );
}
