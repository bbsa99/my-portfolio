import { useState } from 'react';
import { useAsync, errMessage } from '../../state/useAsync';
import { useRepo } from '../../state/useRepo';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Select } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { PageSpinner, EmptyState } from '../../components/ui/Spinner';
import { ResultCard } from '../../components/ResultCard';
import type { Student, Term, TermResult } from '../../lib/types';

/** Parent portal: view published results for linked children. */
export function ParentDashboard() {
  const repo = useRepo();
  const [childId, setChildId] = useState('');
  const [termId, setTermId] = useState('');

  const base = useAsync<{ children: Student[]; terms: Term[] }>(async () => {
    const [children, terms] = await Promise.all([repo.getMyChildren(), repo.listTerms()]);
    if (children.length > 0) setChildId((prev) => prev || children[0].id);
    return { children, terms };
  }, [repo]);

  const result = useAsync<TermResult | null>(
    async () => {
      if (!childId || !termId) return null;
      return repo.getPublishedResult(childId, termId);
    },
    [repo, childId, termId],
  );

  const currentTerm = base.data?.terms.find((t) => t.isCurrent) ?? base.data?.terms[0];
  const activeTermId = termId || currentTerm?.id || '';

  return (
    <div>
      <PageHeader title="Parent portal" subtitle="Follow your children's published results." />

      {base.loading && <PageSpinner />}
      {base.error && <Alert variant="danger">{base.error}</Alert>}

      {base.data && base.data.children.length === 0 && (
        <EmptyState
          title="No linked children"
          description="Your account isn't linked to any students yet. Please contact the school office."
        />
      )}

      {base.data && base.data.children.length > 0 && (
        <>
          <Card className="mb-6">
            <CardBody>
              <div className="grid gap-4 sm:grid-cols-2">
                <Select label="Child" value={childId} onChange={(e) => setChildId(e.target.value)}>
                  {base.data.children.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.fullName} ({c.studentId})
                    </option>
                  ))}
                </Select>
                <Select label="Term" value={activeTermId} onChange={(e) => setTermId(e.target.value)}>
                  {base.data.terms.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </Select>
              </div>
            </CardBody>
          </Card>

          <Card className="mb-6">
            <CardHeader title="My children" subtitle="Students linked to your account." action={<Badge tone="brand">View only</Badge>} />
            <CardBody>
              <ul className="grid gap-2 sm:grid-cols-2">
                {base.data.children.map((c) => (
                  <li key={c.id} className="rounded-lg border border-ink-200 px-3 py-2 text-sm">
                    <span className="font-medium text-ink-800">{c.fullName}</span>
                    <span className="ml-2 text-xs text-ink-400">{c.studentId}</span>
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>

          {childId && activeTermId ? (
            result.loading ? (
              <PageSpinner />
            ) : result.error ? (
              <Alert variant="danger">{errMessage(result.error)}</Alert>
            ) : result.data ? (
              <ResultCard result={result.data} />
            ) : (
              <EmptyState
                title="Results not published yet"
                description="Results for this term will appear here once the school publishes them."
              />
            )
          ) : null}
        </>
      )}
    </div>
  );
}
