import { useMemo } from 'react';
import { getRepository } from '../lib/repo';
import type { SchoolRepository } from '../lib/repo/types';

/**
 * Access the shared repository singleton. The instance is stable for the
 * lifetime of the app, so this is memoised on nothing and simply returns it.
 */
export function useRepo(): SchoolRepository {
  return useMemo(() => getRepository(), []);
}
