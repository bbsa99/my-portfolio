import { describe, expect, it } from 'vitest';
import {
  boundaryForPercent,
  computeSubjectResult,
  PLACEHOLDER_GRADING_SCALE,
  rankByPercentages,
  summarizeSubjects,
  validateMarkScore,
} from '../lib/grading';
import type { Assessment, Mark, Subject } from '../lib/types';

const subject: Subject = { id: 'sub-math', code: 'MATH', name: 'Mathematics', isCore: true };

function assessment(id: string, maxMarks: number, weight: number): Assessment {
  return {
    id,
    title: id,
    description: null,
    type: 'test',
    classSectionId: 'cls-7a',
    subjectId: subject.id,
    termId: 'term-t1-2026',
    maxMarks,
    weight,
    dueDate: null,
    status: 'submitted',
    submittedAt: null,
    createdBy: 'prof-t1',
    createdAt: '2026-09-10T08:00:00Z',
    updatedAt: '2026-09-10T08:00:00Z',
  };
}

function mark(assessmentId: string, score: number | null): Mark {
  return {
    id: `mk-${assessmentId}`,
    assessmentId,
    studentId: 'stu-01',
    score,
    status: 'submitted',
    enteredBy: 'prof-t1',
    createdAt: '2026-10-01T09:00:00Z',
    updatedAt: '2026-10-01T09:00:00Z',
  };
}

describe('validateMarkScore', () => {
  it('accepts null (unmarked) and marks within range', () => {
    expect(validateMarkScore(null, 100).ok).toBe(true);
    expect(validateMarkScore(0, 100).ok).toBe(true);
    expect(validateMarkScore(100, 100).ok).toBe(true);
    expect(validateMarkScore(87.5, 100).ok).toBe(true);
  });

  it('rejects negatives, over-max, and >2 decimals', () => {
    expect(validateMarkScore(-1, 100).ok).toBe(false);
    expect(validateMarkScore(101, 100).ok).toBe(false);
    expect(validateMarkScore(12.345, 100).ok).toBe(false);
    expect(validateMarkScore(10, 0).ok).toBe(false);
  });
});

describe('boundaryForPercent', () => {
  it('maps percentages to the placeholder grade letters', () => {
    expect(boundaryForPercent(95)?.letter).toBe('A');
    expect(boundaryForPercent(85)?.letter).toBe('B');
    expect(boundaryForPercent(72)?.letter).toBe('C');
    expect(boundaryForPercent(61)?.letter).toBe('D');
    expect(boundaryForPercent(55)?.letter).toBe('E');
    expect(boundaryForPercent(30)?.letter).toBe('F');
  });

  it('returns null for non-finite input', () => {
    expect(boundaryForPercent(Number.NaN)).toBeNull();
  });
});

describe('computeSubjectResult', () => {
  const assessments = [assessment('a1', 20, 20), assessment('a2', 80, 80)];
  const marks = [mark('a1', 18), mark('a2', 60)];

  it('computes raw and weighted percentages when weights sum to 100', () => {
    const result = computeSubjectResult({ subject, assessments, marks });
    // obtained 78 / maximum 100 = 78%
    expect(result.obtained).toBe(78);
    expect(result.maximum).toBe(100);
    expect(result.percentage).toBe(78);
    // (18/20*20) + (60/80*80) = 18 + 60 = 78
    expect(result.weightedPercentage).toBe(78);
    expect(result.grade).toBe('C');
  });

  it('returns null weighted percentage when weights are incomplete', () => {
    const partial = [assessment('a1', 20, 20)];
    const result = computeSubjectResult({ subject, assessments: partial, marks: [mark('a1', 18)] });
    expect(result.weightedPercentage).toBeNull();
    expect(result.percentage).toBe(90);
  });

  it('treats a missing mark as incomplete for weighting', () => {
    const result = computeSubjectResult({ subject, assessments, marks: [mark('a1', 18)] });
    expect(result.weightedPercentage).toBeNull();
  });
});

describe('summarizeSubjects', () => {
  it('aggregates totals and derives an overall grade', () => {
    const a = computeSubjectResult({
      subject,
      assessments: [assessment('a1', 20, 20), assessment('a2', 80, 80)],
      marks: [mark('a1', 18), mark('a2', 60)],
    });
    const summary = summarizeSubjects([a], PLACEHOLDER_GRADING_SCALE);
    expect(summary.totalObtained).toBe(78);
    expect(summary.totalMaximum).toBe(100);
    expect(summary.overallPercentage).toBe(78);
    expect(summary.overallGrade).toBe('C');
  });
});

describe('rankByPercentages', () => {
  it('ranks by descending percentage with 1 = best, ties share a rank', () => {
    const map = new Map<string, number>([
      ['a', 90],
      ['b', 80],
      ['c', 80],
      ['d', 70],
    ]);
    expect(rankByPercentages(map, 'a')).toBe(1);
    expect(rankByPercentages(map, 'b')).toBe(2);
    expect(rankByPercentages(map, 'c')).toBe(2);
    expect(rankByPercentages(map, 'd')).toBe(4);
    expect(rankByPercentages(map, 'missing')).toBeNull();
  });
});
