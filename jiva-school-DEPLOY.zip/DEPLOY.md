# Deploy instructions — Jiva School (Cloudflare Pages)

This folder (`dist/`) is the **production build**. Deploy it to Cloudflare Pages
to update https://jiva-school.pages.dev.

## Option A — Drag & drop (fastest, matches how the site is currently published)

1. Log in to the Cloudflare dashboard.
2. Go to **Workers & Pages → jiva-school → Create deployment** (or the
   "Upload assets" / drag-and-drop area for the Pages project).
3. Upload **the entire contents of this `dist/` folder** (not the folder itself
   — the files `index.html`, `assets/`, `images/`, `_redirects` must be at the
   root of what you upload).
4. Wait for the deployment to finish, then open the site and hard-refresh
   (Ctrl+F5) to bypass cache.

## Option B — Wrangler CLI (repeatable / CI)

```powershell
# from the project root, with your Cloudflare API token exported:
npm.cmd run build
npx wrangler pages deploy dist --project-name=jiva-school
```

## What's in this build

- `index.html` — app entry (SPA)
- `assets/` — fingerprinted JS + CSS
- `images/` — the 7 locally-stored photographs (+ CREDITS.md)
- `_redirects` — SPA routing (`/* /index.html 200`) so /academics etc. work on refresh

## Verified before packaging

- `npm run build` succeeded (tsc + vite, no errors)
- 41/41 tests pass
- All routes return 200; all 7 images return 200 image/jpeg
- No demo banner on any public page (demo notice is portal-only, behind login)

## Rollback

Cloudflare keeps previous deployments. If anything looks wrong, open the
Pages project → **Deployments** → click the previous working deployment →
**Rollback to this deployment**. A local backup of the pre-change code is at
`jiva-school-backup-final.zip` (in the parent folder).
