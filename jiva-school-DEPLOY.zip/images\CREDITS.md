# Image credits & licences

All photographs on this site are stored **locally** in `public/images/` and are
served from our own origin (no remote hotlinking). Every image was verified as a
valid, fully-decodable JPEG after download.

## Source & licence

All photographs come from **[Unsplash](https://unsplash.com)** and are used under
the **Unsplash Licence** (<https://unsplash.com/license>), which allows free use
for commercial and non-commercial purposes with **no permission required**. The
licence does not require attribution, but we record the source here for
transparency and future maintenance.

> Unsplash Licence summary: free to download and use for commercial and
> non-commercial purposes; you may modify and build upon the photos. Compiling
> photos from Unsplash to replicate a similar or competing service is not
> permitted.

These are **stock photographs used for illustration only.** They do not depict
actual Jiva School students, staff or facilities, and they are not affiliated
with, or endorsed by, any other institution. No third-party school logos or
branding are shown.

## Files

| File | Subject | Source |
| --- | --- | --- |
| `public/images/campus.jpg` | Welcoming campus / landscaped courtyard | Unsplash |
| `public/images/library.jpg` | University-style library, bookshelves, natural light | Unsplash |
| `public/images/classroom.jpg` | Bright modern classroom, students learning | Unsplash |
| `public/images/playground.jpg` | School playground / outdoor recreation | Unsplash |
| `public/images/science-lab.jpg` | Science / computer laboratory | Unsplash |
| `public/images/students-learning.jpg` | Teacher supporting students in class | Unsplash |
| `public/images/collaboration.jpg` | Students collaborating on group work | Unsplash |

## Replacing images with real school photos

When genuine photographs of Jiva School become available, replace the files in
`public/images/` (keeping the same filenames) and update the `alt` text in the
page components so descriptions accurately reflect the real campus.
